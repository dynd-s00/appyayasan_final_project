<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Invoice extends CI_Controller
{
    public function index()
    {
         $data['title'] = 'Yayasan ILQ | Pengeluaran kencleng';
        $data['kencleng'] = $this->M_kencleng->tampil()->result();
        $this->load->view('templates/header',$data);
        $this->load->view('templates/body');  
        $this->load->view('templates/sidebar');
        $this->load->view('invoice',$data);
        $this->load->view('admin/dashboard');    
        $this->load->view('templates/footer');
    }
    public function printkc($noinv)
    {
        $where = array('noinv' => $noinv);
        $data['kencleng'] = $this->M_kencleng->printkc($where,'kencleng')->result();
        $this->load->view('printinv', $data);
    }
    public function printinf($noinv)
    {
        $where = array('noinv' => $noinv);
        $data['donasi'] = $this->M_donasi->printinf($where,'donasi')->result();
        $this->load->view('printinf', $data);
    }
    public function printsed()
    {
        $data['wakaf'] = $this->M_wakaf->printsed()->result();
        $this->load->view('printsed', $data);
    }
}