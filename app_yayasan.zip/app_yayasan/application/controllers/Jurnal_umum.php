<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Jurnal_umum extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('username') != 'bendahara') {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <strong>Anda Harus login!</strong> 
        </div>');
            redirect('Auth');
        }
    }
    public function index()
    {
        $data['title'] = 'Yayasan ILQ | Jurnal Umum';
        $this->load->model('M_kencleng');
        $data['jurnal_umum'] = $this->M_kencleng->tampilkan()->result();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('jurnal_umum', $data);
        $this->load->view('admin/dashboard');
        $this->load->view('templates/footer');
    }
    public function laporan_ju()
    {
        $data['title'] = 'Yayasan ILQ | Data donasi';
        $this->load->model('M_kencleng');
        $data['jurnal_umum'] = $this->M_kencleng->tampilkan()->result();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar_ketua');
        $this->load->view('jurnal_umum', $data);
        $this->load->view('admin/dashboard');
        $this->load->view('templates/footer');
    }
    public function print_jubln($tgl)
    {
        $data['title'] = 'Yayasan ILQ | Print Jurnal Umum';
        $this->load->model('M_kencleng');
        $where = array('tgl' => $tgl);
        $data['jurnal_umum'] = $this->M_kencleng->print_jubln($where,'jurnal_umum')->result();
        $this->load->view('printju', $data);
       
    }
    public function print_juthn()
    {
        $data['title'] = 'Yayasan ILQ | Print Jurnal Umum';
        $this->load->model('M_kencleng');
        $data['jurnal_umum'] = $this->M_kencleng->print_juthn('jurnal_umum')->result();
        $this->load->view('printju', $data);
    }
    public function bulan()
    {
        $data['title'] = 'Yayasan ILQ | Periode Jurnal Umum';
        $this->load->model('M_kencleng');
        $data['jurnal_umum'] = $this->M_kencleng->show()->result();
        $this->load->view('templates/header',$data);
        $this->load->view('templates/sidebar');
        $this->load->view('ju_bulan', $data);
        $this->load->view('templates/footer');

    }
    public function tahun()
	{
        $data['title'] = 'Yayasan ILQ | Periode Jurnal Umum';
        $this->load->model('M_kencleng');
        $data['jurnal_umum'] = $this->M_kencleng->showing()->result();
        $this->load->view('templates/header',$data);
        $this->load->view('templates/sidebar');
        $this->load->view('ju_tahun', $data);
        $this->load->view('templates/footer');
    }
}
 