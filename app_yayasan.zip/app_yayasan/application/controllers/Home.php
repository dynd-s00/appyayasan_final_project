<?php

namespace App\Controllers;

use App\Models\jemaah;
/*
class Home extends BaseController
{
    public function index()
    {
        $model = new jemaah();
        $data = $model->findAll();

        return  view('data_jemaah', [
            'jemaah' => $data
        ]);
    }
    public function save()
    {
        dd($this->request->getPost());
    }
}
