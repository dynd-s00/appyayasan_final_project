<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Data_mentor extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('username') != 'bendahara') {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <strong>Anda Harus login!</strong> 
        </div>');
            redirect('Auth');
        }
    }
    public function index()
    {
        $data['mentor'] = $this->M_mentor->tampil_data()->result();
        $data['title'] = 'Yayasan ILQ | Data Mentor';
        $this->load->view('templates/header',$data);
        $this->load->view('templates/header');
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('mentor', $data);
        $this->load->view('admin/dashboard');
        $this->load->view('templates/footer');
    }
    public function hapus($nim)
    {
        $where = array('nim' => $nim);
        $this->M_mentor->hapus_data($where, 'mentor');
        redirect('Data_mentor/index');
    }

    public function logout()
    {
        $this->load->view('logout');
    }
    public function autonumbr()
    {
        $nim = '373';
        $this->db->select('RIGHT(mentor.nim,1) as nim', FALSE);
        $this->db->order_by('nim', 'DESC');
        $this->db->limit(1);
        $sql = $this->db->get('mentor');

        if ($sql->num_rows() <> 0) {
            $data = $sql->row();
            $autonumbr = intval($data->nim) + 1;
        } else {
            $autonumbr = 1;
        }
        $limit = str_pad($autonumbr, 5, "0", STR_PAD_LEFT);
        $nim = $nim . $limit;
        return $nim;
    }
    public function tambah_data()
    {
        $nim = $this->autonumbr();
        $nama = $this->input->post('nama');
        $jenis_kelamin = $this->input->post('jenis_kelamin');
        

        $data = array(
            'nim' => $nim,
            'nama' => $nama,
            'jenis_kelamin' => $jenis_kelamin,

        );
        $this->M_mentor->insert_data($data, 'mentor');

        redirect('Data_mentor/index');
    }
    public function edit_mentor($nim)
    {
        $where = array('nim' => $nim);
        $data['mentor'] = $this->M_mentor->edit_data_mentor($where, 'mentor')->result();
        $data['title'] = 'Yayasan ILQ | EditData Mentor';
        $this->load->view('templates/header',$data);
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('editmentor', $data);
        $this->load->view('admin/dashboard');
        $this->load->view('templates/footer');
    }
    public function update()
    {
        $nim = $this->input->post('nim');
        $nama = $this->input->post('nama');
        $jenis_kelamin = $this->input->post('jenis_kelamin');
        
        $data = array(
            'nama' => $nama,
            'jenis_kelamin' => $jenis_kelamin,
        );
        $where = array(
            'nim' => $nim,
        );
        $this->M_mentor->update_data($where, $data, 'mentor');   
        redirect('Data_mentor/index');
    }
  
}
