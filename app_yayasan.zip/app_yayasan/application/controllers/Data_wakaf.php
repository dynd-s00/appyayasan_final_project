<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Data_wakaf extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('M_wakaf');
        if ($this->session->userdata('username') != 'bendahara') {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <strong>Anda Harus login!</strong> 
        </div>');
            redirect('Auth');
        }
    }
    public function index()
    {
        $data['wakaf'] = $this->M_wakaf->tampil()->result();
        $data['wakaf'] = $this->M_wakaf->wakaf()->result();
        $data['title'] = 'Yayasan ILQ | Data wakaf';
        $this->load->model('M_wakaf');
        $this->load->view('templates/header', $data);
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('data_wakaf', $data);
        $this->load->view('templates/footer');
    }
    public function bayar_wakaf()
    {
        $noinv = $this->autonumbr();
        $nama = $this->input->post('nama');
        $tgl = $this->input->post('tgl');
        $hp  = $this->input->post('hp');
        $wakaf  = $this->input->post('wakaf');
        $jenis = $this->input->post('jenis');

        $data = array(
            'noinv' => $noinv,
            'nama'  => $nama,
            'tgl' => $tgl,
            'hp' => $hp,
            'wakaf' => $wakaf,
            'jenis' => $jenis,
        );
        $this->M_wakaf->input($data, 'wakaf');

        //----- kode simpan jurnal   
        $data = array(
            'tgl'             =>  $tgl,
            'bukti'           => $noinv,
            'keterangan'      => 'kas',
            'ref'             => '111',
            'debit'           => $wakaf,
            'kredit'          => 0,
        );
        $this->M_wakaf->input_jurnal($data, 'jurnal_umum');
        //------------------------- simpan junal ke2
        $data = array(
            'tgl'             =>  $tgl,
            'bukti'           => $noinv,
            'keterangan'      => '&nbsp; &nbsp; Dana wakaf',
            'ref'             => '413',
            'debit'           => 0,
            'kredit'          => $wakaf,
        );
        $this->M_wakaf->input_ju($data, 'jurnal_umum');

        //---------- kode simpan buku besar
        $data = array(
            'kdakun'        => '111',
            'nmakun'        => 'kas',
            'tgl'           =>  $tgl,
            'keterangan'    =>  'Dana wakaf',
            'ref'           =>  '413',
            'debit'         =>  $wakaf,
            'kredit'        =>  '0',
        );
        $this->M_wakaf->input_BB($data, 'buku_besar');
        //---------- kode simpan buku besar ke2
        $data = array(
            'kdakun'        => '413',
            'nmakun'        => 'Dana wakaf',
            'tgl'           =>  $tgl,
            'keterangan'    =>  'kas',
            'ref'           =>  '111',
            'debit'         =>  '0',
            'kredit'        =>  $wakaf,
        );
        $this->M_wakaf->input_buku($data, 'buku_besar');
        redirect('Data_wakaf');
    }
    public function autonumbr()
    {
        $noinv = 'WKFBM';
        $this->db->select('RIGHT(wakaf.noinv,2) as noinv', FALSE);
        $this->db->order_by('noinv', 'DESC');
        $this->db->limit(1);
        $sql = $this->db->get('wakaf');

        if ($sql->num_rows() <> 0) {
            $data = $sql->row();
            $autonumbr = intval($data->noinv) + 1;
        } else {
            $autonumbr = 1;
        }
        $limit = str_pad($autonumbr, 2, "0", STR_PAD_LEFT);
        $noinv = $noinv . $limit;
        return $noinv;
    }
    public function hapus($noinv)
    {
        $where = array('noinv' => $noinv);
        $this->M_wakaf->hapus_data($where, 'wakaf');
        redirect('Data_wakaf');
    }

    public function invoicewakaf($noinv)
    {
        $where = array('noinv' => $noinv);
        $data['wakaf'] = $this->M_wakaf->data($where, 'wakaf')->result();
        $data['title'] = 'Yayasan ILQ | Invoice wakaf';
        $this->load->view('templates/header', $data);
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('invoicewakaf', $data);
        $this->load->view('admin/dashboard');
        $this->load->view('templates/footer');
    }
    public function info($noinv)
    {
        $where = array('noinv' => $noinv);
        $data['wakaf'] = $this->M_wakaf->info($where, 'wakaf')->result();

        $this->load->view('templates/header');
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('info', $data);
        $this->load->view('admin/dashboard');
        $this->load->view('templates/footer');
    }
    function get_autocomplete()
    {
        if (isset($_GET['term'])) {
            $result = $this->M_wakaf->search_wakaf($_GET['term']);
            if (count($result) > 0) {
                foreach ($result as $row)
                    $arr_result[] = array(
                        'label' => $row->nama,
                        'hp' => $row->hp,
                        'jenis' => $row->jenis,
                    );
                echo json_encode($arr_result);
            }
        }
    }
}
