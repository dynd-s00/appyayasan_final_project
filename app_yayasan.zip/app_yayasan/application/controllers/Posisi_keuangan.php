<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Posisi_keuangan extends CI_Controller
 {
    public function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('username') != 'bendahara') {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <strong>Anda Harus login!</strong> 
        </div>');
            redirect('Auth');
        }
    }
        public function index()
        {
            $data['title'] = 'Yayasan ILQ | Laporan Kas';
            $this->load->model('M_buku_besar');
            $data['buku_111']= $this->M_buku_besar->tampil_pk_111()->result();   
            $data['buku_112']= $this->M_buku_besar->tampil_pk_112()->result(); 
            $data['buku_121']= $this->M_buku_besar->tampil_pk_121()->result(); 
            $data['buku_411']= $this->M_buku_besar->tampil_pk_411()->result(); 
            $data['buku_412']= $this->M_buku_besar->tampil_pk_412()->result(); 
            $data['buku_413']= $this->M_buku_besar->tampil_pk_413()->result(); 
            $data['buku_511']= $this->M_buku_besar->tampil_pk_511()->result(); 
            $data['buku_512']= $this->M_buku_besar->tampil_pk_512()->result();
            $data['buku_112']= $this->M_buku_besar->tampil_pk_112()->result(); 
            $data['buku_611']= $this->M_buku_besar->tampil_pk_611()->result(); 
            $this->load->view('templates/header',$data);
            $this->load->view('templates/body');  
            $this->load->view('templates/sidebar');
            $this->load->view('posisikeuangan',$data);
            $this->load->view('admin/dashboard');    
            $this->load->view('templates/footer');
        }
    
}