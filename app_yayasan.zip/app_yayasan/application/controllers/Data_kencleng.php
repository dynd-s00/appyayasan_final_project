<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Data_kencleng extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('M_kencleng');
        if ($this->session->userdata('username') != 'bendahara') {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <strong>Anda Harus login!</strong> 
        </div>');
            redirect('Auth');
        }
    }
    public function index()
    {
        $data['kencleng'] = $this->M_kencleng->tampil()->result();
        $data['kencleng'] = $this->M_kencleng->kencleng()->result();
        $data['kencleng'] = $this->M_kencleng->kenclengin()->result();
        $data['jemaah'] = $this->M_kencleng->jemaah()->result();
        $data['title'] = 'Yayasan ILQ | Data kencleng';
        $this->load->model('M_kencleng');
        $this->load->view('templates/header', $data);
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('data_kencleng', $data);
        $this->load->view('templates/footer');
    }
    public function bayar_kencleng()
    {
        $noinv = $this->autonumbr();
        $nama = $this->input->post('nama');
        $tgl = $this->input->post('tgl');
        $hp  = $this->input->post('hp');
        $kencleng  = $this->input->post('kencleng');
        $alamat = $this->input->post('alamat');
        $jenis = $this->input->post('jenis');
        $institusi = $this->input->post('institusi');
        $data = array(
            'noinv' => $noinv,
            'nama'  => $nama,
            'tgl' => $tgl,
            'hp' => $hp,
            'kencleng' => $kencleng,
            'alamat' => $alamat,
            'jenis' => $jenis,
            'institusi' => $institusi,
        );

        $this->M_kencleng->input($data, 'kencleng');
        //----- kode simpan jurnal   
        $data = array(
            'tgl'             =>  $tgl,
            'bukti'           => $noinv,
            'keterangan'      => 'kas',
            'ref'             => '111',
            'debit'           => $kencleng,
            'kredit'          => 0,
        );
        $this->M_kencleng->input_jurnal($data, 'jurnal_umum');
        //------------------------- simpan junal ke2
        $data = array(
            'tgl'             =>  $tgl,
            'bukti'           => $noinv,
            'keterangan'      => '&nbsp; &nbsp; Dana kencleng',
            'ref'             => '411',
            'debit'           => 0,
            'kredit'          => $kencleng,
        );
        $this->M_kencleng->input_ju($data, 'jurnal_umum');

        //---------- kode simpan buku besar
        $data = array(
            'kdakun'        => '111',
            'nmakun'        => 'kas',
            'tgl'           =>  $tgl,
            'keterangan'    =>  'Dana kencleng',
            'ref'           =>  '411',
            'debit'         =>  $kencleng,
            'kredit'        =>  '0',
        );
        $this->M_kencleng->input_BB($data, 'buku_besar');
        //---------- kode simpan buku besar ke2
        $data = array(
            'kdakun'        => '411',
            'nmakun'        => 'Dana kencleng',
            'tgl'           =>  $tgl,
            'keterangan'    =>  'kas',
            'ref'           =>  '111',
            'debit'         =>  '0',
            'kredit'        =>  $kencleng,
        );
        $this->M_kencleng->input_buku($data, 'buku_besar');
        redirect('Data_kencleng');
    }
    public function autonumbr()
    {
        $noinv = 'KC';
        $this->db->select('RIGHT(kencleng.noinv,2) as noinv', FALSE);
        $this->db->order_by('noinv', 'DESC');
        $this->db->limit(1);
        $sql = $this->db->get('kencleng');

        if ($sql->num_rows() <> 0) {
            $data = $sql->row();
            $autonumbr = intval($data->noinv) + 1;
        } else {
            $autonumbr = 1;
        }
        $limit = str_pad($autonumbr, 2, "0", STR_PAD_LEFT);
        $noinv = $noinv . $limit;
        return $noinv;
    }
    public function hapus($noinv)
    {
        $where = array('noinv' => $noinv);
        $this->M_kencleng->hapus_data($where, 'kencleng');
        redirect('Data_kencleng');
    }

    public function invoice($noinv)
    {
        $where = array('noinv' => $noinv);
        $data['kencleng'] = $this->M_kencleng->data($where, 'kencleng')->result();
        $data['title'] = 'Yayasan ILQ | Invoice kencleng';
        $this->load->view('templates/header', $data);
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('invoice', $data);
        $this->load->view('templates/footer');
    }
    public function info($noinv)
    {
        $where = array('noinv' => $noinv);
        $data['kencleng'] = $this->M_kencleng->info($where, 'kencleng')->result();

        $this->load->view('templates/header');
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('info', $data);
        $this->load->view('templates/footer');
    }
    function get_autocomplete()
    {
        if (isset($_GET['term'])) {
            $result = $this->M_kencleng->search_kencleng($_GET['term']);
            if (count($result) > 0) {
                foreach ($result as $row)
                    $arr_result[] = array(
                        'label' => $row->nama,
                        'hp' => $row->hp,
                        'alamat' => $row->alamat,
                        'jenis' => $row->jenis,
                        'institusi' => $row->institusi,
                        'tgl' => $row->tgl
                    );
                echo json_encode($arr_result);
            }
        }
    }
}
