<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Beranda extends CI_Controller
 {
    public function index()
    {
        //$data['user'] = $this->M_Biojemaah->user()->result();  
        $this->load->view('onepage/header');
        $this->load->view('onepage/navbar');
        $this->load->view('beranda');
        $this->load->view('onepage/footer');
        
        
    }
    public function History()
    {
        //$data['user'] = $this->M_Biojemaah->user()->result();  
        $this->load->view('onepage/header');
        $this->load->view('history');
        $this->load->view('onepage/footer');
    }
    public function gallery()
    {
        //$data['user'] = $this->M_Biojemaah->user()->result();  
        $this->load->view('onepage/header');
        $this->load->view('gallery');
        $this->load->view('onepage/footer');
        
        
    }
   
}