<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Biodata_jemaah extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('username') != 'bendahara') {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <strong>Anda Harus login!</strong> 
        </div>');
            redirect('Auth');
        }
    }
    public function index()
    {
        $data['jemaah'] = $this->M_Biojemaah->tampil()->result();
        $data['mentor'] = $this->M_Biojemaah->tampil_data()->result();
        $data['title'] = 'Yayasan ILQ | Data Master';
        $this->load->view('templates/header', $data);
        $this->load->view('templates/header');
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('jemaah', $data);
        $this->load->view('admin/dashboard');
        $this->load->view('templates/footer');
    }
    public function hapus($nik)
    {
        $where = array('nik' => $nik);
        $this->M_Biojemaah->hapus_data($where, 'jemaah');
        redirect('Biodata_jemaah/index');
    }

    public function logout()
    {
        $this->load->view('logout');
    }
    public function autonumbr()
    {
        $nij = '373';
        $this->db->select('RIGHT(jemaah.nij,1) as nij', FALSE);
        $this->db->order_by('nij', 'DESC');
        $this->db->limit(1);
        $sql = $this->db->get('jemaah');

        if ($sql->num_rows() <> 0) {
            $data = $sql->row();
            $autonumbr = intval($data->nij) + 1;
        } else {
            $autonumbr = 1;
        }
        $limit = str_pad($autonumbr, 5, "0", STR_PAD_LEFT);
        $nij = $nij . $limit;
        return $nij;
    }
    public function tambah_data()
    {
        $nij = $this->autonumbr();
        $nama = $this->input->post('nama');
        $jenis_kelamin = $this->input->post('jenis_kelamin');
        $tempat_lahir = $this->input->post('tempat_lahir');
        $tgl_lahir = $this->input->post('tgl_lahir');
        $nik = $this->input->post('nik');
        $alamat_jl = $this->input->post('alamat_jl');
        $alamat_rt = $this->input->post('alamat_rt');
        $alamat_kelurahan = $this->input->post('alamat_kelurahan');
        $alamat_kecamatan = $this->input->post('alamat_kecamatan');
        $alamat_kota = $this->input->post('alamat_kota');
        $no_hp = $this->input->post('no_hp');
        $pekerjaan = $this->input->post('pekerjaan');
        $motivasi = $this->input->post('motivasi');
        $mentor = $this->input->post('mentor');
        $fhq_privat = $this->input->post('fhq_privat');

        $data = array(
            'nij' => $nij,
            'nama' => $nama,
            'jenis_kelamin' => $jenis_kelamin,
            'tempat_lahir' => $tempat_lahir,
            'tgl_lahir' => $tgl_lahir,
            'nik' => $nik,
            'alamat_jl' => $alamat_jl,
            'alamat_rt' => $alamat_rt,
            'alamat_kelurahan' => $alamat_kelurahan,
            'alamat_kecamatan' => $alamat_kecamatan,
            'alamat_kota' => $alamat_kota,
            'no_hp' => $no_hp,
            'pekerjaan' => $pekerjaan,
            'motivasi' => $motivasi,
            'mentor' => $mentor,
            'fhq_privat' => $fhq_privat,

        );
        $this->M_Biojemaah->insert_data($data, 'jemaah');

        redirect('Biodata_jemaah/index');
    }
    public function edit($nik)
    {
        $where = array('nik' => $nik);
        $data['jemaah'] = $this->M_Biojemaah->edit_data($where, 'jemaah')->result();
        $data['mentor'] = $this->M_Biojemaah->edit_data_mentor($where, 'mentor')->result();

        $this->load->view('templates/header');
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('edit', $data);
        $this->load->view('admin/dashboard');
        $this->load->view('templates/footer');
    }
    public function update()
    {
        $nama = $this->input->post('nama');
        $jenis_kelamin = $this->input->post('jenis_kelamin');
        $tempat_lahir = $this->input->post('tempat_lahir');
        $tgl_lahir = $this->input->post('tgl_lahir');
        $nik = $this->input->post('nik');
        $alamat_jl = $this->input->post('alamat_jl');
        $alamat_rt = $this->input->post('alamat_rt');
        $alamat_kelurahan = $this->input->post('alamat_kelurahan');
        $alamat_kecamatan = $this->input->post('alamat_kecamatan');
        $alamat_kota = $this->input->post('alamat_kota');
        $no_hp = $this->input->post('no_hp');
        $pekerjaan = $this->input->post('pekerjaan');
        $motivasi = $this->input->post('motivasi');
        $mentor = $this->input->post('mentor');
        $fhq_privat = $this->input->post('fhq_privat');

        $data = array(
            'nama' => $nama,
            'jenis_kelamin' => $jenis_kelamin,
            'tempat_lahir' => $tempat_lahir,
            'tgl_lahir' => $tgl_lahir,
            'nik' => $nik,
            'alamat_jl' => $alamat_jl,
            'alamat_rt' => $alamat_rt,
            'alamat_kelurahan' => $alamat_kelurahan,
            'alamat_kecamatan' => $alamat_kecamatan,
            'alamat_kota' => $alamat_kota,
            'no_hp' => $no_hp,
            'pekerjaan' => $pekerjaan,
            'motivasi' => $motivasi,
            'mentor' => $mentor,
            'fhq_privat' => $fhq_privat,

        );
        $where = array(
            'nik' => $nik,
        );
        $this->M_Biojemaah->update_data($where, $data, 'jemaah');
        redirect('Biodata_jemaah/index');
    }
}
