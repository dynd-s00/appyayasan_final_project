<?php


class Ketua extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('username') != 'ketua') {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Anda Harus Login!
                     <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                   </div>');
            redirect('Auth');
        }
    }
    public function index()
    {
        $data['title'] = 'Yayasan ILQ | Laporan Ketua';
        $this->load->view('templates/header_ketua',$data);
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar_ketua');
        $this->load->view('dashboard');
        $this->load->view('templates/footer');
    }
}
