<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pembayaran extends CI_Controller
{
    public function index()
    {
        $this->load->view('templates/header');
        $this->load->view('templates/body');
        $this->load->view('pembayaran');
        $this->load->view('templates/footer');
    }
    public function autonumbr()
    {
        $noinv = 'ZA001';
        $this->db->select('RIGHT(zakat.noinv,2) as noinv', FALSE);
        $this->db->order_by('noinv', 'DESC');
        $this->db->limit(1);
        $sql = $this->db->get('zakat');

        if ($sql->num_rows() <> 0) {
            $data = $sql->row();
            $autonumbr = intval($data->noinv) + 1;
        } else {
            $autonumbr = 1;
        }
        $limit = str_pad($autonumbr, 2, "0", STR_PAD_LEFT);
        $noinv = $noinv . $limit;
        return $noinv;
    }
    public function Zakat()
    {
        
        $this->load->view('templates/header');
        $this->load->view('templates/body');
        $this->load->view('zakat');
        $this->load->view('templates/footer');
    }
    public function bayar_zakat()
    {
        $noinv = $this->autonumbr();
        $nama = $this->input->post('nama');
        $tgl = $this->input->post('tgl');
        $penghasilan = $this->input->post('penghasilan');
        $zakat  = $this->input->post('zakat');
        $data = array(
            'noinv' => $noinv,
            'nama'  => $nama,
            'tgl' => $tgl,
            'penghasilan' => $penghasilan,
            'zakat' => $penghasilan*0.025,
        );
        $this->M_zakat->input($data, 'zakat');

        //----- kode simpan jurnal   
        $data = array(
            'tgl'             =>  $tgl,
            'bukti'           => $noinv,
            'keterangan'      => 'kas',
            'ref'             => '111',
            'debit'           => $zakat,
            'kredit'          => 0,
        );
        $this->M_zakat->input_jurnal($data, 'jurnal_umum');
        //------------------------- simpan junal ke2
        $data = array(
            'tgl'             =>  $tgl,
            'bukti'           => $noinv,
            'keterangan'      => '&nbsp; &nbsp; Dana zakat',
            'ref'             => '411',
            'debit'           => 0,
            'kredit'          => $zakat,
        );
        $this->M_zakat->input_ju($data, 'jurnal_umum');

        //---------- kode simpan buku besar
        $data = array(
            'kdakun'        => '111',
            'nmakun'        => 'kas',
            'tgl'           =>  $tgl,
            'keterangan'    =>  'Dana zakat',
            'ref'           =>  '411',
            'debit'         =>  $zakat,
            'kredit'        =>  '0',
        );
        $this->M_zakat->input_BB($data, 'buku_besar');
        //---------- kode simpan buku besar ke2
        $data = array(
            'kdakun'        => '411',
            'nmakun'        => 'Dana Zakat',
            'tgl'           =>  $tgl,
            'keterangan'    =>  'kas',
            'ref'           =>  '111',
            'debit'         =>  '0',
            'kredit'        =>  $zakat,
        );
        $this->M_zakat->input_buku($data, 'buku_besar');


        redirect('Pembayaran');
    }

    //-----------PEMBAYARAN INFAK 

    public function Infak()
    {

        $this->load->view('templates/header');
        $this->load->view('templates/body');
        $this->load->view('infak');
        $this->load->view('templates/footer');
    }
    public function autonumber()
    {
        $noinv = 'IN001';
        $this->db->select('RIGHT(infak.noinv,2) as noinv', FALSE);
        $this->db->order_by('noinv', 'DESC');
        $this->db->limit(1);
        $sql = $this->db->get('infak');

        if ($sql->num_rows() <> 0) {
            $data = $sql->row();
            $autonumber = intval($data->noinv) + 1;
        } else {
            $autonumber = 1;
        }
        $limit = str_pad($autonumber, 2, "0", STR_PAD_LEFT);
        $noinv = $noinv . $limit;
        return $noinv;
    }
    public function bayar_infak()
    {
        $noinv = $this->autonumber();
        $nama = $this->input->post('nama');
        $tgl = $this->input->post('tgl');
        $infak = $this->input->post('infak');
        $data = array(
            'noinv'  => $noinv,
            'nama'  => $nama,
            'tgl' => $tgl,
            'infak' => $infak,
        );
        $this->M_infak->input($data, 'infak');

        //----- kode simpan jurnal   
        $data = array(
            'tgl'             =>  $tgl,
            'bukti'           => $noinv,
            'keterangan'      => 'kas',
            'ref'             => '111',
            'debit'           => $infak,
            'kredit'          => 0,
        );
        $this->M_infak->input_jurnal($data, 'jurnal_umum');
        //------------------------- simpan junal ke2
        $data = array(
            'tgl'             =>  $tgl,
            'bukti'           => $noinv,
            'keterangan'      => '&nbsp; &nbsp; Dana infak',
            'ref'             => '412',
            'debit'           => 0,
            'kredit'          => $infak,
        );
        $this->M_infak->input_ju($data, 'jurnal_umum');

        //---------- kode simpan buku besar
        $data = array(
            'kdakun'        => '111',
            'nmakun'        => 'kas',
            'tgl'           =>  $tgl,
            'keterangan'    =>  'Dana infak',
            'ref'           =>  '412',
            'debit'         =>  $infak,
            'kredit'        =>  '0',
        );
        $this->M_infak->input_BB($data, 'buku_besar');
        //---------- kode simpan buku besar ke2
        $data = array(
            'kdakun'        => '412',
            'nmakun'        => 'Dana infak',
            'tgl'           =>  $tgl,
            'keterangan'    =>  'kas',
            'ref'           =>  '111',
            'debit'         =>  '0',
            'kredit'        =>  $infak,
        );
        $this->M_infak->input_buku($data, 'buku_besar');


        redirect('Pembayaran/infak');
    }


    //-----------PEMBAYARAN SEDEKAH 

    public function Sedekah()
    {

        $this->load->view('templates/header');
        $this->load->view('templates/body');
        $this->load->view('sedekah');
        $this->load->view('templates/footer');
    }
    public function autonum()
    {
        $noinv = 'SD001';
        $this->db->select('RIGHT(sedekah.noinv,2) as noinv', FALSE);
        $this->db->order_by('noinv', 'DESC');
        $this->db->limit(1);
        $sql = $this->db->get('sedekah');

        if ($sql->num_rows() <> 0) {
            $data = $sql->row();
            $autonumber = intval($data->noinv) + 1;
        } else {
            $autonumber = 1;
        }
        $limit = str_pad($autonumber, 2, "0", STR_PAD_LEFT);
        $noinv = $noinv . $limit;
        return $noinv;
    }
    public function bayar_sedekah()
    {
        $noinv = $this->autonum();
        $nama = $this->input->post('nama');
        $tgl = $this->input->post('tgl');
        $sedekah = $this->input->post('sedekah');
        $data = array(
            'noinv'  => $noinv,
            'nama'  => $nama,
            'tgl' => $tgl,
            'sedekah' => $sedekah,
        );
        $this->M_sedekah->input($data, 'sedekah');

        //----- kode simpan jurnal   
        $data = array(
            'tgl'             =>  $tgl,
            'bukti'           => $noinv,
            'keterangan'      => 'kas',
            'ref'             => '111',
            'debit'           => $sedekah,
            'kredit'          => 0,
        );
        $this->M_sedekah->input_jurnal($data, 'jurnal_umum');
        //------------------------- simpan junal ke2
        $data = array(
            'tgl'             =>  $tgl,
            'bukti'           => $noinv,
            'keterangan'      => '&nbsp; &nbsp; Dana sedekah',
            'ref'             => '413',
            'debit'           => 0,
            'kredit'          => $sedekah,
        );
        $this->M_sedekah->input_ju($data, 'jurnal_umum');

        //---------- kode simpan buku besar
        $data = array(
            'kdakun'        => '111',
            'nmakun'        => 'kas',
            'tgl'           =>  $tgl,
            'keterangan'    =>  'Dana sedekah',
            'ref'           =>  '413',
            'debit'         =>  $sedekah,
            'kredit'        =>  '0',
        );
        $this->M_sedekah->input_BB($data, 'buku_besar');
        //---------- kode simpan buku besar ke2
        $data = array(
            'kdakun'        => '413',
            'nmakun'        => 'Dana sedekah',
            'tgl'           =>  $tgl,
            'keterangan'    =>  'kas',
            'ref'           =>  '111',
            'debit'         =>  '0',
            'kredit'        =>  $sedekah,
        );
        $this->M_sedekah->input_buku($data, 'buku_besar');


        redirect('Pembayaran/sedekah');
    }

    //-----------PEMBAYARAN DONASI

    public function Donasi()
    {

        $this->load->view('templates/header');
        $this->load->view('templates/body');
        $this->load->view('donasi');
        $this->load->view('templates/footer');
    }
    public function autono()
    {
        $noinv = 'DS001';
        $this->db->select('RIGHT(donasi.noinv,2) as noinv', FALSE);
        $this->db->order_by('noinv', 'DESC');
        $this->db->limit(1);
        $sql = $this->db->get('donasi');

        if ($sql->num_rows() <> 0) {
            $data = $sql->row();
            $autono = intval($data->noinv) + 1;
        } else {
            $autono = 1;
        }
        $limit = str_pad($autono, 2, "0", STR_PAD_LEFT);
        $noinv = $noinv . $limit;
        return $noinv;
    }
    public function bayar_donasi()
    {
        $noinv = $this->autono();
        $nama = $this->input->post('nama');
        $tgl = $this->input->post('tgl');
        $donasi = $this->input->post('donasi');
        $data = array(
            'noinv'  => $noinv,
            'nama'  => $nama,
            'tgl' => $tgl,
            'donasi' => $donasi,
        );
        $this->M_donasi->input($data, 'donasi');

        //----- kode simpan jurnal   
        $data = array(
            'tgl'             =>  $tgl,
            'bukti'           => $noinv,
            'keterangan'      => 'kas',
            'ref'             => '111',
            'debit'           => $donasi,
            'kredit'          => 0,
        );
        $this->M_donasi->input_jurnal($data, 'jurnal_umum');
        //------------------------- simpan junal ke2
        $data = array(
            'tgl'             =>  $tgl,
            'bukti'           => $noinv,
            'keterangan'      => '&nbsp; &nbsp; Dana donasi',
            'ref'             => '414',
            'debit'           => 0,
            'kredit'          => $donasi,
        );
        $this->M_donasi->input_ju($data, 'jurnal_umum');

        //---------- kode simpan buku besar
        $data = array(
            'kdakun'        => '111',
            'nmakun'        => 'kas',
            'tgl'           =>  $tgl,
            'keterangan'    =>  'Dana donasi',
            'ref'           =>  '414',
            'debit'         =>  $donasi,
            'kredit'        =>  '0',
        );
        $this->M_donasi->input_BB($data, 'buku_besar');
        //---------- kode simpan buku besar ke2
        $data = array(
            'kdakun'        => '414',
            'nmakun'        => 'Dana donasi',
            'tgl'           =>  $tgl,
            'keterangan'    =>  'kas',
            'ref'           =>  '111',
            'debit'         =>  '0',
            'kredit'        =>  $donasi,
        );
        $this->M_donasi->input_buku($data, 'buku_besar');


        redirect('Pembayaran/donasi');
    }
}
