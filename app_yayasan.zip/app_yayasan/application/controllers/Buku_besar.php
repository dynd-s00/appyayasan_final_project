<?php

class Buku_besar extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('username') != 'bendahara') {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <strong>Anda Harus login!</strong> 
        </div>');
            redirect('Auth');
        }
    }
    public function index()
    {
        $data['title'] = 'Yayasan ILQ | Buku besar';
        $this->load->model('M_buku_besar');
        $data['buku_111'] = $this->M_buku_besar->tampil_bb_111()->result();
        $data['buku_112'] = $this->M_buku_besar->tampil_bb_112()->result();
        $data['buku_121'] = $this->M_buku_besar->tampil_bb_121()->result();
        $data['buku_411'] = $this->M_buku_besar->tampil_bb_411()->result();
        $data['buku_412'] = $this->M_buku_besar->tampil_bb_412()->result();
        $data['buku_413'] = $this->M_buku_besar->tampil_bb_413()->result();
        $data['buku_414'] = $this->M_buku_besar->tampil_bb_414()->result();
        $data['buku_511'] = $this->M_buku_besar->tampil_bb_511()->result();
        $data['buku_512'] = $this->M_buku_besar->tampil_bb_512()->result();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('buku_besar', $data);
        $this->load->view('admin/dashboard');
        $this->load->view('templates/footer');
    }

    public function bulan()
    {
        $data['title'] = 'Yayasan ILQ | PEeriode Buku besar bulanan';
        $this->load->model('M_buku_besar');
        $data['buku_111'] = $this->M_buku_besar->bln_bb_111()->result();
        $data['buku_112'] = $this->M_buku_besar->bln_bb_112()->result();
        $data['buku_121'] = $this->M_buku_besar->bln_bb_121()->result();
        $data['buku_411'] = $this->M_buku_besar->bln_bb_411()->result();
        $data['buku_412'] = $this->M_buku_besar->bln_bb_412()->result();
        $data['buku_413'] = $this->M_buku_besar->bln_bb_413()->result();
        $data['buku_511'] = $this->M_buku_besar->bln_bb_511()->result();
        $data['buku_512'] = $this->M_buku_besar->bln_bb_512()->result();
        $data['buku_513'] = $this->M_buku_besar->bln_bb_513()->result();
        $data['buku_611'] = $this->M_buku_besar->bln_bb_611()->result();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('bb_bulan', $data);
        $this->load->view('admin/dashboard');
        $this->load->view('templates/footer');
    }
    public function tahun()
    {
        $data['title'] = 'Yayasan ILQ | Periode Buku besar tahunan';
        $this->load->model('M_buKu_besar');
        $data['buku_111'] = $this->M_buku_besar->thn_bb_111()->result();
        $data['buku_112'] = $this->M_buku_besar->thn_bb_112()->result();
        $data['buku_121'] = $this->M_buku_besar->thn_bb_121()->result();
        $data['buku_411'] = $this->M_buku_besar->thn_bb_411()->result();
        $data['buku_412'] = $this->M_buku_besar->thn_bb_412()->result();
        $data['buku_413'] = $this->M_buku_besar->thn_bb_413()->result();
        $data['buku_511'] = $this->M_buku_besar->thn_bb_511()->result();
        $data['buku_512'] = $this->M_buku_besar->thn_bb_512()->result();
        $data['buku_513'] = $this->M_buku_besar->thn_bb_513()->result();
        $data['buku_611'] = $this->M_buku_besar->thn_bb_611()->result();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('bb_tahun', $data);
        $this->load->view('admin/dashboard');
        $this->load->view('templates/footer');
    }
    public function print_bb($tgl)
    {
        $data['title'] = 'Yayasan ILQ | Print Buku besar';
        $this->load->model('M_buku_besar');
        $where = array('tgl' => $tgl);
        $data['buku_111'] = $this->M_buku_besar->tampil_bb_111($where, 'buku_besar')->result();
        $data['buku_411'] = $this->M_buku_besar->tampil_bb_411($where, 'buku_besar')->result();
        $data['buku_412'] = $this->M_buku_besar->tampil_bb_412($where, 'buku_besar')->result();
        $data['buku_413'] = $this->M_buku_besar->tampil_bb_413($where, 'buku_besar')->result();
        $data['buku_511'] = $this->M_buku_besar->tampil_bb_511($where, 'buku_besar')->result();
        $data['buku_512'] = $this->M_buku_besar->tampil_bb_512($where, 'buku_besar')->result();
        $data['buku_112'] = $this->M_buku_besar->tampil_bb_112($where, 'buku_besar')->result();
        $data['buku_121'] = $this->M_buku_besar->tampil_bb_121($where, 'buku_besar')->result();
        $this->load->view('print_bb', $data);
    }

    /*  public function laporan_bb()
	{
        $data['title'] = 'Yayasan ILQ | Buku Besar';
        $this->load->model('M_buku_besar');
        $data['buku_111']= $this->M_buku_besar->tampil_bb_111()->result();   
        $data['buku_411'] = $this->M_buku_besar->tampil_bb_411()->result();
        $data['buku_412'] = $this->M_buku_besar->tampil_bb_412()->result();
        $data['buku_413'] = $this->M_buku_besar->tampil_bb_413()->result();
        $data['buku_414'] = $this->M_buku_besar->tampil_bb_414()->result();
        $data['buku_511'] = $this->M_buku_besar->tampil_bb_511()->result();
        $data['buku_512'] = $this->M_buku_besar->tampil_bb_512()->result();
        $data['buku_112'] = $this->M_buku_besar->tampil_bb_112()->result();
        $this->load->view('templates/header',$data);
        $this->load->view('templates/body');  
        $this->load->view('templates/sidebar');
        $this->load->view('buku_besar',$data);
        $this->load->view('admin/dashboard');    
        $this->load->view('templates/footer');
    }
*/
}
