<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pengeluaran extends CI_Controller
{
    public function index()
    {
        $data['kas_keluar'] = $this->M_kas_keluar->tampil()->result();
        $data['pengeluaran'] = $this->M_kas_keluar->tampil_data()->result();
        $this->load->view('templates/header');
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('pengeluaran_kas',$data);
        $this->load->view('admin/dashboard');
        $this->load->view('templates/footer');
    }
    public function autonumbr()
    {
        $nobukti = 'L001P';
        $this->db->select('RIGHT(kas_keluar.nobukti,2) as nobukti', FALSE);
        $this->db->order_by('nobukti', 'DESC');
        $this->db->limit(1);
        $sql = $this->db->get('kas_keluar');

        if ($sql->num_rows() <> 0) {
            $data = $sql->row();
            $autonumbr = intval($data->nobukti) + 1;
        } else {
            $autonumbr = 1;
        }
        $limit = str_pad($autonumbr, 2, "0", STR_PAD_LEFT);
        $nobukti = $nobukti . $limit;
        return $nobukti;
    }
    public function kas_keluar()
    {
        $nobukti = $this->autonumbr();
        $tgl = $this->input->post('tgl');
        $nominal  = $this->input->post('nominal');
        $pengeluaran = $this->input->post('pengeluaran');

        $data = array(
            'nobukti' => $nobukti,
            'tgl' => $tgl,
            'nominal' => $nominal,
            'pengeluaran' => $pengeluaran,


        );
        $this->M_kas_keluar->input($data, 'kas_keluar');

        //----- kode simpan jurnal   
        $data = array(
            'tgl'             =>  $tgl,
            'bukti'           => $nobukti,
            'keterangan'      => $pengeluaran,
            'ref'             => '511',
            'debit'           => $nominal,
            'kredit'          => 0,
        );
        $this->M_kas_keluar->input_jurnal($data, 'jurnal_umum');
        //------------------------- simpan junal ke2
        $data = array(
            'tgl'             =>  $tgl,
            'bukti'           => $nobukti,
            'keterangan'      => '&nbsp; &nbsp; Kas',
            'ref'             => '111',
            'debit'           => 0,
            'kredit'          => $nominal,
        );
        $this->M_kas_keluar->input_ju($data, 'jurnal_umum');

        //---------- kode simpan buku besar
        $data = array(
            'kdakun'        => '511', 
            'nmakun'        => 'beban listrik',
            'tgl'           =>  $tgl,
            'keterangan'    =>  'kas',
            'ref'           =>  '111',
            'debit'         =>  $nominal,
            'kredit'        =>  '0',
        );
        $this->M_kas_keluar->input_BB($data, 'buku_besar');
        //---------- kode simpan buku besar ke2
        $data = array(
            'kdakun'        => '111',
            'nmakun'        => 'kas',
            'tgl'           =>  $tgl,
            'keterangan'    =>  'beban',
            'ref'           =>  '511',
            'debit'         =>  '0',
            'kredit'        =>  $nominal,
        );
        $this->M_kas_keluar->input_buku($data, 'buku_besar');


        redirect('pengeluaran/index');
    }

  
}
