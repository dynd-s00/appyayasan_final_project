<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auto extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('m_auto'); 
    }
    var $title = 'autocomplete';
    public function index()
    {
        $data['title'] = $this->title;
        $data['jemaah'] = $this->M_zakat->jemaah()->result();
        $this->load->view('templates/header');
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('auto', $data);
        $this->load->view('admin/dashboard');
        $this->load->view('templates/footer');
    }
     function get_autocomplete()
     {
         if(isset($_GET['term'])){
             $result = $this->m_auto->get_jemaah($_GET['term']);
             if (count($result) > 0){
                 foreach ($result as $row)
                 $result_array[] = $row->nama;
                 echo json_encode($result_array);
             }
         }
     }
   
}
 