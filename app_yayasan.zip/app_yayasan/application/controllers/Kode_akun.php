<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kode_akun extends CI_Controller
{
    public function index()
    {
        $data['title'] = 'Yayasan ILQ | Kode Akun';
        $data['akun'] = $this->M_kode->tampilkan()->result();
        $this->load->view('templates/header',$data);
        $this->load->view('templates/body');  
        $this->load->view('templates/sidebar');
        $this->load->view('kode_akun',$data);
        $this->load->view('admin/dashboard');    
        $this->load->view('templates/footer');
    }
}
