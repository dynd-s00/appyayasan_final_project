<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Data_donasi extends CI_Controller
{
    
    function __construct()
    {
        parent::__construct();
        $this->load->model('M_donasi');
        if ($this->session->userdata('username') != 'bendahara') {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <strong>Anda Harus login!</strong> 
        </div>');
            redirect('Auth');
        }
    }
    public function index()
    {
        $data['donasi'] = $this->M_donasi->tampil()->result();
        $data['donasi'] = $this->M_donasi->donasi()->result();
        $data['title'] = 'Yayasan ILQ | Data donasi';
        $this->load->model('M_donasi');
        $this->load->view('templates/header', $data);
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('data_donasi', $data);
        $this->load->view('templates/footer');
    }
    public function bayar_donasi()
    {
        $noinv = $this->autonumbr();
        $nama = $this->input->post('nama');
        $tgl = $this->input->post('tgl');
        $hp  = $this->input->post('hp');
        $donasi  = $this->input->post('donasi');
        $jenis = $this->input->post('jenis');

        $data = array(
            'noinv' => $noinv,
            'nama'  => $nama,
            'tgl' => $tgl,
            'hp' => $hp,
            'donasi' => $donasi,
            'jenis' => $jenis,
        );
        $this->M_donasi->input($data, 'donasi');

        //----- kode simpan jurnal   
        $data = array(
            'tgl'             =>  $tgl,
            'bukti'           => $noinv,
            'keterangan'      => 'kas',
            'ref'             => '111',
            'debit'           => $donasi,
            'kredit'          => 0,
        );
        $this->M_donasi->input_jurnal($data, 'jurnal_umum');
        //------------------------- simpan junal ke2
        $data = array(
            'tgl'             =>  $tgl,
            'bukti'           => $noinv,
            'keterangan'      => '&nbsp; &nbsp; Dana donasi',
            'ref'             => '412',
            'debit'           => 0,
            'kredit'          => $donasi,
        );
        $this->M_donasi->input_ju($data, 'jurnal_umum');

        //---------- kode simpan buku besar
        $data = array(
            'kdakun'        => '111',
            'nmakun'        => 'kas',
            'tgl'           =>  $tgl,
            'keterangan'    =>  'Dana donasi',
            'ref'           =>  '412',
            'debit'         =>  $donasi,
            'kredit'        =>  '0',
        );
        $this->M_donasi->input_BB($data, 'buku_besar');
        //---------- kode simpan buku besar ke2
        $data = array(
            'kdakun'        => '412',
            'nmakun'        => 'Dana donasi',
            'tgl'           =>  $tgl,
            'keterangan'    =>  'kas',
            'ref'           =>  '111',
            'debit'         =>  '0',
            'kredit'        =>  $donasi,
        );
        $this->M_donasi->input_buku($data, 'buku_besar');


        redirect('Data_donasi/index');
    }
    public function autonumbr()
    {
        $noinv = 'DOBM';
        $this->db->select('RIGHT(donasi.noinv,2) as noinv', FALSE);
        $this->db->order_by('noinv', 'DESC');
        $this->db->limit(1);
        $sql = $this->db->get('donasi');

        if ($sql->num_rows() <> 0) {
            $data = $sql->row();
            $autonumbr = intval($data->noinv) + 1;
        } else {
            $autonumbr = 1;
        }
        $limit = str_pad($autonumbr, 2, "0", STR_PAD_LEFT);
        $noinv = $noinv . $limit;
        return $noinv;
    }
    public function hapus($noinv)
    {
        $where = array('noinv' => $noinv);
        $this->M_donasi->hapus_data($where, 'donasi');
        redirect('Data_donasi/index');
    }

    public function invoicedonasi($noinv)
    {
        $where = array('noinv' => $noinv);
        $data['donasi'] = $this->M_donasi->data($where, 'donasi')->result();
        $data['title'] = 'Yayasan ILQ | Invoice donasi';
        $this->load->view('templates/header',$data);
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('invoice_donasi', $data);
        $this->load->view('admin/dashboard');
        $this->load->view('templates/footer');
    }
    public function info($noinv)
    {
        $where = array('noinv' => $noinv);
        $data['donasi'] = $this->M_donasi->info($where, 'donasi')->result();

        $this->load->view('templates/header');
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('info', $data);
        $this->load->view('admin/dashboard');
        $this->load->view('templates/footer');
    }
    function get_autocomplete()
    {
        if (isset($_GET['term'])) {
            $result = $this->M_donasi->search_donasi($_GET['term']);
            if (count($result) > 0) {
                foreach ($result as $row)
                    $arr_result[] = array(
                        'label' => $row->nama,
                        'hp' => $row->hp,
                        'jenis' => $row->jenis,

                    );
                echo json_encode($arr_result);
            }
        }
    }
}
