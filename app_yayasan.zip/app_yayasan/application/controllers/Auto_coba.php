<?php
class Auto_coba extends CI_Controller{
    function __construct(){
        parent::__construct();
        $this->load->model('auto_model');
    }
 
    function index(){
        $this->load->view('auto_coba');
    }
 
    function get_autocomplete(){
        if (isset($_GET['term'])) {
            $result = $this->auto_model->search_blog($_GET['term']);
            if (count($result) > 0) {
            foreach ($result as $row)
                $arr_result[] = array(
                    'label' =>$row->nama,
                    'nohp' => $row->hp,
                );
                echo json_encode($arr_result);
            }
        }
    }
 
}