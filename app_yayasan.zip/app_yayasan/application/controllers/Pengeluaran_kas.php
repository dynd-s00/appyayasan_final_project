<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pengeluaran_kas extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('M_pengeluaran_kas');
        if ($this->session->userdata('username') != 'bendahara') {
            $this->session->set_flashdata('pesan','<div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <strong>Anda Harus login!</strong> 
        </div>');
            redirect('Auth');
        }
    }
    public function index()
    {
        $this->load->model('M_pengeluaran_kas');
        $data['pengeluaran_kas'] = $this->M_pengeluaran_kas->tampil()->result();
        
        $data['title'] = 'Yayasan ILQ | Pengeluaran kas';
        $this->load->view('templates/header',$data);
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('pengeluaran_kas', $data);
        $this->load->view('admin/dashboard');
        $this->load->view('templates/footer');
    }
    public function autonumbr()
    {
        $nobukti = 'KASBK';
        $this->db->select('RIGHT(pengeluaran_kas.nobukti,2) as nobukti', FALSE);
        $this->db->order_by('nobukti', 'DESC');
        $this->db->limit(1);
        $sql = $this->db->get('pengeluaran_kas');

        if ($sql->num_rows() <> 0) {
            $data = $sql->row();
            $autonumbr = intval($data->nobukti) + 1;
        } else {
            $autonumbr = 1;
        }
        $limit = str_pad($autonumbr, 2, "0", STR_PAD_LEFT);
        $nobukti = $nobukti . $limit;
        return $nobukti;
    }
    public function penyaluran_kas()
    {
        $nobukti = $this->autonumbr();
        $tgl = $this->input->post('tgl');
        $jumlah  = $this->input->post('jumlah');
        $keterangan = $this->input->post('nama');
        $ref =$this->input->post('ref');

        $data = array(
            'nobukti' => $nobukti,
            'tgl' => $tgl,
            'jumlah' => $jumlah,
            'keterangan' => $keterangan,
            'ref' => $ref,

        );
        $this->M_pengeluaran_kas->input($data, 'pengeluaran_kas');

        //----- kode simpan jurnal   
        $data = array(
            'tgl'             =>  $tgl,
            'bukti'           => $nobukti,
            'keterangan'      => $keterangan,
            'ref'             => $ref,
            'debit'           => $jumlah,
            'kredit'          => 0,
        );
        $this->M_pengeluaran_kas->input_jurnal($data, 'jurnal_umum');
        //------------------------- simpan junal ke2
        $data = array(
            'tgl'             =>  $tgl,
            'bukti'           => $nobukti,
            'keterangan'      => '&nbsp; &nbsp; Kas',
            'ref'             => '111',
            'debit'           => 0,
            'kredit'          => $jumlah,
        );
        $this->M_pengeluaran_kas->input_ju($data, 'jurnal_umum');

        //---------- kode simpan buku besar
        $data = array(
            'kdakun'        => $ref,
            'nmakun'        => $keterangan,
            'tgl'           =>  $tgl,
            'keterangan'    =>  'kas',
            'ref'           =>  '111',
            'debit'         =>  $jumlah,
            'kredit'        =>  '0',
        );
        $this->M_pengeluaran_kas->input_BB($data, 'buku_besar');
        //---------- kode simpan buku besar ke2
        $data = array(
            'kdakun'        => '111',
            'nmakun'        => 'kas',
            'tgl'           =>  $tgl,
            'keterangan'    =>  $keterangan,
            'ref'           =>  $ref,
            'debit'         =>  '0',
            'kredit'        =>  $jumlah,
        );
        $this->M_pengeluaran_kas->input_buku($data, 'buku_besar');


        redirect('pengeluaran_kas');
    }
    public function hapus($nobukti)
    {
        $where = array('nobukti' => $nobukti);
        $this->M_pengeluaran_kas->hapus_data($where, 'pengeluaran_kas');
        redirect('Pengeluaran_kas');
    }
    public function invoice_pengeluaran($nobukti)
    {
        $where = array('nobukti' => $nobukti);
        $data['pengeluaran_kas'] = $this->M_pengeluaran_kas->data($where, 'pengeluaran_kas')->result();

        $this->load->view('templates/header');
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('invoice_pengeluaran', $data);
        $this->load->view('admin/dashboard');
        $this->load->view('templates/footer');
    }
    public function info($nobukti)
    {
        $where = array('nobukti' => $nobukti);
        $data['pengeluaran_kas'] = $this->M_pengeluaran_kas->info($where, 'pengeluaran_kas')->result();

        $this->load->view('templates/header');
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar');
        $this->load->view('info', $data);
        $this->load->view('admin/dashboard');
        $this->load->view('templates/footer');
    }
    function get_autocomplete()
    {
        if (isset($_GET['term'])) {
            $result = $this->M_pengeluaran_kas->search_akun($_GET['term']);
            if (count($result) > 0) {
                foreach ($result as $row)
                    $arr_result[] = array(
                        'label' => $row->nama,
                        'ref' => $row->ref,
                    );
                echo json_encode($arr_result);
            }
        }
    }
}
