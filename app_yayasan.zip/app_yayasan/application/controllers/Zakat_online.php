<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Zakat_online extends CI_Controller
 {
    public function index()
    {
       
        $this->load->view('templates/header');
        $this->load->view('templates/body');
        $this->load->view('templates/sidebar_online');
        $this->load->view('zakat_online');
        $this->load->view('templates/footer');
        
    }
    
}