<?php

class Auth extends CI_Controller
{
    public function index()
    {

        $data['title'] = 'Yayasan ILQ | Log in';
        $this->load->view('sign_in', $data  );
    }
    public function proses_login()
    {

        $this->form_validation->set_rules(
            'username',
            'username',
            'required',
            [
                'required' => 'Username wajib diisi!'
            ]
        );
        $this->form_validation->set_rules(
            'password',
            'password',
            'required',
            [
                'required' => 'Password wajib diisi!'
            ]
        );
        if ($this->form_validation->run() == FALSE) {

            $data['title'] = 'Yayasan ILQ | Log in';
            $this->load->view('sign_in', $data  );
        } else {
            //validasi succes
            $this->_login();
        }
    }

    private function _login()
    {
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        /* $password = password_hash($this->input->post('password'), PASSWORD_DEFAULT);*/
        $user = $this->db->get_where('user', ['username' => $username]);

        $user = $username;
        $pass = $password;

        $cek = $this->M_sign->cek_login($user, $pass);

        if ($cek->num_rows() > 0) {

            foreach ($cek->result() as $ck) {
                $sess_data['username'] = $ck->username;
                $sess_data['password'] = $ck->password;

                $this->session->set_userdata($sess_data);
            }
            if ($sess_data['username'] == 'bendahara') {
                $data_user = $this->db->get_where('user', ['username' => $username]);
                foreach ($data_user->result() as $data) {
                    $session = array('username' => 'bendahara');
                    $this->session->set_userdata($session);
                }

                redirect('Biodata_jemaah');
            }
            if ($sess_data['username'] == 'ketua') {
                redirect('Ketua');
            } else {
                $this->session->set_flashdata('pesan', '<div class="panel-actions"><div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <strong>Username dan Kata sandi salah!</strong> 
            </div></div>');
                redirect('Auth');
            }
        } else {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <strong>username dan kata sandi anda!</strong> 
        </div>');
            redirect('Auth');
        }
    }
    public function logout()
    {
        $this->session->sess_destroy();
        redirect('Auth');
    }
}
