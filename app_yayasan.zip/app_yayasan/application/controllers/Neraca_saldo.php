<?php

class Neraca_saldo extends CI_Controller 
{
    public function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('username') != 'bendahara') {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <strong>Anda Harus login!</strong> 
        </div>');
            redirect('Auth');
        }
    }
	public function index()
	{
        $data['title'] = 'Yayasan ILQ | Neraca saldo';
        $this->load->model('M_buku_besar');
        $data['buku_111']= $this->M_buku_besar->tampil_tb_111()->result();   
        $data['buku_411']= $this->M_buku_besar->tampil_tb_411()->result(); 
        $data['buku_412']= $this->M_buku_besar->tampil_tb_412()->result(); 
        $data['buku_413']= $this->M_buku_besar->tampil_tb_413()->result(); 
        $data['buku_511']= $this->M_buku_besar->tampil_tb_511()->result(); 
        $data['buku_512']= $this->M_buku_besar->tampil_tb_512()->result(); 
        $data['buku_112'] = $this->M_buku_besar->tampil_tb_112()->result();
        $data['buku_611'] = $this->M_buku_besar->tampil_tb_611()->result();
		$this->load->view('templates/header',$data);
        $this->load->view('templates/body');  
        $this->load->view('templates/sidebar');
        $this->load->view('neraca_saldo',$data);
        $this->load->view('admin/dashboard');    
        $this->load->view('templates/footer');
    }
    public function print_neraca()
	{
        
        $data['buku_111']= $this->M_buku_besar->tampil_bb_111()->result();   
        $data['buku_411'] = $this->M_buku_besar->tampil_bb_411()->result();
        $data['buku_412'] = $this->M_buku_besar->tampil_bb_412()->result();
        $data['buku_413'] = $this->M_buku_besar->tampil_bb_413()->result();
        $data['buku_511'] = $this->M_buku_besar->tampil_bb_511()->result();
        $data['buku_512'] = $this->M_buku_besar->tampil_bb_512()->result();
        $data['buku_112'] = $this->M_buku_besar->tampil_tb_112()->result();
        $data['buku_611'] = $this->M_buku_besar->tampil_tb_611()->result();
        $this->load->view('print_neraca', $data); 
    }
    public function laporan_neraca()
	{
        $data['buku_111']= $this->M_buku_besar->tampil_tb_111()->result();   
        $data['buku_411']= $this->M_buku_besar->tampil_tb_411()->result(); 
        $data['buku_412']= $this->M_buku_besar->tampil_tb_412()->result(); 
        $data['buku_413']= $this->M_buku_besar->tampil_tb_413()->result(); 
        $data['buku_511']= $this->M_buku_besar->tampil_tb_511()->result(); 
        $data['buku_512']= $this->M_buku_besar->tampil_tb_512()->result(); 
        $data['buku_611'] = $this->M_buku_besar->tampil_tb_611()->result();
		$this->load->view('templates/header');
        $this->load->view('templates/body');  
        $this->load->view('templates/sidebar');
        $this->load->view('neraca_saldo',$data);
        $this->load->view('admin/dashboard');    
        $this->load->view('templates/footer');
    }
   

    
}
