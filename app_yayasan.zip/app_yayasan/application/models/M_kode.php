<?php
class M_kode extends CI_Model
{
    public function tampilkan()
    {
        $this->db->order_by('ref', 'ASC');
        return $this->db->get('akun');
    }
}