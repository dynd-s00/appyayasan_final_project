<?php

class m_auto extends CI_Model{

    public function get_jemaah($title)
    {
        $this->db->like('nama', $title, 'BOTH');
        $this->db->order_by('nama', 'asc');
        $this->db->limit(10);
        return $this->db->get('jemaah')->result();
    }
} 