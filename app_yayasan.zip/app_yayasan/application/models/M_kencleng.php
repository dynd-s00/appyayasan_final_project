<?php
class M_kencleng extends CI_Model
{
    
    public function input($data, $table)
    {  
         $this->db->insert('kencleng', $data);       
    }
    public function tampil()
    {
        return $this->db->get('kencleng');
    }
    public function tampildata()
    {
        return $this->db->get('kencleng');
    }
    public function jemaah()
    {
        return $this->db->get('jemaah');
    }
    public function kencleng()
    {
        return $this->db->get('kencleng');
    }
    public function kenclengin()
    {
        return $this->db->get('kencleng');
    }
    public function printkc($where,$table)
    {
        $this->db->where($where);
        return $this->db->get('kencleng');
    }
    public function print_jubln($where, $table)
    {
        $this->db->where($where);
        $this->db->order_by('tgl');
        return $this->db->get('jurnal_umum');
    }
    public function print_juthn()
    {
        $this->db->order_by('tgl');
        return $this->db->get('jurnal_umum');
    }
    public function tampil_data()
    {
        return $this->db->get('kencleng');
    }
    public function input_jurnal($data, $table)
    {    
         $this->db->insert('jurnal_umum', $data);               
    }
    public function input_ju($data, $table)
    {      
         $this->db->insert('jurnal_umum', $data);               
    }
    public function input_BB($data, $table)
    {    
         $this->db->insert('buku_besar', $data);               
    }
    public function input_buku($data, $table)
    {   
         $this->db->insert('buku_besar', $data);               
    }
    public function get_keyword($keyword)
    {
         $this->db->select('*');
         $this->db->from('jurnal_umum');
         $this->db->like('bukti', $keyword);
         return $this->db->get()->result();
    }
    public function data($where,$table)
    {
       return  $this->db->get_where($table, $where);
    }
    public function info($where,$table)
    {
       return  $this->db->get_where($table, $where); 
    }
    public function tampilkan()
    {
        return $this->db->get('jurnal_umum');
    }
    public function hapus_data ($where, $table)
    {
        $this->db->where($where);
        $this->db->delete($table);
    }
    function search_kencleng($title){
        $this->db->like('nama', $title , 'both');
        $this->db->order_by('nama', 'ASC');
        $this->db->limit(10);
        return $this->db->get('kencleng')->result();
    }
    public function showing()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
        }
        $sql = "SELECT * FROM jurnal_umum WHERE EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql);  
       
    }
    public function show()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
            $bln =$_GET['bln'];
        }
        $sql = "SELECT * FROM jurnal_umum WHERE EXTRACT(MONTH FROM tgl) = '$bln' AND EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql);  
       
    }
   
}

