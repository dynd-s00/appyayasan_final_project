<?php
class auto_model extends CI_Model{
 
    function search_blog($title){
        $this->db->like('nama', $title , 'both');
        $this->db->order_by('nama', 'ASC');
        $this->db->limit(10);
        return $this->db->get('zakat')->result();
    }
 
}