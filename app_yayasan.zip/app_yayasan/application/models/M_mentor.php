<?php
class M_mentor extends CI_Model
{
    public function tampil()
    {
        return $this->db->get('mentor');
    }
    public function user()
    {
        return $this->db->get('user');
    }
    public function tampil_data()
    {
        return $this->db->get('mentor');
    }
    public function hapus_data($where, $tabel)
    {
        $this->db->where($where);
        $this->db->delete($tabel);
    }
    public function edit_data_mentor($where, $tabel)
    {
        return $this->db->get_where($tabel, $where);
       
    }   
    public function update_data($where, $data, $tabel)
    {
        $this->db->where($where);
        $this->db->update($tabel, $data);
    }
    public function insert_data($data, $tabel)
    {
        $this->db->insert($tabel, $data);
    }
}
