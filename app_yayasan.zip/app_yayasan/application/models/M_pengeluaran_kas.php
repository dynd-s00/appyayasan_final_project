<?php
class M_pengeluaran_kas extends CI_Model
{

     public function input($data, $table)
     {
          $this->db->insert('pengeluaran_kas', $data);
     }
     public function tampil()
     {
          return $this->db->get('pengeluaran_kas');
     }
     public function pengeluaran_kas()
     {
          return $this->db->get('pengeluaran_kas');
     }
     public function printsed()
     {
          return $this->db->get('pengeluaran_kas');
     }
     public function tampil_data()
     {
          return $this->db->get('pengeluaran');
     }
     public function input_data_detail($data, $table)
     {
          $this->db->insert('detail_penjualan', $data);
     }
     public function input_jurnal($data, $table)
     {
          $this->db->insert('jurnal_umum', $data);
     }
     public function input_ju($data, $table)
     {

          $this->db->insert('jurnal_umum', $data);
     }
     public function input_BB($data, $table)
     {
          $this->db->insert('buku_besar', $data);
     }
     public function input_buku($data, $table)
     {
          $this->db->insert('buku_besar', $data);
     }
     public function get_keyword($keyword)
     {
          $this->db->select('*');
          $this->db->from('jurnal_umum');
          $this->db->like('bukti', $keyword);
          return $this->db->get()->result();
     }
     public function data($where, $table)
     {
          return  $this->db->get_where($table, $where);
     }
     public function info($where, $table)
     {
          return  $this->db->get_where($table, $where);
     }
     function search_akun($title)
     {
          $this->db->like('nama', $title, 'both');
          $this->db->order_by('nama', 'ASC');
          $this->db->limit(10);
          return $this->db->get('akun')->result();
     }
     public function hapus_data($where, $table)
     {
          $this->db->where($where);
          $this->db->delete($table);
     }
}
