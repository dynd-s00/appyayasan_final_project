<?php
class M_buku_besar extends CI_Model
{

    public function tampil_bb_111()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='111' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_bb_112()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='112' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_bb_121()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='121' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_bb_411()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='411' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_bb_412()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='412' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_bb_413()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='413' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_bb_414()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='414' ORDER BY tgl,id";
        return $this->db->query($sql);
    }

    //PERIODE BULAN
    public function bln_bb_111()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
            $bln = $_GET['bln'];
        }
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='111' and EXTRACT(month FROM tgl) = '$bln' and EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql);
    }
    public function bln_bb_112()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
            $bln = $_GET['bln'];
        }
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='112' and EXTRACT(month FROM tgl) = '$bln' and EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql);
    }
    public function bln_bb_121()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
            $bln = $_GET['bln'];
        }
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='121' and EXTRACT(month FROM tgl) = '$bln' and EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql);
    }
    public function bln_bb_411()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
            $bln = $_GET['bln'];
        }
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='411' and EXTRACT(month FROM tgl) = '$bln' and EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql);
    }
    public function bln_bb_412()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
            $bln = $_GET['bln'];
        }
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='412' and EXTRACT(month FROM tgl) = '$bln' and EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql);
    }
    public function bln_bb_413()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
            $bln = $_GET['bln'];
        }
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='413' and EXTRACT(month FROM tgl) = '$bln' and EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql);
    }
    public function bln_bb_414()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
            $bln = $_GET['bln'];
        }
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='414' and EXTRACT(month FROM tgl) = '$bln' and EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql);
    }
    public function bln_bb_511()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
            $bln = $_GET['bln'];
        }
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='511' and EXTRACT(month FROM tgl) = '$bln' and EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql);
    }
    public function bln_bb_512()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
            $bln = $_GET['bln'];
        }
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='512' and EXTRACT(month FROM tgl) = '$bln' and EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql);
    }
    public function bln_bb_513()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
            $bln = $_GET['bln'];
        }
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='513' and EXTRACT(month FROM tgl) = '$bln' and EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql);
    }
    public function bln_bb_611()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
            $bln = $_GET['bln'];
        }
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='611' and EXTRACT(month FROM tgl) = '$bln' and EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql);
    }

    // TRIAL BALANCE

    public function tampil_tb_111()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='111' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_tb_112()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='112' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_tb_121()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='121' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_tb_411()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='411' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_tb_412()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='412' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_tb_413()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='413' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_bb_511()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='511' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_tb_511()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='511' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_bb_512()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='512' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_tb_512()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='512' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_tb_611()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='611' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_pk_111()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='111' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_pk_411()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='411' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_pk_412()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='412' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_pk_413()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='413' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_pk_511()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='511' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_pk_512()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='512' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_pk_112()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='112' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_pk_121()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='121' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function tampil_pk_611()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='611' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function print_ju($where, $table)
    {
        $this->db->where($where);
        return $this->db->get('buku_besar');
    }
    public function print_bb($where, $table)
    {
        $this->db->where($where);
        return $this->db->get('buku_besar');
    }
    public function showing()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
        }
        $sql = "SELECT * FROM buku_besar WHERE EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql);
    }


    //PERIODE TAHUN      
    public function thn_bb_111()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
        }
        $sql1 = "SELECT * FROM buku_besar
        where kdakun='111' and EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql1);
    }
    public function thn_bb_112()
    {
         if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
        }
        $sql1 = "SELECT * FROM buku_besar
        where kdakun='112' and EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql1);
    }
    public function thn_bb_121()
    {
         if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
        }
        $sql1 = "SELECT * FROM buku_besar
        where kdakun='121' and EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql1);
    }
    public function thn_bb_411()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
        }
        $sql1 = "SELECT * FROM buku_besar
        where kdakun='411' and EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql1);
    }
    public function thn_bb_412()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
        }
        $sql1 = "SELECT * FROM buku_besar
        where kdakun='412' and EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql1);
    }
    public function thn_bb_413()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
        }
        $sql1 = "SELECT * FROM buku_besar
        where kdakun='413' and EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql1);
    }
    public function thn_bb_511()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
        }
        $sql1 = "SELECT * FROM buku_besar
        where kdakun='511' and EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql1);
    }
    public function thn_bb_512()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
        }
        $sql1 = "SELECT * FROM buku_besar
        where kdakun='512' and EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql1);
    }
    public function thn_bb_513()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
        }
        $sql1 = "SELECT * FROM buku_besar
        where kdakun='513' and EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql1);
    }
    public function thn_bb_611()
    {
        if (isset($_GET['submit'])) {
            $thn = $_GET['thn'];
        }
        $sql1 = "SELECT * FROM buku_besar
        where kdakun='611' and EXTRACT(YEAR FROM tgl) = '$thn' ";
        return $this->db->query($sql1);
    }
    // PERIODE BULAN 

    public function pbln_bb_111()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='111' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function pbln_bb_112()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='112' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function pbln_bb_411()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='411' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function pbln_bb_412()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='412' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function pbln_bb_413()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='413' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function pbln_bb_511()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='511' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function pbln_bb_512()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='512' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function pbln_bb_513()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='513' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
    public function pbln_bb_611()
    {
        $sql = "SELECT * FROM buku_besar  WHERE kdakun='611' ORDER BY tgl,id";
        return $this->db->query($sql);
    }
}
