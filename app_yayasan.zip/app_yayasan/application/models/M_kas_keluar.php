<?php
class M_kas_keluar extends CI_Model
{
    
    public function input($data, $table)
    {
        
         $this->db->insert('kas_keluar', $data);       
    }
    public function tampil()
    {
        return $this->db->get('kas_keluar');
    }
    public function kas_keluar()
    {
        return $this->db->get('kas_keluar');
    }
    public function printsed()
    {
        return $this->db->get('kas_keluar');
    }
    public function tampil_data()
    {
        return $this->db->get('pengeluaran');
    }
 
    public function input_data_detail($data, $table)
    {
        
      $this->db->insert('detail_penjualan', $data);     
    }
    public function input_jurnal($data, $table)
    {
        
         $this->db->insert('jurnal_umum', $data);               
    }
    public function input_ju($data, $table)
    {
        
         $this->db->insert('jurnal_umum', $data);               
    }
    public function input_BB($data, $table)
    {
        
         $this->db->insert('buku_besar', $data);               
    }
    public function input_buku($data, $table)
    {
        
         $this->db->insert('buku_besar', $data);               
    }
    public function get_keyword($keyword)
    {
         $this->db->select('*');
         $this->db->from('jurnal_umum');
         $this->db->like('bukti', $keyword);
         return $this->db->get()->result();
    }
    public function data($where,$table)
    {
       return  $this->db->get_where($table, $where);
     
    }
    public function info($where,$table)
    {
       return  $this->db->get_where($table, $where);
     
    }
    
  
    
   
   
}

