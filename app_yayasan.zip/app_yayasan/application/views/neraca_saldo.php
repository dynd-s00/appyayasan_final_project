<section role="main" class="content-body">
    <header class="page-header">
        <h2>Dashboard</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="index.html">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span>Dashboard</span></li>
            </ol>

            <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
        </div>
    </header>
    <div class="row">
        <div class="col-md-12">
            <section class="panel">

                <section class="panel">
                    <header class="panel-heading">

                        <h2 class="panel-title">Neraca Saldo</h2>
                    </header>
                    <div class="panel-body">
                        <div class="panel">
                            <a href="<?php echo base_url('index.php/Neraca_saldo/print_neraca') ?>" target="_blank" class="btn btn-primary ml-sm"><i class="fa fa-print"></i> Print</a>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-bordered mb-none">
                                <tbody>
                                    <?php
                                    $saldoKAS = 0;
                                    ?>
                                    <?php foreach ($buku_111 as $bb)
                                        $saldoKAS += $bb->debit - $bb->kredit; ?>

                                    <?php
                                    $saldokencleng = 0;
                                    ?>
                                    <?php foreach ($buku_411 as $bb)
                                        $saldokencleng += $bb->kredit - $bb->debit; ?>

                                    <?php
                                    $saldodonasi = 0;
                                    ?>
                                    <?php foreach ($buku_412 as $bb)
                                        $saldodonasi += $bb->kredit - $bb->debit; ?>

                                    <?php
                                    $saldowakaf = 0;
                                    ?>
                                    <?php foreach ($buku_413 as $bb)
                                        $saldowakaf += $bb->kredit - $bb->debit; ?>

                                    <?php
                                    $saldobebanlistrik = 0;
                                    ?>
                                    <?php foreach ($buku_511 as $bb)
                                        $saldobebanlistrik += $bb->debit - $bb->kredit; ?>
                                    <?php
                                    $saldowifi = 0;
                                    ?>
                                    <?php foreach ($buku_512 as $bb)
                                        $saldowifi += $bb->debit - $bb->kredit; ?>
                                    <?php
                                    $saldopenyaluranwakaf = 0;
                                    ?>
                                    <?php foreach ($buku_611 as $bb)
                                        $saldopenyaluranwakaf += $bb->debit - $bb->kredit; ?>
                                    <?php
                                    $saldoperalatan = 0;
                                    ?>
                                    <?php foreach ($buku_112 as $bb)
                                        $saldoperalatan += $bb->debit - $bb->kredit; ?>
                                    <?php
                                    $saldoperlengkapan = 0;
                                    ?>
                                    <?php foreach ($buku_121 as $bb)
                                        $saldoperlengkapan += $bb->debit - $bb->kredit; ?>


                                </tbody>

                                <table class="table table-bordered mb-none">
                                    <tr>
                                        <td align="center">Nama Perkiraan</b></td>
                                        <td align="center">Debit</b></td>
                                        <td align="center">Kredit</b></td>
                                    </tr>
                                    <tr>
                                        <td> Kas</b></td>
                                        <td align="right"> <?php echo number_format($saldoKAS, 0, ',', '.')  ?> </td>
                                        <td align="right">0</td>
                                    </tr>
                                    <tr>
                                        <td>Perlengkapan </td>
                                        <td align="right"><?php echo number_format($saldoperlengkapan, 0, ',', '.')  ?> </td>
                                        <td align="right"></td>
                                    </tr>
                                    <tr>
                                        <td>Peralatan </td>
                                        <td align="right"><?php echo number_format($saldoperalatan, 0, ',', '.')  ?> </td>
                                        <td align="right"></td>
                                    </tr>
                                    <tr>
                                        <td>Dana kencleng</td>
                                        <td align="right">0</td>
                                        <td align="right"> <?php echo number_format($saldokencleng, 0, ',', '.')  ?></td>
                                    </tr>
                                    <tr>
                                        <td>Dana donasi</td>
                                        <td align="right">0</td>
                                        <td align="right"> <?php echo number_format($saldodonasi, 0, ',', '.')  ?></td>
                                    </tr>
                                    <tr>
                                        <td>Dana wakaf</td>
                                        <td align="right">0</td>
                                        <td align="right"> <?php echo number_format($saldowakaf, 0, ',', '.')  ?></td>
                                    </tr>
                                    <tr>
                                        <td> Beban iklan</td>
                                        <td align="right">0</td>
                                        <td align="right">0</td>
                                    </tr>
                                    <tr>
                                        <td> Beban listrik</td>
                                        <td align="right"><?php echo number_format($saldobebanlistrik, 0, ',', '.')  ?></td>
                                        <td align="right">0</td>
                                    </tr>
                                    <tr>
                                        <td> Beban wifi</td>
                                        <td align="right"><?php echo number_format($saldowifi, 0, ',', '.')  ?></td>
                                        <td align="right">0</td>
                                    </tr>
                                    <tr>
                                        <td> Penyaluran Wakaf</td>
                                        <td align="right"><?php echo number_format($saldopenyaluranwakaf, 0, ',', '.')  ?></td>
                                        <td align="right">0</td>
                                    </tr>
                                    <tr>
                                        <td align="center"><b> jumlah </b></td>
                                        <td align="right"><b> <?php echo number_format($saldoKAS + $saldobebanlistrik + $saldowifi + $saldopenyaluranwakaf + $saldoperalatan+  $saldoperlengkapan, 0, ',', '.')  ?></b></td>
                                        <td align="right"><b> <?php echo number_format($saldokencleng + $saldodonasi + $saldowakaf, 0, ',', '.')  ?></b></td>

                                    </tr>

                                </table>
                        </div>
                    </div>
                </section>