<div class="content-wrapper" style="box-align: center;">
    <section class="content">
        <?php foreach ($zakat as $pph) { ?>
            <form action="<?php echo base_url() . 'index.php/Data/simpan'; ?>" method="post">
 
                <div class="form-group">
                    <label> Nama </label>
                    <input type="text" name="nama" class="form-control" value="<?php echo $pph->nama ?>">
                </div>
                <div class="form-group">
                    <label> penghasilan </label>
                    <input type="text" name="penghasilan" class="form-control" value="<?php echo $pph->penghasilan ?>">
                </div>
                <div class="form-group">
                    <label> zakat </label>
                    <input type="text" name="zakat" class="form-control" value="<?php echo $pph->penghasilan*0.025 ?>">
                </div>
               
                <button type="reset" class="btn btn-danger"> Reset </button>
                <button type="submit" class="btn btn-primary"> simpan </button>
            </form>
        <?php } ?>