<section role="main" class="content-body">
    <header class="page-header">
        <h2>Pembayaran Zakat</h2>
    </header>


    <div class="row">
        <div class="col-md-9">
            <section class="panel">
                <form method="post" action="" role="form">
                    <div class="panel-body">
                        <div class="form-group">
                            <label class="col-sm-4 control-label">Penghasilan : </label>
                            <div class="col-sm-8">
                                <input type="text" name="penghasilan" class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-4 control-label"> Jumlah bulan yang akan dibayar (Angka): </label>
                            <div class="col-sm-8">
                                <input type="email" name="jml" class="form-control">
                            </div>
                        </div>
                    </div>
                    <footer class="panel-footer">
                        <button class="btn btn-primary">Submit </button>
                        <button type="reset" class="btn btn-default">Reset</button>
                    </footer>
                </form>
                </header>

                <section class="panel">
                    <form method="post" action="<?php echo base_url() . 'Zakat/bayar_zakat' ?>">
                        <div class="panel-body">
                            <div class="form-group">
                                <label class="col-sm-4 control-label">No Bukti : </label>
                                <div class="col-sm-8">
                                    <input type="text" name="name" class="form-control">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-4 control-label"> Jumlah zakat: </label>
                                <div class="col-sm-8">
                                    <input type="text" name="zakat" class="form-control" >
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-4 control-label"> Nomer HP: </label>
                                <div class="col-sm-8">
                                    <input type="text" name="hp" class="form-control">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-4 control-label"> Nama Lengkap: </label>
                                <div class="col-sm-8">
                                    <input type="email" name="email" class="form-control">
                                </div>
                            </div>
                            <label class="col-md-4 control-label">Tanggal:</label>
                            <div class="col-md-8">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </span>
                                    <input type="text" data-plugin-datepicker="" class="form-control">
                                </div>
                            </div>

                        </div>
                        <footer class="panel-footer">
                            <button class="btn btn-primary">Submit </button>
                            <button type="reset" class="btn btn-default">Reset</button>
                        </footer>

                    </form>
                </section>

            </section>
        </div>
    </div>


</section>