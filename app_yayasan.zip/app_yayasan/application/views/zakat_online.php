<?php
if (!isset($_SESSION['item_penghasilan'])) {
    $_SESSION['item_penghasilan'] = array();
}

if (isset($_POST['pilihan'])) {
    $pilihan = explode(" - ", $_POST['pilihan']);

    $item_penghasilan = $_SESSION['item_penghasilan'];
    array_push($item_penghasilan, $pilihan[0]);
    $_SESSION['item_penghasilan'] = $item_penghasilan;
}

if (isset($_POST['trx_aksi'])) {
    if ($_POST['trx_aksi'] == "clear") {
        session_unset();
    }
}
?>
<section role="main" class="content-body">
    <header class="page-header">
        <h2>Pembayaran Zakat</h2>
    </header>


    <div class="row">
        <div class="col-md-9">
            <section class="panel">
                <form method="post" action="" role="form">
                    <div class="panel-body">
                        <div class="form-group">
                            <label class="col-sm-4 control-label" name="pilihan"> Penghasilan : </label>
                            <div class="col-sm-8">
                                <input type="text" name="penghasilan" class="form-control">
                            </div>
                        </div>
                    </div>
                    <footer class="panel-footer">
                        <button class="btn btn-primary">Submit </button>
                    </footer>
                </form>
                </header>
                <?php
                $totaltrx = 0;
                if (isset($_SESSION['item_penghasilan'])) {
                    if (count($_SESSION['item_penghasilan']) > 0) {
                        $item_penghasilan = $_SESSION['item_penghasilan'];


                        $i = 0;
                        foreach ($_SESSION['item_penghasilan'] as $penghasilan) {
                            $zakat =  $penghasilan * 0.025;
                            echo "<tr>";
                            echo "<td>" . $penghasilan . "</td>";
                            echo "</tr>";

                            $totaltrx = $totaltrx + $zakat;
                            $i++;
                        }
                        echo '<form method="POST" action="">
           <input type="hidden" name="trx_aksi" value="clear"><br>
           <div class="input-group-btn">
             <button class="btn btn-sm btn-primary"><i class="fa fa-trash-o"></i> clear transaksi</button>
           </div>
          
           </form>';
                    }
                }
                ?>
                <section class="panel">
                    <form method="post" action="<?php echo base_url() . 'Zakat/bayar_zakat' ?>">
                        <div class="panel-body">
                            <div class="form-group">
                                <label class="col-sm-4 control-label">No Bukti : </label>
                                <div class="col-sm-8">
                                    <input type="text" name="name" class="form-control">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-4 control-label"> Jumlah zakat: </label>
                                <div class="col-sm-8">
                                    <input type="text" name="zakat" class="form-control" value='<?= $totaltrx ?>' readonly>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-4 control-label"> Nomer HP: </label>
                                <div class="col-sm-8">
                                    <input type="text" name="hp" class="form-control">
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-4 control-label"> Nama Lengkap: </label>
                                <div class="col-sm-8">
                                    <input type="email" name="email" class="form-control">
                                </div>
                            </div>
                            <label class="col-md-4 control-label">Tanggal:</label>
                            <div class="col-md-8">
                                <div class="input-group">
                                    <span class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </span>
                                    <input type="text" data-plugin-datepicker="" class="form-control">
                                </div>
                            </div>

                        </div>
                        <footer class="panel-footer">
                            <button class="btn btn-primary">Submit </button>
                            <button type="reset" class="btn btn-default">Reset</button>
                        </footer>

                    </form>
                </section>

            </section>
        </div>
    </div>


</section>