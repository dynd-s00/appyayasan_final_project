<section role="main" class="content-body">
    <header class="page-header">
        <h2>Dashboard</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="index.html">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span>Dashboard</span></li>
            </ol>

            <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
        </div>
    </header>
    <div class="row">
        <div class="col-md-12">
            <section class="panel">

                <section class="panel">
                    <header class="panel-heading">

                        <h2 class="panel-title">Laporan Posisi Keuangan</h2>
                    </header>
                    <div class="panel-body">
                        <div class="panel">
                            <a href="<?php echo base_url('index.php/Invoice/printsed') ?>" target="_blank" class="btn btn-primary ml-sm"><i class="fa fa-print"></i> Print</a>
                        </div>
                        <div class="table-responsive">
                            <tbody>
                                <?php
                                $saldoKAS = 0;
                                ?>
                                <?php foreach ($buku_111 as $bb)
                                    $saldoKAS += $bb->debit - $bb->kredit; ?>

                                <?php
                                $saldokencleng = 0;
                                ?>
                                <?php foreach ($buku_411 as $bb)
                                    $saldokencleng += $bb->kredit - $bb->debit; ?>

                                <?php
                                $saldoinfak = 0;
                                ?>
                                <?php foreach ($buku_412 as $bb)
                                    $saldoinfak += $bb->kredit - $bb->debit; ?>
                                <?php
                                $saldoperlengkapan = 0;
                                ?>
                                <?php foreach ($buku_112 as $bb)
                                    $saldoperlengkapan += $bb->debit - $bb->kredit; ?>
                                <?php
                                $saldoperalatan = 0;
                                ?>
                                <?php foreach ($buku_121 as $bb)
                                    $saldoperalatan += $bb->debit - $bb->kredit; ?>

                                <?php
                                $saldosedekah = 0;
                                ?>
                                <?php foreach ($buku_413 as $bb)
                                    $saldosedekah += $bb->kredit - $bb->debit; ?>

                                <?php
                                $saldobebanlistrik = 0;
                                ?>
                                <?php foreach ($buku_511 as $bb)
                                    $saldobebanlistrik += $bb->debit - $bb->kredit; ?>
                                <?php
                                $saldowifi = 0;
                                ?>
                                <?php foreach ($buku_512 as $bb)
                                    $saldowifi += $bb->debit - $bb->kredit; ?>
                                <?php
                                $saldopeyaluranwakaf = 0;
                                ?>
                                <?php foreach ($buku_611 as $bb)
                                    $saldopeyaluranwakaf += $bb->debit - $bb->kredit; ?>
                            </tbody>
                            <table class="table table-bordered mb-none">
                                <tr>
                                    <td align="left"><b> ASET </b></td>
                                    <td align="left"></b></td>
                                    <td align="left"></b></td>
                                </tr>
                                <tr>
                                    <td align="left"><b> Aset Lancar</b> </td>
                                    <td align="left"> </td>
                                    <td align="left"></td>
                                </tr>
                                <tr>
                                    <td align="left">Kas dan setara kas</td>
                                    <td align="left"><?php echo number_format($saldoKAS, 0, ',', '.')  ?> </td>
                                    <td align="left"></td>
                                </tr>
                                <tr>
                                    <td align="left">Piutang </td>
                                    <td align="left">Rp0</td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <td align="left">investasi dana kematian</td>
                                    <td align="left">Rp0</td>
                                    <td align="left"></td>
                                </tr>
                                <tr>
                                    <td align="left">Aset lancar lain-lain :
                                        Perlengkapan 
                                    </td>
                                    <td align="left">Rp <?php echo number_format($saldoperlengkapan, 0, ',', '.')  ?></td>
                                    <td align="left"> </td>
                                </tr>
                                <tr>
                                    <td align="left"><b>Total Aset Lancar</b></td>
                                    <td align="left"></td>
                                    <td align="left"><b><?php echo number_format($saldoKAS + $saldoperlengkapan, 0, ',', '.')  ?></b></td>
                                </tr>
                                <tr>
                                    <td align="left"><b>Aset Tidak Lancar</b></td>
                                    <td align="left"></td>
                                    <td align="left"></td>
                                </tr>
                                <tr>
                                    <td align="left">Aset Tetap</td>
                                    <td align="left">Rp </td>
                                    <td align="left"></td>
                                </tr>
                                <tr>
                                    <td align="left">Peralatan</td>
                                    <td align="left">Rp <?php echo number_format($saldoperalatan, 0, ',', '.')  ?></td>
                                    <td align="left"></td>
                                </tr>
                                <tr>
                                    <td align="left">bangunan</td>
                                    <td align="left">Rp0</td>
                                    <td align="left"></td>
                                </tr>
                                <tr>
                                    <td align="left"><b>Jumlah Aset Tidak Lancar</b></td>
                                    <td align="left"><b>Rp0</b></td>
                                    <td align="left"><b></b></td>
                                </tr>
                                <tr>
                                    <td align="left"><b>Total Aset </b></td>
                                    <td align="left"><b></b></td>
                                    <td align="left"><b><?php echo number_format($saldoKAS + $saldoperlengkapan +$saldoperalatan, 0, ',', '.')  ?></b></td>
                                </tr>
                                <tr>
                                    <td align="left"><b> Liabilitas </b></td>
                                    <td align="left"></td>
                                    <td align="left"><b> </b></td>
                                </tr>
                                <tr>
                                    <td align="left"><b>Liabilitas jangka pendek</b></td>
                                    <td align="left"><b></b></td>
                                    <td align="left"><b></b></td>
                                </tr>
                                <tr>
                                    <td align="left">Utang pengadaan barang</td>
                                    <td align="left">Rp0</td>
                                    <td align="left"></td>
                                </tr>
                                <tr>
                                    <td align="left">Utang pajak</td>
                                    <td align="left">Rp0</td>
                                    <td align="left"></td>

                                </tr>
                                <tr>
                                    <td align="left"><b>Total Liabilitas jangka pendek</b></td>
                                    <td align="left"><b></b></td>
                                    <td align="left"><b>Rp0</b></td>
                                </tr>
                                <tr>
                                    <td align="left"><b>Total Liabilitas dan Aset Neto</b></td>
                                    <td align="left"><b></b></td>
                                    <td align="left"><b><?php echo number_format($saldoKAS + $saldoperlengkapan + $saldoperalatan, 0, ',', '.')  ?></b></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </section>