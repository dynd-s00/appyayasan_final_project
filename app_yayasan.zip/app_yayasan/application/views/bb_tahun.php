<section role="main" class="content-body">
    <header class="page-header">
        <h2>Dashboard</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="index.html">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><?php echo $title ?></li>
            </ol>

            <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
        </div>
    </header>
    <div class="row">
        <div class="col-md-12">
            <section class="panel">

                <section class="panel">
                    <header class="panel-heading">

                        <h2 class="panel-title">Buku besar</h2>
                    </header>
                    <div class="panel-body">

                        <div class="table-responsive">
                            <table class="table table-bordered mb-none">
                                <tr>
                                    <td colspan="3"> Nama Akun: Kas</td>
                                    <td align="right" colspan="4"> Kode Akun: 111</td>
                                </tr>
                            </table>
                        </div>
                        </table>
                        <div class="table-responsive">
                            <table class="table table-bordered mb-none">
                                <thead>
                                    <tr>
                                        <th>Tanggl</th>
                                        <th>Keterangan</th>
                                        <th>Ref</th>
                                        <th>Debit</th>
                                        <th>Kredit</th>
                                        <th>Saldo</th>
                                    </tr>
                                </thead>

                                <?php
                                $saldo = 0;
                                ?>
                                <?php foreach ($buku_111 as $bb) : ?>
                                    <?php $saldo += $bb->debit - $bb->kredit; ?>
                                    <tr>
                                        <td><?php echo $bb->tgl ?> </td>
                                        <td> <?php echo $bb->keterangan ?> </td>
                                        <td> <?php echo $bb->ref ?> </td>
                                        <td> <?php echo number_format($bb->debit, 0, ',', '.') ?> </td>
                                        <td> <?php echo number_format($bb->kredit, 0, ',', '.') ?> </td>
                                        <?php echo '  <td align="right">' . number_format($saldo, 0, ',', '.')  .  '</td> </tr>'; ?>
                                    <?php endforeach; ?>
                            </table>
                        </div>
                        <br>
                        <!-- BATAS -->


                        <div class="table-responsive">
                            <table class="table table-bordered mb-none">
                                <tr>
                                    <td colspan="3"> Nama Akun: Perlengkapan </td>
                                    <td align="right" colspan="4"> Kode Akun: 112</td>
                                </tr>
                            </table>
                            <div class="table-responsive">
                                <table class="table table-bordered mb-none">
                                    <thead>
                                        <tr>
                                            <th>Tanggl</th>
                                            <th>Keterangan</th>
                                            <th>Ref</th>
                                            <th>Debit</th>
                                            <th>Kredit</th>
                                            <th>Saldo</th>
                                        </tr>
                                    </thead>

                                    <?php
                                    $saldo = 0;
                                    ?>
                                    <?php foreach ($buku_112 as $bb) :
                                        $saldo += $bb->debit - $bb->kredit; ?>
                                        <tr>
                                            <td><?php echo $bb->tgl ?> </td>
                                            <td> <?php echo $bb->keterangan ?> </td>
                                            <td align="center"> <?php echo $bb->ref ?> </td>
                                            <td> <?php echo number_format($bb->debit, 0, ',', '.') ?> </td>
                                            <td> <?php echo number_format($bb->kredit, 0, ',', '.') ?> </td>
                                            <?php echo '  <td align="left">' . number_format($saldo, 0, ',', '.')  .  '</td>'; ?>
                                        </tr>
                                    <?php endforeach; ?>
                                </table>
                                <br>
                                </table>
                            </div>

                            <!-- BATAS -->
                            <div class="table-responsive">
                                <table class="table table-bordered mb-none">
                                    <tr>
                                        <td colspan="3"> Nama Akun: Peralatan</td>
                                        <td align="right" colspan="4"> Kode Akun: 121</td>
                                    </tr>
                                </table>
                            </div>
                            <table class="table table-bordered mb-none">
                                <thead>
                                    <tr>
                                        <th>Tanggl</th>
                                        <th>Keterangan</th>
                                        <th>Ref</th>
                                        <th>Debit</th>
                                        <th>Kredit</th>
                                        <th>Saldo</th>
                                    </tr>
                                </thead>

                                <?php
                                $saldo = 0;
                                ?>
                                <?php foreach ($buku_121 as $bb) : ?>
                                    <?php $saldo += $bb->debit - $bb->kredit; ?>
                                    <tr>
                                        <td><?php echo $bb->tgl ?> </td>
                                        <td> <?php echo $bb->keterangan ?> </td>
                                        <td> <?php echo $bb->ref ?> </td>
                                        <td> <?php echo number_format($bb->debit, 0, ',', '.') ?> </td>
                                        <td> <?php echo number_format($bb->kredit, 0, ',', '.') ?> </td>
                                        <?php echo '  <td align="left">' . number_format($saldo, 0, ',', '.')  .  '</td></tr>'; ?>
                                    <?php endforeach; ?>
                            </table>

                            <!-- BATAS -->
                            <div class="table-responsive">
                                <table class="table table-bordered mb-none">
                                    <tr>
                                        <td colspan="3"> Nama Akun: Dana Kencleng</td>
                                        <td align="right" colspan="4"> Kode Akun: 411</td>
                                    </tr>
                                </table>
                            </div>
                            </table>
                            <div class="table-responsive">
                                <table class="table table-bordered mb-none">
                                    <thead>
                                        <tr>
                                            <th align="center">Tanggl</th>
                                            <th>Keterangan</th>
                                            <th>Ref</th>
                                            <th>Debit</th>
                                            <th>Kredit</th>
                                            <th>Saldo</th>
                                        </tr>
                                    </thead>

                                    <?php
                                    $saldo = 0;
                                    ?>
                                    <?php foreach ($buku_411 as $bb) :
                                        $saldo += $bb->kredit - $bb->debit; ?>
                                        <tr>
                                            <td><?php echo $bb->tgl ?> </td>
                                            <td> <?php echo $bb->keterangan ?> </td>
                                            <td align="center"> <?php echo $bb->ref ?> </td>
                                            <td align="center"> <?php echo number_format($bb->debit, 0, ',', '.') ?> </td>
                                            <td align="center"> <?php echo number_format($bb->kredit, 0, ',', '.') ?> </td>
                                            <?php echo '  <td align="right">' . number_format($saldo, 0, ',', '.') .  '</td>'; ?>
                                        </tr>
                                    <?php endforeach; ?>
                                </table>

                                <br>
                                <br>
                                <div class="table-responsive">
                                    <table class="table table-bordered mb-none">
                                        <tr>
                                            <td colspan="3"> Nama Akun: Dana Donasi </td>
                                            <td align="right" colspan="4"> Kode Akun: 412</td>
                                        </tr>

                                    </table>
                                    <div class="table-responsive">
                                        <table class="table table-bordered mb-none">
                                            <thead>
                                                <tr>
                                                    <th>Tanggl</th>
                                                    <th>Keterangan</th>
                                                    <th>Ref</th>
                                                    <th>Debit</th>
                                                    <th>Kredit</th>
                                                    <th>Saldo</th>
                                                </tr>
                                            </thead>

                                            <?php
                                            $saldo = 0;
                                            ?>
                                            <?php foreach ($buku_412 as $bb) :
                                                $saldo += $bb->kredit - $bb->debit; ?>
                                                <tr>
                                                    <td><?php echo $bb->tgl ?> </td>
                                                    <td> <?php echo $bb->keterangan ?> </td>
                                                    <td align="center"> <?php echo $bb->ref ?> </td>
                                                    <td> <?php echo number_format($bb->debit, 0, ',', '.') ?> </td>
                                                    <td> <?php echo number_format($bb->kredit, 0, ',', '.') ?> </td>
                                                    <?php echo '  <td align="right">' . number_format($saldo, 0, ',', '.') .  '</td>'; ?>
                                                </tr>
                                            <?php endforeach; ?>
                                        </table>
                                        <br>
                                    </div>

                                    <div class="table-responsive">
                                        <table class="table table-bordered mb-none">
                                            <tr>
                                                <td colspan="3"> Nama Akun: Dana wakaf </td>
                                                <td align="right" colspan="4"> Kode Akun: 413</td>
                                            </tr>

                                        </table>
                                        <div class="table-responsive">
                                            <table class="table table-bordered mb-none">
                                                <thead>
                                                    <tr>
                                                        <th>Tanggl</th>
                                                        <th>Keterangan</th>
                                                        <th>Ref</th>
                                                        <th>Debit</th>
                                                        <th>Kredit</th>
                                                        <th>Saldo</th>
                                                    </tr>
                                                </thead>

                                                <?php
                                                $saldo = 0;
                                                ?>
                                                <?php foreach ($buku_413 as $bb) :
                                                    $saldo += $bb->kredit - $bb->debit; ?>
                                                    <tr>
                                                        <td><?php echo $bb->tgl ?> </td>
                                                        <td> <?php echo $bb->keterangan ?> </td>
                                                        <td align="center"> <?php echo $bb->ref ?> </td>
                                                        <td> <?php echo number_format($bb->debit, 0, ',', '.') ?> </td>
                                                        <td> <?php echo number_format($bb->kredit, 0, ',', '.') ?> </td>
                                                        <?php echo '  <td align="right">' . number_format($saldo, 0, ',', '.')  .  '</td>'; ?>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </table>

                                            <br>

                                        </div>

                                        <div class="table-responsive">
                                            <table class="table table-bordered mb-none">
                                                <tr>
                                                    <td colspan="3"> Nama Akun: beban listrik </td>
                                                    <td align="right" colspan="4"> Kode Akun: 511</td>
                                                </tr>

                                            </table>
                                            <div class="table-responsive">
                                                <table class="table table-bordered mb-none">
                                                    <thead>
                                                        <tr>
                                                            <th>Tanggl</th>
                                                            <th>Keterangan</th>
                                                            <th>Ref</th>
                                                            <th>Debit</th>
                                                            <th>Kredit</th>
                                                            <th>Saldo</th>
                                                        </tr>
                                                    </thead>

                                                    <?php
                                                    $saldo = 0;
                                                    ?>
                                                    <?php foreach ($buku_511 as $bb) :
                                                        $saldo += $bb->debit - $bb->kredit; ?>
                                                        <tr>
                                                            <td><?php echo $bb->tgl ?> </td>
                                                            <td> <?php echo $bb->keterangan ?> </td>
                                                            <td align="center"> <?php echo $bb->ref ?> </td>
                                                            <td> <?php echo number_format($bb->debit, 0, ',', '.') ?> </td>
                                                            <td> <?php echo number_format($bb->kredit, 0, ',', '.') ?> </td>
                                                            <?php echo '  <td align="left">' . number_format($saldo, 0, ',', '.')  .  '</td>'; ?>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </table>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="table-responsive">
                                        <table class="table table-bordered mb-none">
                                            <tr>
                                                <td colspan="3"> Nama Akun: Beban wifi </td>
                                                <td align="right" colspan="4"> Kode Akun: 512</td>
                                            </tr>
                                        </table>
                                        <div class="table-responsive">
                                            <table class="table table-bordered mb-none">
                                                <thead>
                                                    <tr>
                                                        <th>Tanggl</th>
                                                        <th>Keterangan</th>
                                                        <th>Ref</th>
                                                        <th>Debit</th>
                                                        <th>Kredit</th>
                                                        <th>Saldo</th>
                                                    </tr>
                                                </thead>

                                                <?php
                                                $saldo = 0;
                                                ?>
                                                <?php foreach ($buku_512 as $bb) :
                                                    $saldo += $bb->debit - $bb->kredit; ?>
                                                    <tr>
                                                        <td><?php echo $bb->tgl ?> </td>
                                                        <td> <?php echo $bb->keterangan ?> </td>
                                                        <td align="center"> <?php echo $bb->ref ?> </td>
                                                        <td> <?php echo number_format($bb->debit, 0, ',', '.') ?> </td>
                                                        <td> <?php echo number_format($bb->kredit, 0, ',', '.') ?> </td>
                                                        <?php echo '  <td align="left">' . number_format($saldo, 0, ',', '.')  .  '</td>'; ?>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </table>
                                            <br>
                                            </table>
                                        </div>

                                        <!-- BATAS -->


                                        <div class="table-responsive">
                                            <table class="table table-bordered mb-none">
                                                <tr>
                                                    <td colspan="3"> Nama Akun: Penyaluran Wakaf </td>
                                                    <td align="right" colspan="4"> Kode Akun: 512</td>
                                                </tr>
                                            </table>
                                            <div class="table-responsive">
                                                <table class="table table-bordered mb-none">
                                                    <thead>
                                                        <tr>
                                                            <th>Tanggl</th>
                                                            <th>Keterangan</th>
                                                            <th>Ref</th>
                                                            <th>Debit</th>
                                                            <th>Kredit</th>
                                                            <th>Saldo</th>
                                                        </tr>
                                                    </thead>

                                                    <?php
                                                    $saldo = 0;
                                                    ?>
                                                    <?php foreach ($buku_611 as $bb) :
                                                        $saldo += $bb->debit - $bb->kredit; ?>
                                                        <tr>
                                                            <td><?php echo $bb->tgl ?> </td>
                                                            <td> <?php echo $bb->keterangan ?> </td>
                                                            <td align="center"> <?php echo $bb->ref ?> </td>
                                                            <td> <?php echo number_format($bb->debit, 0, ',', '.') ?> </td>
                                                            <td> <?php echo number_format($bb->kredit, 0, ',', '.') ?> </td>
                                                            <?php echo '  <td align="left">' . number_format($saldo, 0, ',', '.')  .  '</td>'; ?>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </table>
                                                <br>
                                                </table>
                                            </div>

                                            <?php
                                            if ($saldo > '0') {
                                                echo anchor('Buku_besar/print_bb/' . $bb->tgl, '<div class="btn btn-primary">Print</div>');
                                            } else if ($saldo <= "0") {
                                                echo anchor('Buku_besar/print_bb/' . $bb->tgl, '<div class="btn btn-primary">Print</div>');
                                            }
                                            ?>
                                        </div>
                </section>