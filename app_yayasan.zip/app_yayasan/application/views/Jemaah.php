<section role="main" class="content-body">
  <header class="page-header">
    <h2>Dashboard</h2>
    <div class="right-wrapper pull-right">
      <ol class="breadcrumbs">
        <li>
          <a href="index.html">
            <i class="fa fa-home"></i>
          </a>
        </li>
        <li><span>Dashboard</span></li>
      </ol>

      <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
    </div>
  </header>
  <div class="row">
    <div class="col-md-12">
      <section class="panel">
        <div class="panel-body">
          <h2 class="panel-title">Data Jemaah</h2>
          <section class="panel">
            <header class="panel-heading">
              <div class="panel-actions">
              </div>
              <button class="btn btn-default" data-toggle="modal" data-target="#exampleModal">
                <i class="fa fa-plus"> Open Form </i></button>
              <!-- Modal -->
              <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h4 class="modal-title" id="exampleModalLabel"> Masukan Data </h4>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <form method="post" action="<?php echo base_url() . 'index.php/Biodata_jemaah/tambah_data' ?>" id="demo-form">

                        <div class="form-group mt-lg">
                          <label class="col-sm-3 control-label"> Nij </label>
                          <div class="col-sm-9">
                            <input type="text" name="nij" class="form-control" readonly>
                          </div>
                        </div>
                        <div class="form-group mt-lg">
                          <label class="col-sm-3 control-label"> Nama Lengkap </label>
                          <div class="col-sm-9">
                            <input type="text" name="nama" class="form-control" placeholder="Type your name..." required>
                          </div>
                        </div>
                        <div class="form-group mt-lg">
                          <label class="col-sm-3 control-label"> Jenis Kelamin </label>
                          <div class="col-sm-9">
                            <input type="text" name="jenis_kelamin" class="form-control" placeholder="Type your name..." required>
                          </div>
                        </div>
                        <div class="form-group mt-lg">
                          <label class="col-sm-3 control-label"> Tempat Lahir </label>
                          <div class="col-sm-9">
                            <input type="text" name="tempat_lahir" class="form-control" placeholder="Type your name..." required>
                          </div>
                        </div>
                        <div class="form-group mt-lg">
                          <label class="col-sm-3 control-label"> tgl_lahir </label>
                          <div class="col-sm-9">
                            <input type="date" name="tgl_lahir" class="form-control" placeholder="Type your name..." required>
                          </div>
                        </div>
                        <div class="form-group mt-lg">
                          <label class="col-sm-3 control-label"> NIK </label>
                          <div class="col-sm-9">
                            <input type="text" name="nik" class="form-control" placeholder="Type your name..." required>
                          </div>
                        </div>
                        <div class="form-group mt-lg">
                          <label class="col-sm-3 control-label"> alaamt_jl </label>
                          <div class="col-sm-9">
                            <input type="text" name="alamat_jl" class="form-control" placeholder="Type your name..." required>
                          </div>
                        </div>
                        <div class="form-group mt-lg">
                          <label class="col-sm-3 control-label"> alamat_rt </label>
                          <div class="col-sm-9">
                            <input type="text" name="alamat_rt" class="form-control" placeholder="Type your name..." required>
                          </div>
                        </div>
                        <div class="form-group mt-lg">
                          <label class="col-sm-3 control-label"> alamat kelurahan </label>
                          <div class="col-sm-9">
                            <input type="text" name="alamat_kelurahan" class="form-control" placeholder="Type your name..." required>
                          </div>
                        </div>
                        <div class="form-group mt-lg">
                          <label class="col-sm-3 control-label"> alamat kecamatan </label>
                          <div class="col-sm-9">
                            <input type="text" name="alamat_kecamatan" class="form-control" placeholder="Type your name..." required>
                          </div>
                        </div>
                        <div class="form-group mt-lg">
                          <label class="col-sm-3 control-label"> alamat kota </label>
                          <div class="col-sm-9">
                            <input type="text" name="alamat_kota" class="form-control" placeholder="Type your name..." required>
                          </div>
                        </div>
                        <div class="form-group mt-lg">
                          <label class="col-sm-3 control-label"> No HP </label>
                          <div class="col-sm-9">
                            <input type="text" name="no_hp" class="form-control" placeholder="Type your name..." required>
                          </div>
                        </div>
                        <div class="form-group mt-lg">
                          <label class="col-sm-3 control-label"> pekerjaan </label>
                          <div class="col-sm-9">
                            <input type="text" name="pekerjaan" class="form-control" placeholder="Type your name..." required>
                          </div>
                        </div>
                        <div class="form-group mt-lg">
                          <label class="col-sm-3 control-label"> Motivasi </label>
                          <div class="col-sm-9">
                            <input type="text" name="motivasi" class="form-control" placeholder="Type your name..." required>
                          </div>
                        </div>
                        <div class="form-group mt-lg">
                          <label class="col-sm-3 control-label" type="text" name="mentor" class="form-control"> Mentor </label>
                          <div class="col-sm-9">
                            <select type="text" name="mentor" data-plugin-selecttwo="" class="form-control populate select2-offscreen" tabindex="-1" title="">
                              <optgroup label="Mentor">
                                <?php foreach ($mentor as $mn) { ?>
                                  <option>
                                    <?= $mn->id ?> - <?= $mn->nama ?>
                                  </option>
                                <?php } ?>

                              </optgroup>
                            </select>

                          </div>
                        </div>
                        <div class="form-group mt-lg">
                          <label class="col-sm-3 control-label"> FHQ/Private </label>
                          <div class="col-sm-9">
                            <input type="text" name="fhq_privat" class="form-control" placeholder="Type your name..." required>
                          </div>
                        </div>

                        <button class="btn btn-primary modal-confirm">Submit</button>
                        <button class="btn btn-default modal-dismiss">Cancel</button>

                      </form>
                    </div>
                  </div>
                </div>
              </div>
              <div class="panel-body">
                <div id="datatable-tabletools_wrapper" class="dataTables_wrapper no-footer">
                  <div class="text-right mb-md">
                  </div>
                  <div class="table-responsive">
                    <table class="table table-bordered table-striped mb-none dataTable no-footer" id="datatable-tabletools" data-swf-path="assets/vendor/jquery-datatables/extras/TableTools/swf/copy_csv_xls_pdf.swf" role="grid" aria-describedby="datatable-tabletools_info">
                      <thead>

                        <th> <i class="fa fa-barcode "> Nij </i></th>
                        <th><i class="fa fa-adjust "> Nama Lengkap </i></th>
                        <th><i class="fa fa-hdd-o "> Jenis Kelamin </i></th>
                        <th><i class="fa fa-tags "> Tempat/ Tanggal lahir</i> </th>
                        <th> <i class="fa fa-barcode "> Nik </i></th>

                        <th> Hapus </th>
                        <th> Edit </th>
                      </thead>
                      <?php
                      foreach ($jemaah as $bio) :
                      ?>
                        <tr>
                          <td><?php echo $bio->nij ?></td>
                          <td><?php echo $bio->nama ?></td>
                          <td><?php echo $bio->jenis_kelamin ?></td>
                          <td><?php echo $bio->tempat_lahir ?>/<?php echo $bio->tgl_lahir ?> </td>
                          <td><?php echo $bio->nik ?></td>

                          <td onclick="javascript: return confirm(Ingin Menghapus) "><?php echo anchor('Biodata_jemaah/hapus/' . $bio->nik, '<div class="btn btn-danger btn-sm"><i class="fa fa-trash-o">
                </i></div>') ?> </td>
                          <td><?php echo anchor('Biodata_jemaah/edit/' . $bio->nik, '<div class="btn btn-primary btn-sm"><i class="fa fa-edit ">
                </i></div>') ?></td>
                        </tr>
                      <?php endforeach; ?>


                    </table>
                  </div>
                  <div class="row datatables-footer">
                    <div class="col-sm-12 col-md-6">
                      <div class="dataTables_info" id="datatable-tabletools_info" role="status" aria-live="polite">Showing 1 to 10 of 57 entries</div>
                    </div>
                    <div class="col-sm-12 col-md-6">
                      <div class="dataTables_paginate paging_bs_normal" id="datatable-tabletools_paginate">
                        <ul class="pagination">
                          <li class="prev disabled"><a href="#"><span class="fa fa-chevron-left"></span></a></li>
                          <li class="active"><a href="#">1</a></li>
                          <li><a href="#">2</a></li>
                          <li><a href="#">3</a></li>
                          <li><a href="#">4</a></li>
                          <li><a href="#">5</a></li>
                          <li class="next"><a href="#"><span class="fa fa-chevron-right"></span></a></li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
          </section>
          </script>
        </div>
      </section>
    </div>
  </div>
  </aside>
</section>