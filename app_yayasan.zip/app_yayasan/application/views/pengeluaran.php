<section role="main" class="content-body">
    <header class="page-header">
        <h2>Dashboard</h2>
        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="index.html">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span>Dd</span></li>
            </ol>

            <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
        </div>
    </header>
    <div class="row">
        <div class="col-md-12">
            <section class="panel">

                <div class="panel-body">

                    <h2 class="panel-title">Data Pengeluaran</h2>

                    <section class="panel">
                        <header class="panel-heading">
                            <button class="btn btn-default" data-toggle="modal" data-target="#exampleModal">
                                <i class="fa fa-plus"> Open Form </i></button>
                            <!-- Modal -->
                            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h4 class="modal-title" id="exampleModalLabel"> Masukan Data </h4>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <form method="post" action="<?php echo base_url() . 'index.php/pengeluaran/kas_keluar' ?>">
                                            <section class="panel panel-featured panel-featured-primary ">
                                                <span class="separator"></span>
                                            </section>
                                            <div class="panel-body">
                                                <div class="form-group">
                                                    <label class="col-sm-4 control-label">No Bukti : </label>
                                                    <div class="col-sm-8">
                                                        <input type="text" name="nobukti" class="form-control" readonly>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-sm-4 control-label"> keterangan: </label>
                                                    <div class="col-sm-8">
                                                        <input type="text" name="pengeluaran" class="form-control">
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="col-sm-4 control-label"> nominal: </label>
                                                    <div class="col-sm-8">
                                                        <input type="text" name="nominal" class="form-control">
                                                    </div>
                                                </div>

                                                <label class="col-md-4 control-label">Tanggal:</label>
                                                <div class="col-md-8">
                                                    <div class="input-group">
                                                        <span class="input-group-addon">
                                                            <i class="fa fa-calendar"></i>
                                                        </span>
                                                        <input type="date" name="tgl" class="form-control">
                                                    </div>
                                                </div>
                                            </div>
                                            <button class="btn btn-primary modal-confirm">Submit</button>
                                            <button class="btn btn-default modal-dismiss">Cancel</button>
                                        </form>

                                    </div>
                                </div>
                            
                </div>

                <div class="panel-body">
                    <div id="datatable-tabletools_wrapper" class="dataTables_wrapper no-footer">
                        <div class="text-right mb-md">
                        </div>
                        <div class="table-responsive">
                            <table class="table table-bordered table-striped mb-none dataTable no-footer" id="datatable-tabletools" data-swf-path="assets/vendor/jquery-datatables/extras/TableTools/swf/copy_csv_xls_pdf.swf" role="grid" aria-describedby="datatable-tabletools_info">
                                <thead>

                                    <th> <i class="fa fa-barcode "> No Bukti </i></th>
                                    <th><i class="fa fa-calendar "> Tanggal </i></th>
                                    <th><i class="fa fa-money "> Keterangan</i> </th>
                                    <th><i class="fa fa-money "> Nominal </i> </th>


                                </thead>
                                <?php
                                $total1 =  0;
                                ?>
                                <?php
                                foreach ($kas_keluar as $kas) :
                                ?>
                                    <tr>
                                        <td><?php echo $kas->nobukti ?></td>
                                        <td><?php echo $kas->tgl ?></td>
                                        <td><?php echo $kas->pengeluaran?></td>
                                        <td><?php echo number_format($kas->nominal, 0, ',', '.')  ?></td>
                                        <td><?php echo anchor('Pengeluaran/invoicepengeluaran/' . $kas->nobukti, '<div class="btn btn-default btn-sm"><i class="fa  fa-file-text">
                </i></div>') ?> </td>

                                    </tr>
                                    <?php
                                    $total1 += $kas->nominal;
                                    ?>
                                <?php endforeach; ?>
                                <thead>
                                    <th colspan="3">Total Keseluruhan</th>

                                    <th colspan="4"><?php echo  number_format($total1, 0, ',', '.')  ?></th>

                                </thead>
                            </table>
                        </div>
                        <div class="row datatables-footer">
                            <div class="col-sm-12 col-md-6">
                                <div class="dataTables_info" id="datatable-tabletools_info" role="status" aria-live="polite">Showing 1 to 10 of 57 entries</div>
                            </div>
                            <div class="col-sm-12 col-md-6">
                                <div class="dataTables_paginate paging_bs_normal" id="datatable-tabletools_paginate">
                                    <ul class="pagination">
                                        <li class="prev disabled"><a href="#"><span class="fa fa-chevron-left"></span></a></li>
                                        <li class="active"><a href="#">1</a></li>
                                        <li><a href="#">2</a></li>
                                        <li><a href="#">3</a></li>
                                        <li><a href="#">4</a></li>
                                        <li><a href="#">5</a></li>
                                        <li class="next"><a href="#"><span class="fa fa-chevron-right"></span></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</section>
