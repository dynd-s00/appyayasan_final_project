 <!-- Popup itself -->
 <div id="intro" class="popup mfp-with-anim mfp-hide tm-bg-gray">
     <a href="" class="tm-close-popup">
         return home
         <i class="fas fa-times"></i>
     </a>
     <div class="tm-row tm-intro-row">

         <div class="tm-col tm-bg-white tm-intro-pad">
             <h2 class="tm-color-primary tm-page-title">Sejarah singkat ILQ</h2>
             <div class="tm-row tm-content-row">
                 <div class="tm-col-6 tm-intro-col-l">
                     <p align="justify">
                         Indonesia sebagai negara dengan jumlah muslim terbesar di dunia dipandang sebagai negara yang mampu membangun peradaban Islam yang kuat di masa yang akan datang. Terhitung 85% penduduk Indonesia merupakan Muslim. dengan jumlah tersebut,sudah sepantasny masyarakat memahami Islam melalui pemahaman Al-Qur'an dan As-Sunnah sebagai agamanya dengan baik.
                     </p>
                     <p align="justify">
                         Namun ada sebuah fakta yang cukup mengkhawatirkan bahwa ternyata tingkat buta huruf Al-Qur'an di Indonesia terbilang cukup tinggi.
                         Hasil riset dari lnstitut Ilmu Qur'an (IIQ) pada bulan Januari 2013 mencatat bahwa sekitar 65% masyarakat Indonesia buta huruf Al-Qur'an.
                         35 % nya hanya bisa membaca AI-Qur'an saja. Sedangkan yang bisa membaca secara fashih hanya 20% saja.
                     </p>
                     <p align="justify">
                         Berdasarkan data terse but dapat di ketahui bahwa dibalik jumlah penduduk Muslim yang mayoritas,
                         ternyata masih banyak diantara mereka yang belum terbiasa dengan Al-Qur'an bahkan belum bisa membacanya.
                         Permasalahan tersebut haruslah menjadi perhatian semua kalangan.
                         Usaha pengentasan buta huruf perlu diadakan secara massif dengan bekerjasama melibatkan berbagai pihak baik pemerintah,
                         tokoh ularna, organisasi, komunitas maupun peran aktif masyarakat
                     </p>
                 </div>
                 <div align="justify">
                     <p>
                         Berangkat dari masalah tadi, Indonesia Learning Qur'an (ILQ) hadir memberikan perhatian lebih pada isu tersebut.
                         dengan sebuah gerakan yang berbasis dakwah sosial melalui salah satu dari empat program JLQ yaitu "Pelatihan Baca Al-Qur'an dari Nol".
                         Persepsi yang muncul di masyarakat luas bahwa belajar Al-Qur'an itu sulit dan membutuhkan waktu yang lama, dalam hal ini ILQ mencoba untuk menepis hal tersebut
                         dengan menggunakan metode ILQ, dimana metode terse but hanya membutuhkan waktu 4 jam untuk seseorang dari tidak bisa membaca
                         Al-Qur'an hingga ke tahap mengenal semua huruf, tanda baca dan kaidah-kaidah tajwid sebagai syarat seseorang untuk membaca Al-Qur'an dengan baik.

                     </p>
                     <p align="justify">
                         Melalui program "Pelatihan Baca Al-Qur'an dari Nol" inilah menjadi sebuah kendaraan ILQ menuju Indonesia Bebas Buta Aksara Al-Qur'an
                     </p>
                     <p class="tm-mb-80">

                     </p>
                     <div class="tm-text-center">
                         <a href="#" class="tm-btn tm-btn-primary mfp-prevent-close tm-btn-next">
                             Next Page
                         </a>
                     </div>
                 </div>
             </div>
         </div>
     </div>
 </div>

 <div id="gallery" class="popup mfp-with-anim mfp-hide tm-bg-gray">
     <a href="#" class="tm-close-popup">
         return home
         <i class="fas fa-times"></i>
     </a>
     <div class="tm-row tm-gallery-row">
         <div class="tm-gallery">
             <div class="tm-gallery-container">
                 <figure class="effect-chico tm-gallery-item portrait">
                     <img src="<?php echo base_url() ?>onepage/img/gallery/portrait-01.jpg" alt="Image" />
                     <figcaption>
                         <p>Chico's main fear was missing the morning bus.</p>
                     </figcaption>
                 </figure>
                
             </div>
         </div>
     </div>
 </div>

 <div id="testimonials" class="popup mfp-with-anim mfp-hide tm-bg-gray">
     <a href="#" class="tm-close-popup">
         return home
         <i class="fas fa-times"></i>
     </a>
     <div class="tm-testimonials-inner">
         <h2 class="tm-color-gray tm-testimonial-col tm-page-title">About</h2>
         <div class="tm-row tm-testimonial-row">
             <div class="tm-col tm-testimonial-col">
                 <p>
                     OCEAN vibes is free website template from
                     <a rel="nofollow" href="https://templatemo.com" class="tm-color-primary">TemplateMo</a>
                     website. You are allowed to use
                     it for commercial purpose. You can convert this template as a CMS theme or a custom
                     website builder template.
                 </p>
                 <em class="tm-mb-30 tm-color-light-gray">
                     You may support us by telling your friends
                     about our TemplateMo site. Feel free to
                     contact us if you have anything to ask.
                 </em>
                 <p>
                     You can make a little contribution via
                     <a rel="nofollow" href="http://paypal.me/templatemo" target="_parent"><strong>PayPal</strong></a>
                     or saying about TemplateMo to your friends. Duis egestas lorem eu nisi
                     finibus, sit amet elementum lacus pretium.
                 </p>
                 <p>
                     In tempor felis vitae nulla feugiat aliquam.
                     Vivamus vitae congue mi. Sed maximus velit
                     vestibulum nisl condimentum hendrerit.
                 </p>
             </div>
             <div class="tm-col tm-testimonial-col tm-testimonial-col-2">
                 <img src="<?php echo base_url() ?>onepage/img/testimonial-01.jpg" alt="Image" class="tm-mb-30">
                 <blockquote>
                     <p>
                         "Suspendisse eu mollis diam, at ullamcorper
                         diam. Ut sit amet arcu metus. Nullam mattis
                         eros eget." by <span class="tm-color-primary">George, Chief Editor</span>
                     </p>
                 </blockquote>
                 <blockquote class="tm-mb-50">
                     <p>
                         "Quisque et lorem accumsan, sollicitudin
                         dolor vel, facilisis eros. Donec aliquet felis in
                         mollis egestas." by <span class="tm-color-primary">Mary, CEO of Web</span>
                     </p>
                 </blockquote>
             </div>
             <div class="tm-col tm-testimonial-col tm-testimonial-col-2">
                 <p>
                     Duis sapien diam, eleifend eget vehicula sed,
                     convallis sit amet elit. Aenean condimentum
                     vulputate porta.
                 </p>
                 <p>
                     Mauris accumsan erat ante, id sagittis felis
                     gravida vitae. Sed iaculis tincidunt neque, a
                     molestie magna vehicula at.
                 </p>
                 <p>
                     Phasellus ornare magna nec nulla pharetra,
                     nec tristique elit lobortis.
                 </p>
                 <img src="<?php echo base_url() ?>onepage/img/testimonial-02.jpg" alt="Image" class="tm-mt-35">
             </div>
         </div>
     </div>
 </div>


    
 <div id="contact" class="popup mfp-with-anim mfp-hide tm-bg-gray">
     <a href="#" class="tm-close-popup">
         return home
         <i class="fas fa-times"></i>
     </a>
     <h2 class="tm-contact-col tm-color-primary tm-page-title tm-mb-40">Contact Us</h2>
     <div class="tm-row tm-contact-row">
         <div class="tm-col tm-contact-col">

             <!-- Do you need a working HTML contact form?
                	Please visit https://templatemo.com/contact page -->

             <form id="contact-form" action="" method="POST" class="tm-contact-form">
                 <div class="form-group">
                     <input type="text" name="name" class="form-control rounded-0" placeholder="Full Name" required />
                 </div>
                 <div class="form-group">
                     <input type="email" name="email" class="form-control rounded-0" placeholder="Email" required />
                 </div>
                 <div class="form-group">
                     <select class="form-control" id="contact-select" name="inquiry">
                         <option value="-">Subject</option>
                         <option value="sales">Sales &amp; Marketing</option>
                         <option value="creative">Creative Design</option>
                         <option value="uiux">UI / UX</option>
                     </select>
                 </div>
                 <div class="form-group">
                     <textarea rows="8" name="message" class="form-control rounded-0" placeholder="Message" required=></textarea>
                 </div>

                 <div class="form-group tm-text-right">
                     <button type="submit" class="tm-btn tm-btn-primary">Send it now</button>
                 </div>
             </form>
         </div>
         <div class="tm-col tm-contact-col tm-contact-col-r">
             <!-- Map -->
             <div class="mapouter tm-mb-40">
                 <div class="gmap_canvas">
                     <iframe width="100%" height="520" id="gmap_canvas" src="https://g.page/Okaputra?share" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
                 </div>
             </div>

             <!-- Address -->
             <address class="tm-mb-40">
                 110-220 Nam vel ultricies mauris,<br>
                 Et gravida eros 10220
             </address>

             <!-- Links -->
             <ul class="tm-contact-links">
                 <li>
                     <a href="tel:0100200340">
                         <i class="fas fa-phone tm-contact-link-icon"></i>
                         Tel: 010-020-0340
                     </a>
                 </li>
                 <li>
                     <a href="mailto:info@company.com">
                         <i class="fas fa-at tm-contact-link-icon"></i>
                         Email: info@company.com
                     </a>
                 </li>
                 <li>
                     <a href="https://www.company.com">
                         <i class="fas fa-link tm-contact-link-icon"></i>
                         URL: www.company.com
                     </a>
                 </li>
             </ul>
         </div>
     </div>
 </div>
 </div>