<section role="main" class="content-body">
    <header class="page-header">
        <h2>Dashboard</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="index.html">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span>Dashboard</span></li>
            </ol>

            <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
        </div>
    </header>
    <div class="row">
        <div class="col-md-12">
            <section class="panel">

                <section class="panel">
                    <header class="panel-heading">

                        <h2 class="panel-title">Kode Akun</h2>
                    </header>
                    <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-bordered mb-none">
                                <thead>
                                    <tr align="center">
                                        <th>Kode Akun</th>
                                        <th>Nama Akun</th>
                                    </tr>
                                </thead>
                        </div>
                    </div>
                    <?php foreach ($akun as $ak) : ?>
                        <tr>
                            <td> <?php echo $ak->ref ?> </td>
                            <td> <?php echo $ak->nama ?> </td>
                        </tr>
                    <?php endforeach; ?>

                    </table>
        </div>
    </div>
</section>