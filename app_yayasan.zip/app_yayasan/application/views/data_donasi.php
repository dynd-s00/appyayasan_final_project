<section role="main" class="content-body">
    <header class="page-header">
        <h2>Dashboard</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="index.html">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span><?php echo $title ?></span></li>
            </ol>

            <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
        </div>
    </header>
    <div class="row">
        <div class="col-md-12">
            <section class="panel">

                <div class="panel-body">

                    <h2 class="panel-title"><a href="<?php echo site_url('index.php/Data_donasi') ?>">Input Data</a></h2>

                    <section class="panel">
                        <header class="panel-heading">
                            <div class="panel-actions">
                            </div>


                            <form method="post" action="<?php echo base_url() . 'index.php/Data_donasi/bayar_donasi' ?>">
                                <h2 class="panel-title"><i class="fa fa-user">Profile Donatur</i></i></h2>
                                <section class="panel panel-featured panel-featured-primary ">
                                    <span class="separator"></span>
                                </section>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Nominal : </label>
                                        <div class="col-sm-8">
                                            <input type="text" name="donasi" class="form-control">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">Nama : </label>
                                        <div class="col-sm-8">
                                            <input type="text" name="nama" id="nama" class="form-control">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">No Hp : </label>
                                        <div class="col-sm-8">
                                            <input type="text" name="hp" class="form-control">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-sm-4 control-label">jenis kelamin : </label>
                                        <div class="col-sm-8">
                                            <input type="text" name="jenis" class="form-control">
                                        </div>
                                    </div>
                                    <label class="col-md-4 control-label">Tanggal:</label>
                                    <div class="col-md-8">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </span>
                                            <input type="date" name="tgl" class="form-control">
                                        </div>
                                    </div>
                                    <button class="btn btn-primary modal-confirm">Submit</button>
                                    <button type="reset" class="btn btn-default">Reset</button>
                                </div>
                            </form>
                            <script type="text/javascript">
                                $(document).ready(function() {
                                    $("#nama").autocomplete({
                                        source: "<?php echo site_url('Data_donasi/get_autocomplete'); ?>",

                                        select: function(event, ui) {
                                            $('[name="title"]').val(ui.item.label);
                                            $('[name="hp"]').val(ui.item.hp);
                                            $('[name="alamat"]').val(ui.item.alamat);
                                            $('[name="jenis"]').val(ui.item.jenis);
                                            $('[name="institusi"]').val(ui.item.institusi);
                                        }
                                    });
                                });
                            </script>




                            <!-- Tabel -->
                            <div class="panel-body">
                                <div id="datatable-tabletools_wrapper" class="dataTables_wrapper no-footer">
                                    <div class="text-right mb-md">
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped mb-none dataTable no-footer" id="datatable-tabletools" data-swf-path="assets/vendor/jquery-datatables/extras/TableTools/swf/copy_csv_xls_pdf.swf" role="grid" aria-describedby="datatable-tabletools_info">
                                            <thead>

                                                <th> <i class="fa fa-barcode "> No Bukti </i></th>
                                                <th><i class="fa fa-calendar "> Tanggal </i></th>
                                                <th><i class="fa fa-user ">Nama Lengkap </i></th>
                                                <th><i class="fa fa-money "> Jumlah donasi</i> </th>
                                                <th><i class="fa fa-file-text "> Invoice </i> </th>
                                                <th><i class="fa fa-trash-o "> Hapus</i> </th>

                                            </thead>
                                            <?php
                                            $total1 =  0;
                                            ?>
                                            <?php
                                            foreach ($donasi as $inf) :
                                            ?>
                                                <tr>
                                                    <td><?php echo $inf->noinv ?></td>
                                                    <td><?php echo $inf->tgl ?></td>
                                                    <td><?php echo $inf->nama ?></td>
                                                    <td><?php echo number_format($inf->donasi, 0, ',', '.')  ?></td>
                                                    <td><?php echo anchor('Data_donasi/invoicedonasi/' . $inf->noinv, '<div class="btn btn-default btn-sm"><i class="fa  fa-file-text">
                                             </i></div>') ?> </td>
                                                    <td onclick="javascript: return confirm(Ingin Menghapus) "><?php echo anchor(
                                                                                                                    'Data_donasi/hapus/' . $inf->noinv,
                                                                                                                    '<div class="btn btn-danger btn-sm"><i class="fa fa-trash-o">
                                                                                                            </i></div>'
                                                                                                                ) ?> </td>
                                                </tr>
                                                <?php
                                                $total1 += $inf->donasi;
                                                ?>
                                            <?php endforeach; ?>
                                            <thead>
                                                <th colspan="3">Total Keseluruhan</th>

                                                <th colspan="4"><?php echo  number_format($total1, 0, ',', '.')  ?></th>

                                            </thead>

                                        </table>
                                    </div>
                                    <div class="row datatables-footer">
                                        <div class="col-sm-12 col-md-6">
                                            <div class="dataTables_info" id="datatable-tabletools_info" role="status" aria-live="polite">Showing 1 to 10 of 57 entries</div>
                                        </div>
                                        <div class="col-sm-12 col-md-6">
                                            <div class="dataTables_paginate paging_bs_normal" id="datatable-tabletools_paginate">
                                                <ul class="pagination">
                                                    <li class="prev disabled"><a href="#"><span class="fa fa-chevron-left"></span></a></li>
                                                    <li class="active"><a href="#">1</a></li>
                                                    <li><a href="#">2</a></li>
                                                    <li><a href="#">3</a></li>
                                                    <li><a href="#">4</a></li>
                                                    <li><a href="#">5</a></li>
                                                    <li class="next"><a href="#"><span class="fa fa-chevron-right"></span></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                    </section>

                </div>
            </section>