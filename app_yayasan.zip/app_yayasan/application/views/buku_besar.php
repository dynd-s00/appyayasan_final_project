<section role="main" class="content-body">
    <header class="page-header">
        <h2>Dashboard</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="index.html">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span>Dashboard</span></li>
            </ol>

            <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
        </div>
    </header>
    <div class="row">
        <div class="col-md-12">
            <section class="panel">

                <section class="panel">
                    <header class="panel-heading">

                        <h2 class="panel-title">Buku besar</h2>

                    </header>

                    <div class="col-md-8">
                        <form method="GET" action="<?php echo base_url() . 'index.php/Buku_besar/tahun' ?>" class="form-inline">
                            <h3> <label for="date1" class="panel-title"> Periode Pertahun </label></h3>
                            <select class="form-control mr-2" name="thn">
                                <option value="2022">2022</option>
                                <option value="2023">2023</option>
                                <option value="2024">2024</option>
                            </select>
                            <button type="submit" name="submit" class="btn btn-primary">Tampilkan</button>
                        </form>
                    </div>


                    <div class="col-md-8">
                        <form method="GET" action="<?php echo base_url() . 'index.php/Buku_besar/bulan' ?>" class="form-inline">
                            <h1> <label for="date1" class="panel-title"> Periode Per Bulan </label></h1>
                            <select class="form-control mr-2" name="bln">
                                <option value="1">Januari</option>
                                <option value="2">Februari</option>
                                <option value="3">Maret</option>
                                <option value="4">April</option>
                                <option value="5">Mei</option>
                                <option value="6">Juni</option>
                                <option value="7">Juli</option>
                                <option value="8">Agustus</option>
                                <option value="9">September</option>
                                <option value="10">Oktober</option>
                                <option value="11">November</option>
                                <option value="12">Desember</option>
                            </select>
                            <select class="form-control mr-2" name="thn">
                                <option value="2022">2022</option>
                                <option value="2023">2023</option>
                                <option value="2024">2024</option>
                            </select>
                            <button type="submit" name="submit" class="btn btn-primary">Tampilkan</button>
                        </form>
                    </div>
        </div>


        <div class="panel-body">
            <div class="panel">
            </div>
            <div class="table-responsive">
                <table class="table table-bordered mb-none">
                  
                </table>
            </div>

        </div>
    </div>
</section>
</section>
</div>
</div>
</section>