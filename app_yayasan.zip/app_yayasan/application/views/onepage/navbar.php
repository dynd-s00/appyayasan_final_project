<body>
    <header class="tm-site-header">
        <h1 class="tm-mt-0 tm-mb-15"><span class="tm-color-primary">ILQ</span> <span class="tm-color-gray-2">Official</span></h1>
        <em class="tm-tagline tm-color-light-gray"> Indonesia Learning Quran</em>
    </header>


    <div id="tm-img-container">
        <img src="<?php echo base_url() ?>onepage/img/thumbler.png">
    </div>
    <div class="tm-container">
        <nav class="tm-main-nav">
            <ul>
                <li class="tm-nav-item">
                <a href="<?php echo base_url('index.php/Beranda/History'); ?>" data-effect="" class="tm-nav-link">

                        A Brief History
                        <i class="fas fa-3x fa-id-card-alt"></i>
                    </a>
                </li>


                <li class="tm-nav-item">
                    <a href="<?php echo base_url('index.php/Beranda/gallery'); ?>" data-effect="" class="tm-nav-link" >
                        Gallery
                        <i class="far fa-3x fa-images"></i>
                    </a>
                </li>

                <li class="tm-nav-item">
                    <a href="#testimonials" data-effect="mfp-move-from-top" class="tm-nav-link">
                        About
                        <i class="fas fa-3x fa-book-reader"></i>
                    </a>
                </li>

                <li class="tm-nav-item">
                    <a href="#contact" data-effect="mfp-move-from-top" class="tm-nav-link">
                        Contact
                        <i class="fas fa-3x fa-phone-alt"> </i>
                    </a>
                </li>


                <li class="tm-nav-item">
                    <a href="<?php echo base_url('index.php/Auth'); ?>" data-effect="<?php echo base_url('index.php/Auth'); ?>" class="tm-nav-link">
                        login
                        <i class="fas fa-3x fa-laptop-house"></i>
                    </a>
                </li>

            </ul>



        </nav>