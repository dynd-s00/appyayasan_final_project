<footer class="tm-footer">
        <span>Copyright &copy; 2022 Y.ILQ</span>
        <span>Web Designed by
            <a href="https://templatemo.com" title="free website templates" target="_parent" rel="nofollow">Ds-ka19</a></span>
    </footer>

    <script src="<?php echo base_url() ?>onepage/js/jquery-3.4.1.min.js"></script>
    <script src="<?php echo base_url() ?>onepage/js/imagesloaded.pkgd.min.js"></script>
    <script src="<?php echo base_url() ?>onepage/js/isotope.pkgd.min.js"></script>
    <script src="<?php echo base_url() ?>onepage/js/jquery.magnific-popup.min.js"></script>
    <script src="<?php echo base_url() ?>onepage/js/templatemo-script.js"></script>
</body>

</html>