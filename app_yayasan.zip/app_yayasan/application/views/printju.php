<html>

<head>
    <title><?php echo $title ?></title>
    <!-- Web Fonts  -->
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet" type="text/css">

    <!-- Vendor CSS -->
    <link rel="stylesheet" href="<?php echo base_url() ?>asset/assets/vendor/bootstrap/css/bootstrap.css" />

    <!-- Invoice Print Style -->
    <link rel="stylesheet" href="<?php echo base_url() ?>asset/assets/stylesheets/invoice-print.css" />
</head>

<section class="panel">
                    <header class="panel-heading">

                        <h2 class="panel-title">Jurnal Umum</h2>
                    </header>
                    <div class="panel-body">
                   
                        <div class="table-responsive">
                            <table class="table table-bordered mb-none">
                                <thead>
                                    <tr align="center">
                                        <th>Tanggl</th>
                                        <th>No. Bukti</th>
                                        <th>Keterangan</th>
                                        <th>Ref</th>
                                        <th>Debit</th>
                                        <th>Kredit</th>
                                    </tr>
                                </thead>
                        </div>
                    </div>
                    <?php
                    $total1 = $total2 = 0;
                    ?>
                    <?php foreach ($jurnal_umum as $ju) : ?>
                        <tr>
                            <td align="center"> <?php echo $ju->tgl ?> </td>
                            <td align="center"> <?php echo $ju->bukti ?> </td>
                            <td> <?php echo $ju->keterangan ?> </td>
                            <td align="center"> <?php echo $ju->ref ?> </td>
                            <td align="right"> <?php echo number_format($ju->debit, 0, ',', '.') ?> </td>
                            <td align="right"> <?php echo number_format($ju->kredit, 0, ',', '.') ?> </td>
                        </tr>
                        <?php
                        $total1 += $ju->debit;
                        $total2 += $ju->kredit;
                        ?>
                    <?php endforeach; ?>

                    <?php
                    echo '
            <tr>
            <td align="center" colspan="4">
                <b>TOTAL KESELURUHAN</b></td>
            <td align="right">' . number_format($total1, 0, ',', '.')  . '</td>
            <td align="right">' . number_format($total2, 0, ',', '.')  . '</td>
            </tr>';
                    ?>

                    </table>

</div>
<script>
    window.print();
</script>
</body>

</html>

