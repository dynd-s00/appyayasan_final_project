<table class="table table-bordered mb-none">
    <tbody>
        <?php
        $saldoKAS = 0;
        ?>
        <?php foreach ($buku_111 as $bb)
            $saldoKAS += $bb->debit - $bb->kredit; ?>

        <?php
        $saldozakat = 0;
        ?>
        <?php foreach ($buku_411 as $bb)
            $saldozakat += $bb->kredit - $bb->debit; ?>

        <?php
        $saldoinfak = 0;
        ?>
        <?php foreach ($buku_412 as $bb)
            $saldoinfak += $bb->kredit - $bb->debit; ?>

        <?php
        $saldosedekah = 0;
        ?>
        <?php foreach ($buku_413 as $bb)
            $saldosedekah += $bb->kredit - $bb->debit; ?>

        <?php
        $saldobebanlistrik = 0;
        ?>
        <?php foreach ($buku_511 as $bb)
            $saldobebanlistrik += $bb->debit - $bb->kredit; ?>
        <?php
        $saldopenyaluranzakat = 0;
        ?>
        <?php foreach ($buku_512 as $bb)
            $saldopenyaluranzakat += $bb->debit - $bb->kredit; ?>


    </tbody>

    <table class="table table-bordered mb-none">
        <tr>
            <td align="center">Nama Perkiraan</b></td>
            <td align="center">Debit</b></td>
            <td align="center">Kredit</b></td>
        </tr>
        <tr>
            <td> Kas</b></td>
            <td align="right"> <?php echo number_format($saldoKAS, 0, ',', '.')  ?> </td>
            <td align="right">0</td>
        </tr>
        <tr>
            <td>Piutang usaha</td>
            <td align="right">0</td>
            <td align="right">0</td>
        </tr>
        <tr>
            <td>Perlengkapan kantor</td>
            <td align="right">0</td>
            <td align="right">0</td>
        </tr>
        <tr>
            <td>Utang usaha</td>
            <td align="right">0</td>
            <td align="right">0</td>
        </tr>
        <tr>
            <td>Dana Zakat</td>
            <td align="right">0</td>
            <td align="right"> <?php echo number_format($saldozakat, 0, ',', '.')  ?></td>
        </tr>
        <tr>
            <td>Dana Infak</td>
            <td align="right">0</td>
            <td align="right"> <?php echo number_format($saldoinfak, 0, ',', '.')  ?></td>
        </tr>
        <tr>
            <td>Dana Sedekah</td>
            <td align="right">0</td>
            <td align="right"> <?php echo number_format($saldosedekah, 0, ',', '.')  ?></td>
        </tr>
        <tr>
            <td> Beban iklan</td>
            <td align="right">0</td>
            <td align="right">0</td>
        </tr>
        <tr>
            <td> Beban listrik</td>
            <td align="right"><?php echo number_format($saldobebanlistrik, 0, ',', '.')  ?></td>
            <td align="right">0</td>
        </tr>
        <tr>
            <td> Penyaluran zakat</td>
            <td align="right"><?php echo number_format($saldopenyaluranzakat, 0, ',', '.')  ?></td>
            <td align="right">0</td>
        </tr>
        <tr>
            <td align="center"><b> jumlah </b></td>
            <td align="right"><b> <?php echo number_format($saldoKAS + $saldobebanlistrik + $saldopenyaluranzakat, 0, ',', '.')  ?></b></td>
            <td align="right"><b> <?php echo number_format($saldozakat + $saldoinfak + $saldosedekah, 0, ',', '.')  ?></b></td>

        </tr>

    </table>
    <script>
        window.print();
    </script>