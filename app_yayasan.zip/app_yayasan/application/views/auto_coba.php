<head>
    <link rel="stylesheet" href="<?php echo base_url() . 'asset/jquery/jquery-ui.css' ?>">
</head>

<body>
    <div class="container">
        <div class="row">
            <h2>Autocomplete Codeigniter</h2>
        </div>
        <div class="row">
            <form method="post" action="<?php echo base_url() . 'index.php/Data_zakat/bayar_zakat' ?>">
                <div class="modal-body">
                    <div class="form-group">
                        <label class="col-sm-4 control-label">No Bukti : </label>
                        <div class="col-sm-8">
                            <input type="text" name="noinv" class="form-control" readonly>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label">Nominal : </label>
                        <div class="col-sm-8">
                            <input type="text" name="zakat"  class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label">Nama : </label>
                        <div class="col-sm-8">
                            <input type="text" name="nama" id="nama" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-4 control-label">No HP : </label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" name="nohp" placeholder="NO HP">
                        </div>
                    </div>
                    <button class="btn btn-primary modal-confirm">Submit</button>
                </div>
            </form>
        </div>
    </div>
    </div>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#nama").autocomplete({
                source: "<?php echo site_url('Auto_coba/get_autocomplete/?'); ?>",

                select: function(event, ui) {
                    $('[name="title"]').val(ui.item.label);
                    $('[name="nohp"]').val(ui.item.nohp);
                }
            });
        });
    </script>


    </div>
    </div>

    <script src="<?php echo base_url() . 'js/jquery-3.3.1.js' ?>" type="text/javascript"></script>
    <script src="<?php echo base_url() . 'js/bootstrap.js' ?>" type="text/javascript"></script>
    <script src="<?php echo base_url() . 'js/jquery-ui.js' ?>" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#nama").autocomplete({
                source: "<?php echo site_url('Data_zakat/get_autocomplete/?'); ?>",

                select: function(event, ui) {
                    $('[name="title"]').val(ui.item.label);
                    $('[name="nohp"]').val(ui.item.nohp);
                }
            });
        });
    </script>