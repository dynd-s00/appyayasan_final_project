    <div id="<?php echo base_url('index.php/Beranda/gallery'); ?>">
        <a href="<?php echo base_url('index.php/Beranda'); ?>" class="tm-close-popup">
            return home
            <i class="fas fa-times"></i>
        </a>
         <div class="tm-row tm-gallery-row">
                <div class="tm-gallery">
                    <div class="tm-gallery-container">                        
                        <figure class="effect-chico tm-gallery-item portrait">
                            <img src="<?php echo base_url() ?>onepage/img/gallery/gaambar1.jpeg" alt="Image"/>
                            <figcaption>
                                <p>Chico's main fear was missing the morning bus.</p>							
                            </figcaption>			
                        </figure>
                        <figure class="effect-chico tm-gallery-item nature">
                            <img src="<?php echo base_url() ?>onepage/img/gallery/gaambar2.jpeg" alt="Image"/>
                            <figcaption>
                                <p>TemplateMo is the best website for free css templates.</p>							
                            </figcaption>			
                        </figure>
                        <figure class="effect-chico tm-gallery-item animal">
                            <img src="<?php echo base_url() ?>onepage/img/gallery/gaambar3.jpeg" alt="Image"/>
                            <figcaption>
                                <p>Chico's main fear was missing the morning bus.</p>							
                            </figcaption>			
                        </figure>
                        <figure class="effect-chico tm-gallery-item animal">
                            <img src="<?php echo base_url() ?>onepage/img/gallery/gaambar4.jpeg" alt="Image"/>
                            <figcaption>
                                <p>Chico's main fear was missing the morning bus.</p>							
                            </figcaption>			
                        </figure>
                    </div>
                </div>
                <!-- Gallery navigation and description -->
                <div class="tm-col tm-gallery-right">
                    <h2 class="tm-color-primary tm-mt-35 tm-page-title">Gallery Kegiatan ILQ</h2>
                    <div class="tm-gallery-right-inner">
                        <ul class="tm-gallery-links">
                            <li>
                                <a href="#" class="active tm-gallery-link" data-filter="*">
                                    <i class="fas fa-layer-group tm-gallery-link-icon"></i>
                                    All
                                </a>
                            </li>
                        </ul>
                       
                    </div>
                </div>
            </div>
        </div>
