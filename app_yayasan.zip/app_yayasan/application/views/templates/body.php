<body>
	<section class="body">

		<!-- start: header -->
		<header class="header">
			<div class="logo-container">
				<div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
					<i class="fa fa-bars" aria-label="Toggle sidebar"></i>
				</div>
			</div>


		</header>
		<script src="<?php echo base_url() . 'js/jquery-3.3.1.js' ?>" type="text/javascript"></script>
		<script src="<?php echo base_url() . 'js/bootstrap.js' ?>" type="text/javascript"></script>
		<script src="<?php echo base_url() . 'js/jquery-ui.js' ?>" type="text/javascript"></script>
		<!-- end: header -->