<head>
    <title><?php echo $title ?></title>
    <!-- Web Fonts  -->
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet" type="text/css">

    <!-- Vendor CSS -->
    <link rel="stylesheet" href="<?php echo base_url() ?>asset/assets/vendor/bootstrap/css/bootstrap.css" />

    <!-- Invoice Print Style -->
    <link rel="stylesheet" href="<?php echo base_url() ?>asset/assets/stylesheets/invoice-print.css" />
</head>
<table class="table table-bordered mb-none">
    <tr>
        <td colspan="3"> Nama Akun: kas</td>
        <td align="right" colspan="4"> Kode Akun: 111</td>
    </tr>
</table>
</div>
<div class="table-responsive">
    <table class="table table-bordered mb-none">
        <thead>
            <tr>
                <th>Tanggl</th>
                <th>Keterangan</th>
                <th>Ref</th>
                <th>Debit</th>
                <th>Kredit</th>
                <th>D/K</th>
                <th>Saldo</th>
            </tr>
        </thead>

        <?php
        $saldo = 0;
        ?>
        <?php foreach ($buku_111 as $bb) : ?>
            <?php $saldo += $bb->debit - $bb->kredit; ?>
            <tr>
                <td><?php echo $bb->tgl ?> </td>
                <td> <?php echo $bb->keterangan ?> </td>
                <td> <?php echo $bb->ref ?> </td>
                <td> <?php echo number_format($bb->debit, 0, ',', '.') ?> </td>
                <td> <?php echo number_format($bb->kredit, 0, ',', '.') ?> </td>
                <td align="center"> D </td>
                <?php echo '  <td align="right">' . number_format($saldo, 0, ',', '.')  .  '</td>
                </tr>'; ?>


            <?php endforeach; ?>
    </table>
</div>

<br>
<br>
<div class="table-responsive">
    <table class="table table-bordered mb-none">
        <tr>
            <td colspan="3"> Nama Akun: Zakat</td>
            <td align="right" colspan="4"> Kode Akun: 411</td>
        </tr>
    </table>
</div>
</table>
<div class="table-responsive">
    <table class="table table-bordered mb-none">
        <thead>
            <tr>
                <th align="center">Tanggl</th>
                <th>Keterangan</th>
                <th>Ref</th>
                <th>Debit</th>
                <th>Kredit</th>
                <th>D/K</th>
                <th>Saldo</th>
            </tr>
        </thead>

        <?php
        $saldo = 0;
        ?>
        <?php foreach ($buku_411 as $bb) :
            $saldo += $bb->kredit - $bb->debit; ?>
            <tr>
                <td><?php echo $bb->tgl ?> </td>
                <td> <?php echo $bb->keterangan ?> </td>
                <td align="center"> <?php echo $bb->ref ?> </td>
                <td align="center"> <?php echo number_format($bb->debit, 0, ',', '.') ?> </td>
                <td align="center"> <?php echo number_format($bb->kredit, 0, ',', '.') ?> </td>
                <td align="center"> K </td>
                <?php echo '  <td align="right">' . number_format($saldo, 0, ',', '.') .  '</td>'; ?>
            </tr>
        <?php endforeach; ?>
    </table>

    <br>
    <br>
    <div class="table-responsive">
        <table class="table table-bordered mb-none">
            <tr>
                <td colspan="3"> Nama Akun: Infak </td>
                <td align="right" colspan="4"> Kode Akun: 412</td>
            </tr>

        </table>
        <div class="table-responsive">
            <table class="table table-bordered mb-none">
                <thead>
                    <tr>
                        <th>Tanggl</th>
                        <th>Keterangan</th>
                        <th>Ref</th>
                        <th>Debit</th>
                        <th>Kredit</th>
                        <th>D/K</th>
                        <th>Saldo</th>
                    </tr>
                </thead>

                <?php
                $saldo = 0;
                ?>
                <?php foreach ($buku_412 as $bb) :
                    $saldo += $bb->kredit - $bb->debit; ?>
                    <tr>
                        <td><?php echo $bb->tgl ?> </td>
                        <td> <?php echo $bb->keterangan ?> </td>
                        <td align="center"> <?php echo $bb->ref ?> </td>
                        <td> <?php echo number_format($bb->debit, 0, ',', '.') ?> </td>
                        <td> <?php echo number_format($bb->kredit, 0, ',', '.') ?> </td>
                        <td align="center"> K </td>
                        <?php echo '  <td align="right">' . number_format($saldo, 0, ',', '.') .  '</td>'; ?>
                    </tr>
                <?php endforeach; ?>
            </table>
            <br>
        </div>
        <br>
        <br>
        <div class="table-responsive">
            <table class="table table-bordered mb-none">
                <tr>
                    <td colspan="3"> Nama Akun: Sedekah </td>
                    <td align="right" colspan="4"> Kode Akun: 413</td>
                </tr>

            </table>
            <div class="table-responsive">
                <table class="table table-bordered mb-none">
                    <thead>
                        <tr>
                            <th>Tanggl</th>
                            <th>Keterangan</th>
                            <th>Ref</th>
                            <th>Debit</th>
                            <th>Kredit</th>
                            <th>D/K</th>
                            <th>Saldo</th>
                        </tr>
                    </thead>

                    <?php
                    $saldo = 0;
                    ?>
                    <?php foreach ($buku_413 as $bb) :
                        $saldo += $bb->kredit - $bb->debit; ?>
                        <tr>
                            <td><?php echo $bb->tgl ?> </td>
                            <td> <?php echo $bb->keterangan ?> </td>
                            <td align="center"> <?php echo $bb->ref ?> </td>
                            <td> <?php echo number_format($bb->debit, 0, ',', '.') ?> </td>
                            <td> <?php echo number_format($bb->kredit, 0, ',', '.') ?> </td>
                            <td align="center"> K </td>
                            <?php echo '  <td align="right">' . number_format($saldo, 0, ',', '.')  .  '</td>'; ?>
                        </tr>
                    <?php endforeach; ?>
                </table>

                <br>

            </div>
            <div class="table-responsive">
                <table class="table table-bordered mb-none">
                    <tr>
                        <td colspan="3"> Nama Akun: beban listrik </td>
                        <td align="right" colspan="4"> Kode Akun: 511</td>
                    </tr>

                </table>
                <div class="table-responsive">
                    <table class="table table-bordered mb-none">
                        <thead>
                            <tr>
                                <th>Tanggl</th>
                                <th>Keterangan</th>
                                <th>Ref</th>
                                <th>Debit</th>
                                <th>Kredit</th>
                                <th>D/K</th>
                                <th>Saldo</th>
                            </tr>
                        </thead>

                        <?php
                        $saldo = 0;
                        ?>
                        <?php foreach ($buku_511 as $bb) :
                            $saldo += $bb->debit - $bb->kredit; ?>
                            <tr>
                                <td><?php echo $bb->tgl ?> </td>
                                <td> <?php echo $bb->keterangan ?> </td>
                                <td align="center"> <?php echo $bb->ref ?> </td>
                                <td> <?php echo number_format($bb->debit, 0, ',', '.') ?> </td>
                                <td> <?php echo number_format($bb->kredit, 0, ',', '.') ?> </td>
                                <td align="center"> K </td>
                                <?php echo '  <td align="left">' . number_format($saldo, 0, ',', '.')  .  '</td>'; ?>
                            </tr>
                        <?php endforeach; ?>
                    </table>

                    <br>
                    </table>
                </div>
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered mb-none">
                <tr>
                    <td colspan="3"> Nama Akun: Beban wifi </td>
                    <td align="right" colspan="4"> Kode Akun: 512</td>
                </tr>

            </table>
            <div class="table-responsive">
                <table class="table table-bordered mb-none">
                    <thead>
                        <tr>
                            <th>Tanggl</th>
                            <th>Keterangan</th>
                            <th>Ref</th>
                            <th>Debit</th>
                            <th>Kredit</th>
                            <th>D/K</th>
                            <th>Saldo</th>
                        </tr>
                    </thead>

                    <?php
                    $saldo = 0;
                    ?>
                    <?php foreach ($buku_512 as $bb) :
                        $saldo += $bb->debit - $bb->kredit; ?>
                        <tr>
                            <td><?php echo $bb->tgl ?> </td>
                            <td> <?php echo $bb->keterangan ?> </td>
                            <td align="center"> <?php echo $bb->ref ?> </td>
                            <td> <?php echo number_format($bb->debit, 0, ',', '.') ?> </td>
                            <td> <?php echo number_format($bb->kredit, 0, ',', '.') ?> </td>
                            <td align="center"> K </td>
                            <?php echo '  <td align="left">' . number_format($saldo, 0, ',', '.')  .  '</td>'; ?>
                        </tr>
                    <?php endforeach; ?>
                </table>

                <br>
                </table>
                <script>
                    window.print();
                </script>