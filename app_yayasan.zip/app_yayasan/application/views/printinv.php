<html>

<head>
    <title>Porto Admin - Invoice Print</title>
    <!-- Web Fonts  -->
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet" type="text/css">

    <!-- Vendor CSS -->
    <link rel="stylesheet" href="<?php echo base_url() ?>asset/assets/vendor/bootstrap/css/bootstrap.css" />

    <!-- Invoice Print Style -->
    <link rel="stylesheet" href="<?php echo base_url() ?>asset/assets/stylesheets/invoice-print.css" />
</head>

<body>
    <div class="invoice">
        <?php foreach ($kencleng as $kc) { ?>
            <header class="clearfix">
                <div class="row">
                    <div class="col-sm-6 mt-md">
                        <h2 class="h2 mt-none mb-sm text-dark text-bold">INVOICE</h2>
                        <h4 class="h4 m-none text-dark text-bold"><?= $kc->noinv ?></h4>
                    </div>
                    <div class="col-sm-6 text-right mt-md mb-md">
                        <address class="ib mr-xlg">
                            Yayasan ILQ (Indonesia Learning Quran)
                            <br>
                            GATEWAY PASTEUR L-0 C03,Jl. Gn. Batu,Sukaraja BANDUNG
                            <br>
                            Phone: 0821-2343-2516
                            <br>
                        </address>
                        <div class="ib">
                            <img src="<?php echo base_url() ?>asset/assets/images/ilq1.png">
                        </div>
                    </div>
                </div>
            </header>
            <div class="bill-info">
                <div class="row">
                    <div class="col-md-6">
                        <div class="bill-to">
                            <p class="h5 mb-xs text-dark text-semibold">To:</p>
                            <address>
                                <?= $kc->nama ?>
                                <br>
                                <?= $kc->alamat ?>
                                <br>
                                <?= $kc->hp ?>
                                <br>
                                info@envato.com
                            </address>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="bill-data text-right">
                            <p class="mb-none">
                                <span class="text-dark">Invoice Date:</span>
                                <span class="value"><?= $kc->tgl ?></span>
                            </p>

                        </div>
                    </div>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table invoice-items">
                    <thead>
                        <tr class="h4 text-dark">

                            <th id="cell-item" class="text-semibold"> Nama Lengkap </th>
                            <th id="cell-desc" class="text-semibold">Jenis Kelamin</th>
                            <th id="cell-price" class="text-center text-semibold">kencleng </th>
                            <th id="cell-price" class="text-center text-semibold">Institusi </th>


                        </tr>
                    </thead>
                    <tbody>

                        <tr>

                            <td class="text-semibold text-dark"><?= $kc->nama ?></td>
                            <td><?= $kc->jenis ?></td>
                            <td class="text-center"><?= number_format($kc->kencleng, 0, ',', '.') ?>
                            <td class="text-center"><?=  $kc->institusi ?>


                        </tr>
                    </tbody>
                </table>
            </div>


        <?php } ?>
    </div>
    <script>
        window.print();
    </script>
</body>

</html>