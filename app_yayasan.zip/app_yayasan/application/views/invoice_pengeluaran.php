<section role="main" class="content-body">
    <header class="page-header">
        <h2>Dashboard</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
                <li>
                    <a href="index.html">
                        <i class="fa fa-home"></i>
                    </a>
                </li>
                <li><span>Dashboard</span></li>
            </ol>

            <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
        </div>
    </header>
    <div class="row">
        <div class="col-md-12">
            <section class="panel">



                <section class="panel">
                    <header class="panel-heading">
                        <div class="panel-actions">

                        </div>
                        <div class="invoice">
                            <?php foreach ($pengeluaran_kas as $kas) { ?>
                                <header class="clearfix">
                                    <div class="row">
                                        <div class="col-sm-6 mt-md">
                                            <h2 class="h2 mt-none mb-sm text-dark text-bold">INVOICE</h2>
                                            <h4 class="h4 m-none text-dark text-bold"><?= $kas->nobukti ?></h4>
                                        </div>
                                        <div class="col-sm-6 text-right mt-md mb-md">
                                            <address class="ib mr-xlg">
                                                Yayasan ILQ (Indonesia Learning Quran)
                                                <br>
                                                GATEWAY PASTEUR L-0 C03,Jl. Gn. Batu,Sukaraja BANDUNG
                                                <br>
                                                Phone: 0821-2343-2516
                                                <br>
                                            </address>
                                            <div class="ib">
                                                <img src="<?php echo base_url() ?>asset/assets/images/ilq1.png">
                                            </div>
                                        </div>
                                    </div>
                                </header>
                                <div class="bill-info">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="bill-to">


                                                <br>
                                                info@envato.com
                                                </address>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="bill-data text-right">
                                                <p class="mb-none">
                                                    <span class="text-dark">Invoice Date:</span>
                                                    <span class="value"><?= $kas->tgl ?></span>
                                                </p>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="table-responsive">
                                    <table class="table invoice-items">
                                        <thead>
                                            <tr class="h4 text-dark">

                                                <th id="cell-item" class="text-semibold"> No Bukti </th>
                                                <th id="cell-desc" class="text-semibold">keterangan</th>
                                                <th id="cell-price" class="text-center text-semibold"> Jumlah </th>



                                            </tr>
                                        </thead>
                                        <tbody>

                                            <tr>

                                                <td class="text-semibold text-dark"><?= $kas->nobukti ?></td>
                                                <td><?= $kas->keterangan ?></td>
                                                <td class="text-center"><?= number_format($kas->jumlah, 0, ',', '.') ?>



                                            </tr>
                                        </tbody>
                                    </table>
                                </div>


                            <?php } ?>
                        </div>
                        <div class="text-right mr-lg">
                            <a href="#" class="btn btn-default">Submit Invoice</a>
                            <a href="<?php echo base_url('index.php/Invoice/printinf') ?>" target="_blank" class="btn btn-primary ml-sm"><i class="fa fa-print"></i> Print</a>
                        </div>


        </div>
</section>