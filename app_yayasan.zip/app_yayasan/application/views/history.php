<div id="<?php echo base_url('index.php/Beranda/History'); ?>" >
            <a href="<?php echo base_url('index.php/Beranda'); ?>" class="tm-close-popup">
                return home
                <i class="fas fa-times"></i>
            </a>
            <div class="tm-row tm-intro-row">

                <div class="tm-col tm-bg-white tm-intro-pad">
                    <h2 class="tm-color-primary tm-page-title">Sejarah singkat ILQ</h2>
                    <div class="tm-row tm-content-row">
                        <div class="tm-col-6 tm-intro-col-l">
                            <p align="justify">
                                Indonesia sebagai negara dengan jumlah muslim terbesar di dunia dipandang sebagai negara yang mampu membangun peradaban Islam yang kuat di masa yang akan datang. Terhitung 85% penduduk Indonesia merupakan Muslim. dengan jumlah tersebut,sudah sepantasny masyarakat memahami Islam melalui pemahaman Al-Qur'an dan As-Sunnah sebagai agamanya dengan baik.
                            </p>
                            <p align="justify">
                                Namun ada sebuah fakta yang cukup mengkhawatirkan bahwa ternyata tingkat buta huruf Al-Qur'an di Indonesia terbilang cukup tinggi.
                                Hasil riset dari lnstitut Ilmu Qur'an (IIQ) pada bulan Januari 2013 mencatat bahwa sekitar 65% masyarakat Indonesia buta huruf Al-Qur'an.
                                35 % nya hanya bisa membaca AI-Qur'an saja. Sedangkan yang bisa membaca secara fashih hanya 20% saja.
                            </p>
                            <p align="justify">
                                Berdasarkan data terse but dapat di ketahui bahwa dibalik jumlah penduduk Muslim yang mayoritas,
                                ternyata masih banyak diantara mereka yang belum terbiasa dengan Al-Qur'an bahkan belum bisa membacanya.
                                Permasalahan tersebut haruslah menjadi perhatian semua kalangan.
                                Usaha pengentasan buta huruf perlu diadakan secara massif dengan bekerjasama melibatkan berbagai pihak baik pemerintah,
                                tokoh ularna, organisasi, komunitas maupun peran aktif masyarakat
                            </p>
                        </div>
                        <div align="justify">
                            <p>
                                Berangkat dari masalah tadi, Indonesia Learning Qur'an (ILQ) hadir memberikan perhatian lebih pada isu tersebut.
                                dengan sebuah gerakan yang berbasis dakwah sosial melalui salah satu dari empat program JLQ yaitu "Pelatihan Baca Al-Qur'an dari Nol".
                                Persepsi yang muncul di masyarakat luas bahwa belajar Al-Qur'an itu sulit dan membutuhkan waktu yang lama, dalam hal ini ILQ mencoba untuk menepis hal tersebut
                                dengan menggunakan metode ILQ, dimana metode terse but hanya membutuhkan waktu 4 jam untuk seseorang dari tidak bisa membaca
                                Al-Qur'an hingga ke tahap mengenal semua huruf, tanda baca dan kaidah-kaidah tajwid sebagai syarat seseorang untuk membaca Al-Qur'an dengan baik.

                            </p>
                            <p align="justify">
                                Melalui program "Pelatihan Baca Al-Qur'an dari Nol" inilah menjadi sebuah kendaraan ILQ menuju Indonesia Bebas Buta Aksara Al-Qur'an
                            </p>
                            <p class="tm-mb-80">

                            </p>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>