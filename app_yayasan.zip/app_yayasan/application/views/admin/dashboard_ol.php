<section role="main" class="content-body">
    <header class="page-header">
        <h2>Dashboard</h2>

        <div class="right-wrapper">
          
            <div class="inner-body mg-main">

                <!-- start: page -->

                <div class="row mg-files" data-sort-destination data-sort-id="media-gallery">
                    <div class="isotope-item document col-sm-6 col-md-3 col-lg-3">
                        <div class="thumbnail">
                            <div class="thumb-preview">
                                <a class="thumb-image" href="<?php echo base_url() ?>asset/assets/images/projects/project-1.jpg">
                                    <img src="<?php echo base_url() ?>asset/assets/images/projects/project-1.jpg" class="img-responsive" alt="Project">
                                </a>
                                <div class="mg-thumb-options">
                                    <div class="mg-zoom"><i class="fa fa-search"></i></div>
                                    <div class="mg-toolbar">
                                        <div class="mg-option checkbox-custom checkbox-inline">
                                            <input type="checkbox" id="file_1" value="1">
                                            <label for="file_1">SELECT</label>
                                        </div>
                                        <div class="mg-group pull-right">
                                            <a href="#">EDIT</a>
                                            <button class="dropdown-toggle mg-toggle" type="button" data-toggle="dropdown">
                                                <i class="fa fa-caret-up"></i>
                                            </button>
                                            <ul class="dropdown-menu mg-menu" role="menu">
                                                <li><a href="#"><i class="fa fa-download"></i> Download</a></li>
                                                <li><a href="#"><i class="fa fa-trash-o"></i> Delete</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <h5 class="mg-title text-semibold">SEO<small>.png</small></h5>
                            <div class="mg-description">
                                <small class="pull-left text-muted">Design, Websites</small>
                                <small class="pull-right text-muted">07/10/2014</small>
                            </div>
                        </div>
                    </div>
                    <div class="isotope-item col-sm-6 col-md-4 col-lg-3">
                        <div class="thumbnail">
                            <div class="thumb-preview">
                                <a class="thumb-image" href="assets/images/projects/project-2.jpg">
                                    <img src="<?php echo base_url() ?>asset/assets/images/projects/project-2.jpg" class="img-responsive" alt="Project">
                                </a>
                                <div class="mg-thumb-options">
                                    <div class="mg-zoom"><i class="fa fa-search"></i></div>
                                    <div class="mg-toolbar">
                                        <div class="mg-option checkbox-custom checkbox-inline">
                                            <input type="checkbox" id="file_2" value="1">
                                            <label for="file_2">SELECT</label>
                                        </div>
                                        <div class="mg-group pull-right">
                                            <a href="#">EDIT</a>
                                            <button class="dropdown-toggle mg-toggle" type="button" data-toggle="dropdown">
                                                <i class="fa fa-caret-up"></i>
                                            </button>
                                            <ul class="dropdown-menu mg-menu" role="menu">
                                                <li><a href="#"><i class="fa fa-download"></i> Download</a></li>
                                                <li><a href="#"><i class="fa fa-trash-o"></i> Delete</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <h5 class="mg-title text-semibold">Blog<small>.png</small></h5>
                            <div class="mg-description">
                                <small class="pull-left text-muted">PSDs, Projects</small>
                                <small class="pull-right text-muted">07/10/2014</small>
                            </div>
                        </div>
                    </div>
                    <div class="isotope-item video col-sm-6 col-md-4 col-lg-3">
                        <div class="thumbnail">
                            <div class="thumb-preview">
                                <a class="thumb-image" href="assets/images/projects/project-5.jpg">
                                    <img src="<?php echo base_url() ?>asset/assets/images/projects/project-5.jpg" class="img-responsive" alt="Project">
                                </a>
                                <div class="mg-thumb-options">
                                    <div class="mg-zoom"><i class="fa fa-search"></i></div>
                                    <div class="mg-toolbar">
                                        <div class="mg-option checkbox-custom checkbox-inline">
                                            <input type="checkbox" id="file_3" value="1">
                                            <label for="file_3">SELECT</label>
                                        </div>
                                        <div class="mg-group pull-right">
                                            <a href="#">EDIT</a>
                                            <button class="dropdown-toggle mg-toggle" type="button" data-toggle="dropdown">
                                                <i class="fa fa-caret-up"></i>
                                            </button>
                                            <ul class="dropdown-menu mg-menu" role="menu">
                                                <li><a href="#"><i class="fa fa-download"></i> Download</a></li>
                                                <li><a href="#"><i class="fa fa-trash-o"></i> Delete</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <h5 class="mg-title text-semibold">Friends<small>.png</small></h5>
                            <div class="mg-description">
                                <small class="pull-left text-muted">Projects, Vacation</small>
                                <small class="pull-right text-muted">07/10/2014</small>
                            </div>
                        </div>
                    </div>

                    <div class="isotope-item video col-sm-6 col-md-4 col-lg-3">
                        <div class="thumbnail">
                            <div class="thumb-preview">
                                <a class="thumb-image" href="assets/images/projects/project-5.jpg">
                                    <img src="<?php echo base_url() ?>asset/assets/images/projects/project-5.jpg" class="img-responsive" alt="Project">
                                </a>
                                <div class="mg-thumb-options">
                                    <div class="mg-zoom"><i class="fa fa-search"></i></div>
                                    <div class="mg-toolbar">
                                        <div class="mg-option checkbox-custom checkbox-inline">
                                            <input type="checkbox" id="file_5" value="1">
                                            <label for="file_5">SELECT</label>
                                        </div>
                                        <div class="mg-group pull-right">
                                            <a href="#">EDIT</a>
                                            <button class="dropdown-toggle mg-toggle" type="button" data-toggle="dropdown">
                                                <i class="fa fa-caret-up"></i>
                                            </button>
                                            <ul class="dropdown-menu mg-menu" role="menu">
                                                <li><a href="#"><i class="fa fa-download"></i> Download</a></li>
                                                <li><a href="#"><i class="fa fa-trash-o"></i> Delete</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <h5 class="mg-title text-semibold">Poetry<small>.png</small></h5>
                            <div class="mg-description">
                                <small class="pull-left text-muted">Websites</small>
                                <small class="pull-right text-muted">07/10/2014</small>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
</section>
<!-- end: page -->

