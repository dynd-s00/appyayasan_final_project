<div class="content-wrapper">
  <!-- Modal -->
  <div class="box-header">
      <h2 class="primary">Bio data Jemaah baru</h2>
    </div><!-- /.box-header -->
        <section class="content">
        <div class="modal-body">
          <form method="post" action="<?php echo base_url() . 'index.php/Biodata_jemaah/tambah_data' ?>">

            <div class="form-group">
              <label> Nij </label>
              <input type="text" name="nij" class="form-control">
            </div>
            <div class="form-group">
              <label> Nama lengkap </label>
              <input type="text" name="nama_jemaah" class="form-control">
            </div>
            <div class="form-group">
              <label> Jenis Kelamin </label>
              <input type="text" name="jenis_kelamin" class="form-control">
            </div>
            <div class="form-group">
              <label> Tempat Lahir </label>
              <input type="text" name="tempat_lahir" class="form-control">
            </div>
            <div class="form-group">
              <label> tgl_lahir </label>
              <input type="date" name="tgl_lahir" class="form-control">
            </div>
            <div class="form-group">
              <label> NIK </label>
              <input type="text" name="nik" class="form-control">
            </div>
            <div class="form-group">
              <label> alamat_jl </label>
              <input type="text" name="alamat_jl" class="form-control">
            </div>
            <div class="form-group">
              <label> alamat_rt </label>
              <input type="text" name="alamat_rt" class="form-control">
            </div>
            <div class="form-group">
              <label> alamat_kelurahan </label>
              <input type="text" name="alamat_kelurahan" class="form-control">
            </div>
            <div class="form-group">
              <label> almat_kecamaatan</label>
              <input type="text" name="alamat_kecamatan" class="form-control">
            </div>
            <div class="form-group">
              <label> alamat kota </label>
              <input type="text" name="alamat_kota" class="form-control">
            </div>
            <div class="form-group">
              <label> no hp </label>
              <input type="text" name="no_hp" class="form-control">
            </div>
            <div class="form-group">
              <label> pekerjaan </label>
              <input type="text" name="pekerjaan" class="form-control">
            </div>
            <div class="form-group">
              <label> motivasi </label>
              <input type="text" name="motivasi" class="form-control">
            </div>
            <div class="form-group">
              <label> mentor </label>
              <input type="text" name="mentor" class="form-control">
            </div>
            <div class="form-group">
              <label> FHQ/Privat </label>
              <input type="text" name="fhq_privat" class="form-control">
            </div>

            <button type="close" class="btn btn-danger" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Save changes</button>
          </form>
        </div>
      </div>
    </div>
  </div>