<!doctype html>
<html class="fixed">

<head>

<title><?php echo $title?></title>
    <!-- Vendor CSS -->
    <link rel="stylesheet" href="<?php echo base_url() ?>asset/assets/vendor/bootstrap/css/bootstrap.css" />
    <link rel="stylesheet" href="<?php echo base_url() ?>asset/assets/vendor/font-awesome/css/font-awesome.css" />
    <link rel="stylesheet" href="<?php echo base_url() ?>asset/assets/vendor/magnific-popup/magnific-popup.css" />
    <link rel="stylesheet" href="<?php echo base_url() ?>asset/assets/vendor/bootstrap-datepicker/css/datepicker3.css" />

    <!-- Theme CSS -->
    <link rel="stylesheet" href="<?php echo base_url() ?>asset/assets/stylesheets/theme.css" />

    <!-- Skin CSS -->
    <link rel="stylesheet" href="<?php echo base_url() ?>asset/assets/stylesheets/skins/default.css" />

    <!-- Theme Custom CSS -->
    <link rel="stylesheet" href="<?php echo base_url() ?>asset/assets/stylesheets/theme-custom.css">

    <!-- Head Libs -->
    <script src="<?php echo base_url() ?>asset/assets/vendor/modernizr/modernizr.js"></script>

</head>

<body>
    <!-- start: page -->
    <section class="body-sign">
        <div class="center-sign">
            <a href="/" class="logo pull-left">
                <img src="<?php echo base_url() ?>asset/assets/images/ilq1.png" height="65" alt="Porto Admin" />
            </a>
            <div class="panel panel-sign">
                <div class="panel-title-sign mt-xl text-right">
                    <h2 class="title text-uppercase text-bold m-none"><i class="fa fa-user mr-xs"></i> Sign In</h2>
                </div>
                <?= $this->session->flashdata('pesan'); ?>
                <div class="panel-body">
                    <form class="user" method="POST" action="<?= base_url('index.php/Auth/proses_login') ?>">
                        <div class="form-group">
                            <input type="text" class="form-control form-control-user" id="username" name="username" placeholder="Enter username...">
                            <?= form_error('username', '<div class="alert alert-danger small ml-3">', '</div'); ?>
                            <br>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control form-control-user" id="password" name="password" placeholder="Password">
                            <?= form_error('password', '<div class="text-danger small ml-3">', '</div'); ?>
                        </div>
                        <div class="form-group">

                        </div>
                        <button type="submit" name="login" class="btn btn-primary btn-user btn-block">
                            Login
                        </button>
                    </form>
                </div>
            </div>

            <p class="text-center text-muted mt-md mb-md">&copy; Copyright 2021. All rights reserved. by Ds.</p>
        </div>
    </section>
    <!-- end: page -->


</body>

</html>