<section role="main" class="content-body">
    <header class="page-header">
        <h2>Dashboard</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">
               
            </ol>

            <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
        </div>
    </header>
<section class="panel">
    <header class="panel-heading">
        <div class="panel-actions">
           
        </div>

        <h2 class="panel-title">Edit Data Jemaah</h2>

      
    </header>
    <div class="panel-body">
        <?php foreach ($jemaah as $jmh) { ?>
            <form method="post" action="<?php echo base_url() . 'index.php/Biodata_jemaah/update' ?>" id="demo-form">

                <div class="form-group mt-lg">
                    <label class="col-sm-3 control-label"> Nij </label>
                    <div class="col-sm-9">
                        <input type="text" name="nij" class="form-control" readonly>
                    </div>
                </div>
                <div class="form-group mt-lg">
                    <label class="col-sm-3 control-label"> Nama Lengkap </label>
                    <div class="col-sm-9">
                        <input type="text" name="nama" class="form-control" value="<?php echo $jmh->nama ?>">
                    </div>
                </div>
                <div class="form-group mt-lg">
                    <label class="col-sm-3 control-label"> Jenis Kelamin </label>
                    <div class="col-sm-9">
                        <input type="text" name="jenis_kelamin" class="form-control" value="<?php echo $jmh->jenis_kelamin ?>">
                    </div>
                </div>
                <div class="form-group mt-lg">
                    <label class="col-sm-3 control-label"> Tempat Lahir </label>
                    <div class="col-sm-9">
                        <input type="text" name="tempat_lahir" class="form-control" value="<?php echo $jmh->tempat_lahir ?>">
                    </div>
                </div>
                <div class="form-group mt-lg">
                    <label class="col-sm-3 control-label"> tgl_lahir </label>
                    <div class="col-sm-9">
                        <input type="date" name="tgl_lahir" class="form-control" value="<?php echo $jmh->tgl_lahir ?>">
                    </div>
                </div>
                <div class="form-group mt-lg">
                    <label class="col-sm-3 control-label"> NIK </label>
                    <div class="col-sm-9">
                        <input type="text" name="nik" class="form-control" value="<?php echo $jmh->nik ?>">
                    </div>
                </div>
                <div class="form-group mt-lg">
                    <label class="col-sm-3 control-label"> alaamt_jl </label>
                    <div class="col-sm-9">
                        <input type="text" name="alamat_jl" class="form-control" value="<?php echo $jmh->alamat_jl ?>">
                    </div>
                </div>
                <div class="form-group mt-lg">
                    <label class="col-sm-3 control-label"> alamat_rt </label>
                    <div class="col-sm-9">
                        <input type="text" name="alamat_rt" class="form-control" value="<?php echo $jmh->alamat_rt ?>">
                    </div>
                </div>
                <div class="form-group mt-lg">
                    <label class="col-sm-3 control-label"> alamat kelurahan </label>
                    <div class="col-sm-9">
                        <input type="text" name="alamat_kelurahan" class="form-control" value="<?php echo $jmh->alamat_kelurahan ?>">
                    </div>
                </div>
                <div class="form-group mt-lg">
                    <label class="col-sm-3 control-label"> alamat kecamatan </label>
                    <div class="col-sm-9">
                        <input type="text" name="alamat_kecamatan" class="form-control" value="<?php echo $jmh->alamat_kecamatan ?>">
                    </div>
                </div>
                <div class="form-group mt-lg">
                    <label class="col-sm-3 control-label"> alamat kota </label>
                    <div class="col-sm-9">
                        <input type="text" name="alamat_kota" class="form-control" value="<?php echo $jmh->alamat_kota ?>">
                    </div>
                </div>
                <div class="form-group mt-lg">
                    <label class="col-sm-3 control-label"> No HP </label>
                    <div class="col-sm-9">
                        <input type="text" name="no_hp" class="form-control" value="<?php echo $jmh->no_hp ?>">
                    </div>
                </div>
                <div class="form-group mt-lg">
                    <label class="col-sm-3 control-label"> pekerjaan </label>
                    <div class="col-sm-9">
                        <input type="text" name="pekerjaan" class="form-control" value="<?php echo $jmh->pekerjaan ?>">
                    </div>
                </div>
                <div class="form-group mt-lg">
                    <label class="col-sm-3 control-label"> Motivasi </label>
                    <div class="col-sm-9">
                        <input type="text" name="motivasi" class="form-control" value="<?php echo $jmh->motivasi ?>">
                    </div>
                </div>
                <div class="form-group mt-lg">
                    <label class="col-sm-3 control-label" type="text" name="mentor" class="form-control" > Mentor </label>
                    <div class="col-sm-9">
                        <select type="text" name="mentor" data-plugin-selecttwo="" class="form-control populate select2-offscreen" tabindex="-1" title="" >
                            <optgroup label="Mentor">
                                <?php foreach ($mentor as $mn) { ?>
                                    <option>
                                        <?= $mn->nim ?> - <?= $mn->nama ?>
                                    </option>
                                <?php } ?>

                            </optgroup>
                        </select>

                    </div>
                </div>
                <div class="form-group mt-lg">
                    <label class="col-sm-3 control-label"> FHQ/Private </label>
                    <div class="col-sm-9">
                        <input type="text" name="fhq_privat" class="form-control" value="<?php echo $jmh->fhq_privat ?>">
                    </div>
                </div>

                <button class="btn btn-primary modal-confirm">Submit</button>
            </form>
        <?php } ?>
      
    </div>
    
</section>