<!DOCTYPE html>
<html lang="en">

<head>
    <title>Boostrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
<body>

    <div class="container">
        <div class="jumbotron">
        <h1> ini labsia </h1>
    </div>
    <p>Bootstrap is the most popular HTML,CSS, and JS framwork</p>
</body>

</html>
    