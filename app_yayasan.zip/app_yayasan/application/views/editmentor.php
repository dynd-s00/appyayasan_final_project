<section role="main" class="content-body">
    <header class="page-header">
        <h2>Dashboard</h2>

        <div class="right-wrapper pull-right">
            <ol class="breadcrumbs">

            </ol>

            <a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
        </div>
    </header>
    <section class="panel">
        <header class="panel-heading">
            <div class="panel-actions">

            </div>

            <h2 class="panel-title">Edit Data Mentor</h2>


        </header>
        <div class="panel-body">
            <?php foreach ($mentor as $jmh) { ?>
                <form method="post" action="<?php echo base_url() . 'index.php/Data_mentor/update' ?>" id="demo-form">

                    <div class="form-group mt-lg">
                        <label class="col-sm-3 control-label"> Nim </label>
                        <div class="col-sm-9">
                            <input type="text" name="nim" class="form-control" readonly value="<?php echo $jmh->nim ?>">
                        </div>
                    </div>
                    <div class="form-group mt-lg">
                        <label class="col-sm-3 control-label"> Nama Lengkap </label>
                        <div class="col-sm-9">
                            <input type="text" name="nama" class="form-control" value="<?php echo $jmh->nama ?>">
                        </div>
                    </div>
                    <div class="form-group mt-lg">
                        <label class="col-sm-3 control-label"> Jenis Kelamin </label>
                        <div class="col-sm-9">
                            <input type="text" name="jenis_kelamin" class="form-control" value="<?php echo $jmh->jenis_kelamin ?>">
                        </div>
                    </div>

                    <button class="btn btn-primary modal-confirm">Submit</button>
                </form>
            <?php } ?>

        </div>

    </section>