<?php

if(isset($_GET['nav'])){
    if ($_GET['nav']=="belanja"){
        include_once "content_belanja.php";
    
    }  else if ($_GET['nav']=="berjualan"){
         include_once "berjualan.php";
    }      
} else {
    include_once "sidebar.php";
}

?>