<aside class="main-sidebar">
<div class="bg-green-active color-platte">

</div>
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <div class="user-panel">
            <div class="left image">
              <img src="<?php echo base_url() ?>asset/dist/img/apotek.jpg" class="img-circle" alt="User Image" />
            </div>
            <div class="pull-left info">
              <p>Admin</p>

              <a href=""><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div>
          <!-- search form -->
         <br class="skin-danger">----------------------------------------------</br>
        
          <li class="header"></li>
        <!--  <li class="active treeview">
              <a href="#">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li class="active"><a href="index.html"><i class="fa fa-circle-o"></i> Dashboard v1</a></li>
                <li><a href="index2.html"><i class="fa fa-circle-o"></i> Dashboard v2</a></li>
              </ul>
            </li> -->
</br>
          
              
        <li class="active treeview">
            <a href="#">
                <i class="fa fa-medkit"></i> <span>Daftar Obat</span> <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu menu-open" style="display: block;">
                <li><a href="<?php echo base_url('index.php/obat_k')?>"><i class=""></i> Obat khusus | resep </a></li>
                <li><a href="<?php echo base_url('index.php/obat')?>"><i class=" "></i> Obat umum </a></li>
              </ul>
            </li>
            </br>
            <li>
            <a href="<?php echo base_url('index.php/supplier')?>">
                <i class="fa  fa-truck"></i> <span> Tabel supplier </span> <small class="label pull-right bg-green"></small>
              </a>
            </li>
            </br>
            <li>
            <a href="<?php echo base_url('index.php/transaksi')?>">
                <i class="fa fa-pencil-square"></i> <span> Transaksi </span> <small class="label pull-right bg-green"></small>
              </a>
            </li>

           
            

           
      <!-- Left side column. contains the logo and sidebar -->

          <!-- sidebar menu: : style can be found in sidebar.less -->
          <!--  <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <li >
              <a href="belanja.php">
              <i class="fa fa-shopping-cart"></i> <span> BELANJA </span> <small class="label pull-right bg-green"></small>
              </a>
            </li>
            <li >
              <a href="#">
              <i class="fa fa-th"></i> <span>TABEL BARANG </span> <small class="label pull-right bg-green"></small>
              </a>  
            </li>
            <li >
              <a href="#">
              <i class="fa fa-th"></i> <span> Mulai Berjualan </span> <small class="label pull-right bg-green">new</small>
              </a>
            </li>
             -->
                   
      </aside>



     
            