<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
           persediaan obat
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="<?php echo base_url(). 'index.php/home'?>"><i class="fa fa-home"></i> Home</a></li>
            <li class="active">data obat</li>
          </ol>
        </section>
        <section class="content">
        <button type="button" class="btn btn-success" data-toggle="modal" data-target="#staticBackdrop">
  persediaan obat + +
  </br>
</button>


    <div class="box box-solid box-success box-header">
        <div class="box box-success">
                  </div><!-- /.box-header -->
                <div class="box-body">
                  <div id="example1_wrapper" class="dataTables_wrapper form-inline" role="grid">
                  <div class="row">
                  <div class="col-xs-6">
                  <div id="example1_length" class="dataTables_length">
                  <label><select size="1" name="kode" aria-controls="example1">
                  <?php foreach($obat as $obt){ ?> 
                      <option value="<?=$obt->kode?>">
                         <?=$obt->kode ?>
                            </option>
                              <?php } ?>
                         
                  <option value=""></option><option value=""></option>
                  <option value=""></option></select> records per page</label>
                  </div>
                  </div>
                 
                  <div class="col-xs-6">
                  <div class="dataTables_filter" id="id">
                 <i class="fa fa-search"> search :  <input type="text" name="nama_obat" aria-controls="tabel1">
                 </i>
                  </div>
                  </div>
                  </div>
                  <table id="tabel1" class="table table-bordered table-striped dataTable" aria-describedby="example1_info">
                    <thead>
                      <tr role="row">
                      <th  class="fa fa-lock"> ID </th>
                      <th class="sorting_asc" role="columnheader" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 315.767px;" aria-sort="ascending" aria-label="Browser: activate to sort column descending"><i class="fa fa-book"> Nama Obat</th>
                      <th class="fa fa-hdd-o"> Stok</th>
                      <th class="sorting" role="columnheader" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 186.767px;" aria-label="Engine version: activate to sort column ascending"><i class="fa  fa-tags"> Harga </i></th>
                      <th>hapus</th>
                      <th>edit</th>    
                      
                    </thead>

              <tbody role="alert" aria-live="polite" aria-relevant="all"><tr class="odd">
            <?php foreach ($obat as $obt){ ?>
        <tr>
            <td><?php echo $obt->kode; ?> </td>
            <td><?php echo $obt->nama_obat; ?> </td>
            <td><?php echo $obt->stok; ?> </td>
            <td><?php echo $obt->harga; ?> </td>
            <td onclick="javascript: return confirm('hapus??')"><?php echo anchor ('obat/hapus/'.$obt->kode,
             '<div class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></div>')?> </td>
             <td><?php echo anchor('obat/edit/'.$obt->kode,'<div class="btn btn-primary btn-sm">
             <i class="fa fa-edit"></i></div>')?> </td>            
        </tr>
           <?php }?>
          </tbody>
          </table>
                <div class="row">
                <div class="col-xs-6">
                  <div class="dataTables_info" id="example1_info">Showing entries</div>
                    </div>
                    <div class="col-xs-6">
                      <div class="dataTables_paginate paging_bootstrap">
                      <ul class="pagination">
                      <li class="prev disabled">
                      <a href="#">← Previous</a>
                      </li>
                        <li class="active">
                           <a href="#">1</a>
                           </li>
                        <li>
                            <a href="#">2</a>
                            </li>
                        <li>
                            <a href="#">3</a>
                            </li>
                        <li>
                            <a href="#">4</a>
                            </li>
                        <li>
                            <a href="#">5</a>
                            </li>
                        <li class="next">
                            <a href="#">Next → </a>
                      </li>
                      </ul>
                      </div>
                    </div>
                  </div>
                </div>
                </div>
                
                 </footer>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
   </div>
    
  <!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="staticBackdropLabel">masukan data obat</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
    <form action="<?php echo base_url().'index.php/obat/tambah_aksi'; ?>" method="post">
        <div class="form-group">
            <label> kode obat</label>
            <input type="text" name="kode" class="form-control"></input>
        </div>
        <div class="form-group">
            <label> Nama obat</label>
            <input type="text" name="nama_obat" class="form-control"></input>
        </div>
        <div class="form-group">
            <label> stok tersedia</label>
            <input type="text" name="stok" class="form-control"></input>
        </div>
        <div class="form-group">
            <label> Harga </label>
            <input type="text" name="harga" class="form-control"></input>
        </div>
        <button type="reset" class="btn btn-danger" data-dismiss="modal">Reset</button>
        <button type="submit" class="btn btn-primary">save</button>
    </form>
      </div>
      </div>
  </div>
</div>
</div>






