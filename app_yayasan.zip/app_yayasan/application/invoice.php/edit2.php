<div class="content-wrapper">
<section class="content">

<?php foreach ($supplier as $spp){ ?>
    <span>Active
    <form  method="post" action="<?php echo base_url().'index.php/supplier/update'; ?>" > 

    <div class="form-group">
        <label > id supplier</label>
        <input type="text" name="id" class="form-control" value="<?php echo $spp->id?>">
        
    </div>
    <div class="form-group">
        <label > nama supplier </label>
        <input type="text" name="nama" class="form-control" value="<?php echo $spp->nama?>">
    </div>
    <div class="form-group">
        <label > alamat </label>
        <input type="text" name="alamat" class="form-control" value="<?php echo $spp->alamat?>">
    </div>
    <div class="form-group">
        <label > telp </label>
        <input type="text" name="tlp" class="form-control" value="<?php echo $spp->tlp?>">
    </div>
    <button type="reset" class="btn btn-danger"> reset </button>
    <button type="submit" class="btn btn-primary"> simpan </button>
    

    </form>
    </span>
    <?php  }   ?>
    </section>

</div>