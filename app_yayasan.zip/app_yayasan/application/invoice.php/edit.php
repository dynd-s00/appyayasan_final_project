<div class="content-wrapper">
<section class="content">

<?php foreach ($obat as $obat){ ?>
    <form  method="post" action="<?php echo base_url().'index.php/obat/update'; ?>" > 

    <div class="form-group">
        <label > kode obat</label>
        <input type="text" name="kode" class="form-control" value="<?php echo $obat->kode?>">
        
    </div>
    <div class="form-group">
        <label > nama obat </label>
        <input type="text" name="nama_obat" class="form-control" value="<?php echo $obat->nama_obat?>">
    </div>
    <div class="form-group">
        <label > stok </label>
        <input type="text" name="stok" class="form-control" value="<?php echo $obat->stok?>">
    </div>
    <div class="form-group">
        <label > harga </label>
        <input type="text" name="harga" class="form-control" value="<?php echo $obat->harga?>">
    </div>
    <button type="reset" class="btn btn-danger"> reset </button>
    <button type="submit" class="btn btn-primary"> simpan </button>
    

    </form>
    <?php  }   ?>
    </section>

</div>