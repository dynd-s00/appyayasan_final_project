


      <!-- Right side column. Contains the navbar and content of the page -->
      <div class="content-wrapper" style="min-height: 250;">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
          
            <small></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"></i> </a></li>
            <li class="active"></li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">

        <div class="box-solid box-danger box-header">
   <h3 class="box-title"> <b> ApoTek BaHagIa</b></h3>
                </div><!-- /.box-header -->
                <!-- form start -->
                <form action="<?php echo base_url().'index.php/log/login'; ?>" method="post">
                <div class="col-md-4 col-sm-6 col-xs-12">
                  <div class="box-body">
                    <div class="form-group">
                      <label for="exampleInputEmail1">username</label>
                      <input type="text" class="form-control" name="username" placeholder="admin02">
                    </div>
                    <div class="form-group">
                      <label for="exampleInputPassword1">Password</label>
                      <input type="password" class="form-control" name="password" placeholder="*****">
                    </div>
                    
                    
                  </div><!-- /.box-body -->

                  <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </form>



    
  

              
        
