<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
           Beranda
            <small>Control panel</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
            <li class="active"></li>
          </ol>
        </section>
        <section class="content">

        

       
                

        <div class="col-lg-12 col-xs-12">
              <!-- small box -->
              <div class="small-box bg-aqua">
                <div class="inner">
               <center>   <h3>selamat datang!</h3> </center>
                  <p> <i class="fa fa-angle-double-left"> pilih menu di sebelah kiri </i> </p>
                </div>
                <div class="icon">
                <i class="ion ion-person-add"></i>
                </div>
                <a href="#" class="small-box-footer"> <i class="fa fa-arrow-circle-right"></i></a>
              </div>
              </div>
           

            <!-- fix for small devices only -->
            <div class="clearfix visible-sm-block"></div>
      

            <div class="col-md-6 col-sm-6 col-xs-6">
              <div class="info-box">
                <span class="info-box-icon bg-green"><i class="glyphicon glyphicon-shopping-cart"></i></span>
                <div class="info-box-content">
                  <span class="info-box-text">pembelian</span>
                  <span class="info-box-number">2</span>
                  <a class="small-box-footer" href="<?php echo base_url(). '#'?> ">
                  Data <i class="fa fa-arrow-circle-right"></i> </a>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
            </div><!-- /.col -->
            <div class="col-md-6 col-sm-6 col-xs-6">
              <div class="info-box">
                <span class="info-box-icon bg-yellow">
                <i class=" fa fa-users"></i></span>
                <div class="info-box-content">
                  <span class="info-box-text">Data admin</span>
                  <span class="info-box-number">3</span>
                  <a class="small-box-footer" href="<?php echo base_url().'index.php/D_admin'?> ">
                  Data <i class="fa fa-arrow-circle-right"></i> </a>
                </div><!-- /.info-box-content -->
              </div><!-- /.info-box -->
            </div><!-- /.col -->
          
            
        
            
          
