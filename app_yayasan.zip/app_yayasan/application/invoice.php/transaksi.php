
               <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
           Transaksi
            <small></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="<?php echo base_url(). 'index.php/home'?>"><i class="fa fa-home"></i> Home</a></li>
            <li class="active"></li>
          </ol>
        </section>
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#staticBackdrop">
  transaksi obat + +
</button>
<table class="table table-hover">
        <tr>
            <th>ID</th>
            <th>NAMA </th>
            <th>harga</th>
            <th> hapus</th>      
        </tr>
      <tr>
        <td></td>
        <td></td>
        <td></td>
        </table>
    
   
   <!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="staticBackdropLabel">pembelian obat</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
    <form action="<?php echo base_url().'index.php/obat/dropdown'; ?>" method="post">
        
        <div class="form-group">
            <label> kode obat &#9; </label>
            <select type="text" name="kode" class="form-control ">
            <?php foreach($obat as $obt){ ?> 
            <option value="<?=$obt->kode?>">
            <?=$obt->kode ?>
            <?=$obt->nama_obat ?>
            </option>
            <?php } ?>
          </select>    
        </div>	

        

        <button type="reset" class="btn btn-danger" data-dismiss="modal">Reset</button>
        <button type="submit" class="btn btn-primary">save</button>
    </form>
      </div>
      </div>
  </div>
</div>
</div>

              <h3 class="box-title">form transaksi</h3>

           <!--   <form action="<?php echo base_url().'index.php'; ?>" method="post">
    No. Faktur Penjualan :
    <input class="form-control" type="text" name="nofakt"><br>
    tgl Transaksi :
    <input class="form-control" type="date" id="input-tgltrans" name="tgltrans" data-dp="0"><br>
    ID customer (Pembelian) :
    <input class="form-control" type="text" name="idcust">
    
    <br>
    Total Transaksi Penjualan :
    <input class="form-control" type="text" name="totalhrg" value="0" readonly=""><br>
    uang muka :
    <input class="form-control" type="text" name="uangmk"><br>
    tgl jatuh tempo :
    <input class="form-control" type="date" id="input-tgtemp" name="tgtemp" data-dp="79"><br>
    <div class="box-footer">
                    <button type="submit" class="btn btn-primary">Simpan transaksi</button>
                  </div>
    
</form> 
-->
