
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
           Daftar Admin
            <small></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="<?php echo base_url(). 'index.php/home'?>"><i class="fa fa-home"></i> Home</a></li>
            <li class="active">data admin</li>
          </ol>
        </section>
        <section class="content">
        

<div class="box box-header box-solid box-success">
<div class="box box-success disable color-palette">
                  
                </div><!-- /.box-header -->
                <div class="box-body">
                  <div id="example1_wrapper" class="dataTables_wrapper form-inline" role="grid">                
                  </div>
                 
                  <div class="col-xs-6">
                  <div class="dataTables_filter" id="id">
                 <i class="fa fa-search"> search :  <input type="text" name="nama" aria-controls="tabel1">
                 </i>
                  </div>
                  </div>
                  </div>
                  <table id="example1" class="table table-bordered table-striped dataTable" aria-describedby="example1_info">
                    <thead>
                      <tr role="row">
                      <th class="sorting" role="columnheader" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 219.767px;" aria-label="username: activate to sort column ascending"><i class=" glyphicon glyphicon-user"> Username </i></th>
                      <th class="sorting_asc" role="columnheader" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" style="width: 315.767px;" aria-sort="" aria-label="password: activate to sort column descending"><i class="glyphicon glyphicon-lock"> password  </i></th>   
                    <td> hapus </td>
                    <td> edit </td>                    
                    </thead>
                           
              <tbody role="alert" aria-live="polite" aria-relevant="all"><tr class="odd">
            <?php foreach ($admin as $adm){ ?>
              <tr>
            <td><?php echo $adm->username; ?> </td>
            <td><?php echo $adm->password ?> </td>
            
            <td onclick="javascript: return confirm('hapus??')"><?php echo anchor ('D_admin/hapus/'.$adm->username,
             '<div class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></div>')?> </td>
             <td><?php echo anchor('admin/edit/'.$adm->username,'<div class="btn btn-primary btn-sm">
             <i class="fa fa-edit"></i></div>')?> </td>            
              </tr>
                     <?php }?>
                    </tbody>
                    </table>

    
           <div class="row">
                  <div class="col-xs-6">
                  <div class="dataTables_info" id="example1_info">Showing entries</div>
                    </div>
                      <div class="col-xs-6">
                      <div class="dataTables_paginate paging_bootstrap">
                      <ul class="pagination">
                      <li class="prev disabled">
                         <a href="#">← Previous</a>
                      </li>
                      <li class="active">
                        <a href="#">1</a>
                      </li>
                      <li>
                        <a href="#">2</a>
                      </li>
                      <li>
                        <a href="#">3</a>
                      </li>
                      <li>
                        <a href="#">4</a>
                      </li>
                      <li>
                        <a href="#">5</a>
                      </li>
                      <li class="next">
                        <a href="#">Next → </a>
                        </li>
                      </ul>
                      </div>
                      </div>
                      </div>
                      </div>
                </div>
                
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
</div>


 







