
$("#nama").ready(function(){
    $("#nama").autocomplete({
        source :[
        "Apple",
        "Banana",
        "Cerry"
        ],
        select: function(event, selectedData) {
            console.log(selectedData);
        }
    })
}
)

var availableTags = [
	"dinda",
	"Anisat",
	"bunga",
	"cerry",
	"C",
	"C++",
	"Clojure",
	"COBOL",
	"ColdFusion",
	"Erlang",
	"Fortran",
	"Groovy",
	"Haskell",
	"Java",
	"JavaScript",
	"Lisp",
	"Perl",
	"PHP",
	"Python",
	"Ruby",
	"Scala",
	"Scheme"
];
$( "#nama" ).autocomplete({
	source: availableTags
});